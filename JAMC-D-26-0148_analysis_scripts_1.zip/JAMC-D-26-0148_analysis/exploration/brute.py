from test_cls import *
seasonsE={'OND':[10,11,12],'NDJ':[11,12,1],'DJF':[12,1,2],'JFM':[1,2,3],'SON':[9,10,11],'DJFM':[12,1,2,3],'NDJF':[11,12,1,2],'Dec':[12],'Jan':[1]}
seasonsI={'SON':[9,10,11],'ASO':[8,9,10],'OND':[10,11,12],'JJASON':[6,7,8,9,10,11],'SO':[9,10],'ON':[10,11],'Sep':[9],'Oct':[10],'Nov':[11],'JAS':[7,8,9]}
res=[]
for base in [(1981,2010),(1971,2000),(1991,2020),(1961,1990),(1951,1980)]:
    nb=anom(n,*base)
    for sn,ms in seasonsE.items():
        mis=[]
        for y in range(1951,2018):
            v=seas(nb,y,ms); e='EN' if v>=0.5 else ('LN' if v<=-0.5 else '0')
            if e!=T1[y][0]: mis.append((y,round(v,2)))
        res.append(('ENSO',base,sn,len(mis),mis))
    d=anom(b.wtio,*base)-anom(b.setio,*base)
    for sn,ms in seasonsI.items():
        for th in [0.4]:
            mis=[]
            for y in range(1951,2018):
                v=seas(d,y,ms); i='P' if v>=th else ('N' if v<=-th else '0')
                if i!=T1[y][1]: mis.append((y,round(float(v),2)))
            res.append(('IOD',base,sn,len(mis),mis))
for k in ['ENSO','IOD']:
    for r in sorted([r for r in res if r[0]==k],key=lambda r:r[3])[:6]: print(r)
