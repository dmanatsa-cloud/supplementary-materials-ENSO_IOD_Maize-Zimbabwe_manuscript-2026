import pandas as pd, numpy as np
x=pd.read_excel('/home/claude/data/zim/zimbabwe_natural_region_representative_timeseries_1951_2017_to be used.xlsx',sheet_name=None)
raw=x['Raw_Station_Data']; reg=x['Station_Regions'][['Station','Natural_Region']]
raw=raw.drop(columns=[c for c in raw.columns if c.startswith('Natural_Region')]).merge(reg,on='Station',how='left')
raw=raw[pd.to_numeric(raw.Year,errors='coerce').notna()].copy(); raw['Year']=raw.Year.astype(int)
med=raw.groupby('Station').Season_T.transform('median')
raw['ratio']=raw.Season_T/med
print('Season_T ratio extremes:')
print(raw[(raw.ratio>2.2)|(raw.ratio<0.3)][['Station','Natural_Region','Year','Season_T','ratio']].sort_values('ratio').to_string())
bad=raw[(raw.SOS.notna())&(raw.EOS.notna())&((raw.EOS-raw.SOS-raw.LOS).abs()>1)]
print('LOS!=EOS-SOS', len(bad)); print(bad[['Station','Year','SOS','EOS','LOS']].head(20).to_string())
print('SOS range', raw.SOS.min(), raw.SOS.max(), 'EOS range', raw.EOS.min(), raw.EOS.max(), 'LOS', raw.LOS.min(), raw.LOS.max())
print(raw[(raw.LOS<30)][['Station','Year','Season_T','SOS','EOS','LOS']].to_string())
for c in ['Oct_LODS','Nov_LODS','Dec_LODS','Jan_LODS','Feb_LODS','Mar_LODS']:
    print(c, raw[c].min(), raw[c].max(), (raw[c]>31).sum())
raw.to_pickle('raw_station.pkl')
