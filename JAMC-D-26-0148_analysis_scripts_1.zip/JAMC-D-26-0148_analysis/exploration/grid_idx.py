import xarray as xr, numpy as np, pandas as pd
from table1 import T1
ds=xr.open_dataset('/home/claude/data/ext/ersstv5_xr.nc')
sst=ds.sst
def box(lat0,lat1,lon0,lon1):
    s=sst.sel(lat=slice(lat1,lat0),lon=slice(lon0,lon1))
    w=np.cos(np.deg2rad(s.lat))
    return s.weighted(w).mean(('lat','lon')).to_series()
n34=box(-5,5,190,240); wtio=box(-10,10,50,70); setio=box(-10,0,90,110)
df=pd.DataFrame({'n34':n34,'wtio':wtio,'setio':setio})
df.index=pd.to_datetime(df.index)
df.to_csv('ersstv5_grid_boxes_1970_2021.csv')
print(df.head(3)); print(len(df))
def anom(s,b0,b1):
    clim=s[(s.index.year>=b0)&(s.index.year<=b1)].groupby(s[(s.index.year>=b0)&(s.index.year<=b1)].index.month).mean()
    return s-clim.reindex(s.index.month).values
for base in [(1991,2020),(1981,2010),(1971,2000),(1970,2021)]:
    a=pd.DataFrame({k:anom(df[k],*base) for k in df})
    a['dmi']=a.wtio-a.setio
    res=[]
    for y in range(1970,2018):
        djf=a.n34[[f'{y}-12-01',f'{y+1}-01-01',f'{y+1}-02-01']].mean()
        son=a.dmi[[f'{y}-09-01',f'{y}-10-01',f'{y}-11-01']].mean()
        e='EN' if djf>=0.5 else ('LN' if djf<=-0.5 else '0')
        i='P' if son>=0.4 else ('N' if son<=-0.4 else '0')
        res.append((y,djf,son,e,i,T1[y]))
    me=[r for r in res if r[3]!=r[5][0]]; mi=[r for r in res if r[4]!=r[5][1]]
    print(base,'ENSO mismatches',[(r[0],round(r[1],2),r[5][0]) for r in me])
    print(base,'IOD mismatches',[(r[0],round(r[2],2),r[5][1]) for r in mi])
