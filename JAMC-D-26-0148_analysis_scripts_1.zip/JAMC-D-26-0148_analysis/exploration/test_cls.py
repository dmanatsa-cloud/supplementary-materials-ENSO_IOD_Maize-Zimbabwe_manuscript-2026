from load_idx import *
from table1 import T1, T1ext
n=knmi_series(D+'iersst_nino34a.nc','Nino3.4')
b,_=ersst_io_boxes()
h=knmi_series(D+'ihadisst1_dmi.nc','diff')
def anom(s,b0,b1):
    m=(s.index.year>=b0)&(s.index.year<=b1)
    clim=s[m].groupby(s[m].index.month).mean()
    return s-clim.reindex(s.index.month).values
def detr(s,y0=1950,y1=2025):
    s=s[str(y0):str(y1)]
    t=np.arange(len(s)); ok=s.notna().values; p=np.polyfit(t[ok],s.values[ok],1); return s-np.polyval(p,t)
def seas(s,y,months):
    idx=[pd.Timestamp(y+(1 if m<7 else 0),m,1) for m in months]
    return s.reindex(idx).mean()
def classify(n34,dmi,years,te=0.5,ti=0.4):
    out={}
    for y in years:
        djf=seas(n34,y,[12,1,2]); son=seas(dmi,y,[9,10,11])
        e='EN' if djf>=te else ('LN' if djf<=-te else '0')
        i='P' if son>=ti else ('N' if son<=-ti else '0')
        out[y]=(e,i,djf,son)
    return out
def report(name,n34,dmi,ref=T1,years=range(1951,2018)):
    c=classify(n34,dmi,years)
    me=[(y,round(c[y][2],2),ref[y][0]) for y in years if c[y][0]!=ref[y][0]]
    mi=[(y,round(c[y][3],2),ref[y][1]) for y in years if c[y][1]!=ref[y][1]]
    print(f'{name}: ENSO mis {len(me)} {me}\n    IOD mis {len(mi)} {mi}')
    return c
if __name__=='__main__':
    for base in [(1981,2010),(1991,2020),(1971,2000),(1950,2017),(1951,2017)]:
        nb=anom(n,*base); 
        d=anom(b.wtio,*base)-anom(b.setio,*base)
        report(f'KNMI-N34 {base} / ERSSTv5 DMI {base}',nb,d)
    report('KNMI-N34 8110 / KNMI HadISST DMI raw',n,h)
    report('KNMI-N34 8110 / HadISST DMI 8110',n,anom(h,1981,2010))
    report('detr N34 / detr DMI (8110)',detr(anom(n,1981,2010)),detr(anom(b.wtio,1981,2010)-anom(b.setio,1981,2010)))
    report('detr N34 / detr boxes',detr(anom(n,1981,2010)),detr(anom(b.wtio,1981,2010))-detr(anom(b.setio,1981,2010)))
