import pandas as pd, numpy as np
from table1 import T1
df=pd.read_csv('ersstv5_grid_boxes_1970_2021.csv',index_col=0,parse_dates=True)
def anom(s,b0,b1):
    m=(s.index.year>=b0)&(s.index.year<=b1)
    clim=s[m].groupby(s[m].index.month).mean()
    return s-clim.reindex(s.index.month).values
def detr(s):
    t=np.arange(len(s)); p=np.polyfit(t,s.values,1); return s-np.polyval(p,t)+0
out=[]
for base in [(1991,2020),(1981,2010),(1971,2000),(1970,2021)]:
    A={k:anom(df[k],*base) for k in df}
    variants={
     'none':(A['n34'],A['wtio']-A['setio']),
     'detr_index':(detr(A['n34']),detr(A['wtio']-A['setio'])),
     'detr_boxes':(detr(A['n34']),detr(A['wtio'])-detr(A['setio'])),
    }
    for vn,(n,d) in variants.items():
        # running 3-mo means
        for sm in ['seasmean']:
            me=[];mi=[]
            for y in range(1970,2018):
                djf=n[[f'{y}-12-01',f'{y+1}-01-01',f'{y+1}-02-01']].mean()
                son=d[[f'{y}-09-01',f'{y}-10-01',f'{y}-11-01']].mean()
                e='EN' if djf>=0.5 else ('LN' if djf<=-0.5 else '0')
                i='P' if son>=0.4 else ('N' if son<=-0.4 else '0')
                if e!=T1[y][0]: me.append((y,round(float(djf),2)))
                if i!=T1[y][1]: mi.append((y,round(float(son),2)))
            out.append((base,vn,len(me),len(mi),me,mi))
for o in sorted(out,key=lambda o:o[2]+o[3]): print(o[0],o[1],'ENSOmis',o[2],'IODmis',o[3],o[4],o[5])
