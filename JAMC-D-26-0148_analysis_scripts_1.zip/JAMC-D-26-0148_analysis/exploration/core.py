import pandas as pd, numpy as np
from scipy import stats
import warnings; warnings.filterwarnings('ignore')
from stations import *
from indices import build, seasonal_table
from table1 import T1ext
rng=np.random.default_rng(42)
def get_rain():
    q=pd.read_pickle('/home/claude/analysis/station_qc.pkl')
    R,C=representative(q,'Season_T'); A=pct_anom(R); A['Nat']=national(A[NRS]); return R,C,A
def table_from_T1():
    mE={'EN':'EN','LN':'LN','0':'N'}; mI={'P':'P','N':'M','0':'N'}
    t=pd.DataFrame([dict(year=y,enso=mE[v[0]],iod=mI[v[1]]) for y,v in T1ext.items()]).set_index('year').sort_index()
    cmap={('EN','N'):'EN only',('LN','N'):'LN only',('N','P'):'pIOD only',('N','M'):'nIOD only',('EN','P'):'EN+pIOD',('EN','M'):'EN+nIOD',('LN','P'):'LN+pIOD',('LN','M'):'LN+nIOD',('N','N'):'Neutral'}
    t['cat']=[cmap[(a,b)] for a,b in zip(t.enso,t.iod)]; return t
def welch(a,b):
    a=np.asarray(a,float); b=np.asarray(b,float); a=a[~np.isnan(a)]; b=b[~np.isnan(b)]
    if len(a)<2 or len(b)<2: return np.nan,np.nan
    t,p=stats.ttest_ind(a,b,equal_var=False); return a.mean()-b.mean(),p
def boot_ci(a,b,n=10000):
    a=np.asarray(a,float); b=np.asarray(b,float); a=a[~np.isnan(a)]; b=b[~np.isnan(b)]
    d=[rng.choice(a,len(a)).mean()-rng.choice(b,len(b)).mean() for _ in range(n)]
    return np.percentile(d,[2.5,97.5])
def summary(t,A,years=range(1951,2018),label=''):
    t=t.loc[list(years)]; A=A.loc[list(years)]
    cols=NRS+['Nat']; out={}
    for nm,mask in [('EN',t.enso=='EN'),('LN',t.enso=='LN'),('pIOD',t.iod=='P'),('nIOD',t.iod=='M')]:
        out[nm]={c:welch(A.loc[mask,c],A.loc[~mask,c]) for c in cols}; out[nm]['n']=int(mask.sum())
    neu=t.cat=='Neutral'
    for c_ in ['EN+pIOD','EN only','LN only','LN+nIOD','pIOD only','nIOD only','EN+nIOD','LN+pIOD']:
        m=t.cat==c_
        if m.sum()==0: continue
        out[c_]={c:welch(A.loc[m,c],A.loc[neu,c]) for c in cols}; out[c_]['n']=int(m.sum())
    print(f'--- {label}  (neutral n={int(neu.sum())})')
    for k,v in out.items():
        print(f"{k:10s} n={v['n']:2d} "+' '.join(f"{c}:{v[c][0]:+6.1f}({v[c][1]:.3f})" for c in cols))
    return out
if __name__=='__main__':
    R,C,A=get_rain()
    df=build()
    tP=seasonal_table(df,range(1950,2025))
    tF=seasonal_table(df,range(1950,2025),'n34_8110','dmi_8110')
    tD=seasonal_table(df,range(1950,2025),'n34_detr','dmi_detr_boxes')
    tO=table_from_T1()
    summary(tO,A,label='Submitted Table 1 classification, QC rainfall')
    summary(tP,A,label='PRIMARY rolling-base (CPC ONI convention)')
    summary(tF,A,label='Fixed 1981-2010 base, no detrending')
    summary(tD,A,label='Fixed base, linearly detrended boxes')
