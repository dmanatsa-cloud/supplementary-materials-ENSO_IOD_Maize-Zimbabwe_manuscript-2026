# JAMC-D-26-0148 revision: analysis and build scripts

Python 3 (pandas, numpy, scipy, statsmodels, xarray, netCDF4, geopandas, regionmask, matplotlib, python-docx).
Paths are absolute to the working machine (`/home/claude/...`); edit the path constants at the top of each script.

## Order of execution
1. `pipeline/station_coords.py`  MSD register coordinates and polygon allocation -> `stations_table.csv`
1b. `pipeline/stations.py`  station quality control -> `station_qc.pkl`
2. `pipeline/indices.py`  Niño 3.4 and DMI from ERSSTv5 (CPC moving 30-yr base) and alternatives -> `indices_monthly_built.csv`, `season_class_primary.csv`
3. `pipeline/chirps.py`  CHIRPS v2.0 daily, averaged in Natural Region polygons
4. `pipeline/data.py`  station QC and representative series, CHIRPS, SPEI-6, Tmax, ERA5-Land, maize mapping -> `cache_data.pkl`
   (ERA5 pressure-level and Tmax fields were pre-subset to seasonal 0.5° npz files: `era5_w500/z500/z850_seasonal_0p5.npz`, `era5_tmax_seasonal_zim.npz`)
5. `pipeline/analysis.py` ... `analysis5.py`  composites, tests, robustness, timing, circulation, land, maize -> `results_final.json`, `results_station_sens.json`
6. `pipeline/analysis6_extra.py`  NR V gap, sub-periods, index drift -> `results_extra.json`; `pipeline/analysis_sens.py`  station-choice sensitivity -> `results_station_sens.json`
6b. `pipeline/analysis7_yield.py`  FAOSTAT maize yield, area harvested and production check (inputs `derived/FAOSTAT_maize_yield_Zimbabwe_2026-10-22.csv`, `derived/FAOSTAT_maize_area_production_Zimbabwe_2026-10-22.csv`; harvest year H assigned to season onset year H−1) -> `results_yield.json`
7. `figures/fig01.py` ... `fig12.py`, `figS.py`  main and supplementary figures
8. `manuscript_build/make_all.sh`  builds the revised manuscript, supplement, response letter and comparison document; every number in the text is read from the JSON results files.

## Derived data (folder `derived/`)
- `indices_monthly_built.csv`: monthly Niño 3.4 and DMI under each convention
- `season_class_primary.csv`: DJF ONI, SON DMI and category for every season, 1950–2024
- `stations_table.csv`: station inventory with corrected coordinates and allocation
- `qc_log_seasonT.csv`, `qc_log_timing.csv`: values removed by quality control
- `FAOSTAT_maize_*_Zimbabwe_2026-10-22.csv`: FAOSTAT QCL maize yield, area harvested and production for Zimbabwe, downloaded 22 Oct 2026
- `results_*.json`: all statistics quoted in the paper

`exploration/` holds the scripts used to diagnose which index convention reproduces the submitted Table 1.
