"""All numbers used in the manuscript, supplement and response, pulled from the analysis outputs."""
import json, math, pickle
import pandas as pd
A = '/home/claude/analysis/'
R = json.load(open(A + 'results_final.json'))
RS = json.load(open(A + 'results_station_sens.json'))
X = json.load(open(A + 'results_extra.json'))
YD = json.load(open(A + 'results_yield.json'))
ST = pd.read_csv(A + 'stations_table.csv', dtype={'MSD_ID': str})
TC = pd.read_csv(A + 'season_class_primary.csv', index_col=0)
QC = pd.read_csv(A + 'qc_log_seasonT.csv')
QT = pd.read_csv(A + 'qc_log_timing.csv')
M = '−'
NRS = ['I', 'II', 'III', 'IV', 'V']
LAB = {'EN+pIOD': 'El Niño & +IOD', 'EN only': 'El Niño only', 'LN only': 'La Niña only', 'LN+nIOD': 'La Niña & −IOD',
       'Neutral': 'Neutral', 'pIOD only': '+IOD only', 'nIOD only': '−IOD only', 'EN+nIOD': 'El Niño & −IOD',
       'LN+pIOD': 'La Niña & +IOD', 'EN': 'El Niño', 'LN': 'La Niña', 'pIOD': 'Positive IOD', 'nIOD': 'Negative IOD'}

def s(x, d=1, plus=True):
    """signed number with unicode minus"""
    if x is None or (isinstance(x, float) and math.isnan(x)): return 'n/a'
    v = round(x, d)
    if v == 0: return f'{0:.{d}f}'
    t = f'{abs(v):.{d}f}'
    return (M + t) if v < 0 else (('+' + t) if plus else t)
def u(x, d=1): return s(x, d, plus=False)
def a(x, d=1): return f'{abs(x):.{d}f}'
def P(p, italic=True):
    pp = '*p*' if italic else 'p'
    if p is None or (isinstance(p, float) and math.isnan(p)): return f'{pp} = n/a'
    if p < 0.001: return f'{pp} < 0.001'
    if p < 0.0995: return f'{pp} = {p:.3f}'
    return f'{pp} = {p:.2f}'
def Pn(p):  # plain p value for tables
    if p < 0.001: return '<0.001'
    if p < 0.0995: return f'{p:.3f}'
    return f'{p:.2f}'
def Q(q):
    if q < 0.001: return '*q* < 0.001'
    return f'*q* = {q:.3f}' if q < 0.0095 else f'*q* = {q:.2f}'

st = R['st']
def d(cat, nr='Nat'): return st[cat][nr]['d']
def p(cat, nr='Nat'): return st[cat][nr]['p']
def n(cat): return st[cat]['n']
def q(cat, nr): return R['st_fdr'][f'{cat}|{nr}']['q']
def ci(cat, nr='Nat'): return R['st_boot'][cat][nr]
def cis(cat, nr='Nat'):
    lo, hi = ci(cat, nr); return f'95% CI {s(lo,1)} to {s(hi,1)}%'
conv = {c['conv']: c for c in R['conventions']}
thr = R['thr_grid']
chron = R['chron']
T = R['timing']; L = R['land']; Mx = R['mech']; Z = R['maize']; TP = R['temp']; CH = R['chirps']; SP = R['spei']
NS = R['nonstat']; SK = R['skill']; PC = R['pcor']; SEA = R['seasonality']; IN = R['intensity']; TER = R['terciles']
area = {'I': 5372, 'II': 57818, 'III': 64597, 'IV': 115603, 'V': 147935}
nst = ST.NR_poly.value_counts().to_dict()
dens = {k: nst[k] / area[k] * 1e4 for k in NRS}
nr_clim = R['nr_clim']
sig_enp = [nr for nr in NRS if R['st_fdr'][f'EN+pIOD|{nr}']['q'] < 0.05]
spei_r = dict(SP['r_station']); spei_r['V'] = X['spei_r_NRV']
import numpy as _np
_mv = _np.hypot(ST.Longitude - ST.lon_wb, ST.Latitude - ST.lat_wb)
n_register = int((ST.coord_note == 'MSD register').sum()); n_moved02 = int((_mv > 0.2).sum()); n_moved005 = int((_mv > 0.05).sum())
n_realloc = int((ST.NR_poly != ST.NR_msd).sum())
