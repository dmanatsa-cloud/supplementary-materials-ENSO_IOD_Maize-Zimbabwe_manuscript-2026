"""Shared python-docx helpers: JAMC manuscript format (TNR 12 pt, 1.5 spacing, Letter, 1-inch margins,
continuous line numbers, page numbers). Inline markup: *italic*, **bold**, ^superscript^, ~subscript~,
[[HL:text]] yellow highlight (author placeholders), {{c:RRGGBB:text}} coloured text."""
import re
from docx import Document
from docx.shared import Pt, Inches, RGBColor, Emu
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING, WD_COLOR_INDEX, WD_BREAK
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.section import WD_SECTION
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

FONT = 'Times New Roman'

def _set_font(run_or_style, size=12, bold=None, italic=None, color=None):
    f = run_or_style.font
    f.name = FONT; f.size = Pt(size)
    if bold is not None: f.bold = bold
    if italic is not None: f.italic = italic
    if color is not None: f.color.rgb = RGBColor.from_string(color)
    el = run_or_style.element if hasattr(run_or_style, 'element') else run_or_style._element
    rpr = el.get_or_add_rPr()
    rfonts = rpr.find(qn('w:rFonts'))
    if rfonts is None:
        rfonts = OxmlElement('w:rFonts'); rpr.insert(0, rfonts)
    for a in ('w:ascii', 'w:hAnsi', 'w:cs', 'w:eastAsia'): rfonts.set(qn(a), FONT)

def new_doc(line_numbers=True, spacing=1.5):
    d = Document()
    sec = d.sections[0]
    sec.page_width = Emu(12240 * 635); sec.page_height = Emu(15840 * 635)
    for m in ('left_margin', 'right_margin', 'top_margin', 'bottom_margin'): setattr(sec, m, Inches(1))
    st = d.styles['Normal']; _set_font(st, 12)
    pf = st.paragraph_format; pf.line_spacing = spacing; pf.space_after = Pt(0); pf.space_before = Pt(0)
    for name, size in (('Heading 1', 12), ('Heading 2', 12), ('Heading 3', 12)):
        h = d.styles[name]; _set_font(h, size, bold=True, italic=(name == 'Heading 3'), color='000000')
        h.paragraph_format.space_before = Pt(12); h.paragraph_format.space_after = Pt(6)
        h.paragraph_format.keep_with_next = True; h.paragraph_format.line_spacing = spacing
    if line_numbers:
        sp = sec._sectPr; ln = OxmlElement('w:lnNumType')
        ln.set(qn('w:countBy'), '1'); ln.set(qn('w:restart'), 'continuous'); ln.set(qn('w:distance'), '360')
        # lnNumType must precede pgNumType/cols/docGrid etc.; insert after pgMar
        pgmar = sp.find(qn('w:pgMar')); pgmar.addnext(ln)
    z = d.settings.element.find(qn('w:zoom'))
    if z is not None: z.set(qn('w:percent'), '100')
    # page number footer
    fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = fp.add_run(); _fld(r, 'PAGE'); _set_font(r, 11)
    return d

def _fld(run, code):
    b = OxmlElement('w:fldChar'); b.set(qn('w:fldCharType'), 'begin')
    t = OxmlElement('w:instrText'); t.set(qn('xml:space'), 'preserve'); t.text = code
    e = OxmlElement('w:fldChar'); e.set(qn('w:fldCharType'), 'end')
    run._r.append(b); run._r.append(t); run._r.append(e)

TOK = re.compile(r'(\[\[HL:.*?\]\]|\{\{c:[0-9A-Fa-f]{6}:.*?\}\}|\*\*.+?\*\*|\*[^*\s][^*]*?\*|\^[^^]+?\^|~[^~]+?~)')

MINUS = re.compile(r'(?<=[\s(=\[/])-(?=\d)')
def add_runs(p, text, size=12, base_bold=False, base_italic=False, color=None):
    text = MINUS.sub('\u2212', text.replace('\\*', '\u0001'))
    for part in TOK.split(text):
        if not part: continue
        bold, ital, sup, sub, hl, col = base_bold, base_italic, False, False, False, color
        t = part
        if part.startswith('[[HL:'): t = part[5:-2]; hl = True
        elif part.startswith('{{c:'): col = part[4:10]; t = part[11:-2]
        elif part.startswith('**'): t = part[2:-2]; bold = True
        elif part.startswith('*') and part.endswith('*') and len(part) > 2: t = part[1:-1]; ital = not base_italic
        elif part.startswith('^') and part.endswith('^'): t = part[1:-1]; sup = True
        elif part.startswith('~') and part.endswith('~') and len(part) > 2: t = part[1:-1]; sub = True
        if '*' in t and (hl or col):  # allow italics inside highlight/colour
            add_runs_inner(p, t, size, bold, ital, col, hl); continue
        r = p.add_run(t.replace('\u0001', '*')); _set_font(r, size, bold=bold, italic=ital, color=col)
        if sup: r.font.superscript = True
        if sub: r.font.subscript = True
        if hl: r.font.highlight_color = WD_COLOR_INDEX.YELLOW
    return p

def add_runs_inner(p, t, size, bold, ital, col, hl):
    for part in re.split(r'(\*[^*]+\*)', t):
        if not part: continue
        it = ital
        if part.startswith('*') and part.endswith('*'): part = part[1:-1]; it = True
        r = p.add_run(part.replace('\u0001', '*')); _set_font(r, size, bold=bold, italic=it, color=col)
        if hl: r.font.highlight_color = WD_COLOR_INDEX.YELLOW

def para(d, text, indent=True, align='justify', size=12, bold=False, italic=False, color=None, space_after=0, keep=False, spacing=None):
    p = d.add_paragraph()
    pf = p.paragraph_format
    if indent: pf.first_line_indent = Inches(0.3)
    pf.alignment = {'justify': WD_ALIGN_PARAGRAPH.JUSTIFY, 'left': WD_ALIGN_PARAGRAPH.LEFT,
                    'center': WD_ALIGN_PARAGRAPH.CENTER}[align]
    if space_after: pf.space_after = Pt(space_after)
    if keep: pf.keep_with_next = True
    if spacing: pf.line_spacing = spacing
    add_runs(p, text, size=size, base_bold=bold, base_italic=italic, color=color)
    return p

def heading(d, text, level=1):
    h = d.add_heading('', level=level)
    add_runs(h, text, size=12, base_bold=True, base_italic=(level == 3), color='000000')
    return h

def figure(d, path, caption, width=6.5):
    p = d.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.keep_with_next = True; p.paragraph_format.space_before = Pt(6)
    p.add_run().add_picture(path, width=Inches(width))
    c = para(d, caption, indent=False, size=11, space_after=8)
    return c

def _cell_text(cell, text, size=10, bold=False, align='left', color=None):
    cell.text = ''
    p = cell.paragraphs[0]
    p.paragraph_format.line_spacing = 1.0
    p.alignment = {'left': WD_ALIGN_PARAGRAPH.LEFT, 'center': WD_ALIGN_PARAGRAPH.CENTER, 'right': WD_ALIGN_PARAGRAPH.RIGHT}[align]
    add_runs(p, str(text), size=size, base_bold=bold, color=color)

def _borders(tbl, top=True, header_bottom=True, bottom=True):
    """AMS-style rules: top, below header, bottom; no shading, no vertical lines."""
    tblPr = tbl._tbl.tblPr
    b = OxmlElement('w:tblBorders')
    for side in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV'):
        e = OxmlElement(f'w:{side}')
        if side in ('top', 'bottom'):
            e.set(qn('w:val'), 'single'); e.set(qn('w:sz'), '8'); e.set(qn('w:color'), '000000')
        else:
            e.set(qn('w:val'), 'nil')
        b.append(e)
    look = tblPr.find(qn('w:tblLook'))
    if look is not None: look.addprevious(b)
    else: tblPr.append(b)

def table(d, header, rows, caption=None, widths=None, size=10, align=None, note=None, caption_above=True):
    if caption and caption_above:
        c = para(d, caption, indent=False, size=11, space_after=4, keep=True)
    t = d.add_table(rows=1 + len(rows), cols=len(header))
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    _borders(t)
    align = align or (['left'] + ['center'] * (len(header) - 1))
    for j, h in enumerate(header):
        _cell_text(t.rows[0].cells[j], h, size=size, bold=True, align=align[j])
        tcPr = t.rows[0].cells[j]._tc.get_or_add_tcPr()
        bb = OxmlElement('w:tcBorders'); e = OxmlElement('w:bottom')
        e.set(qn('w:val'), 'single'); e.set(qn('w:sz'), '6'); e.set(qn('w:color'), '000000'); bb.append(e); tcPr.append(bb)
    # repeat header row
    trPr = t.rows[0]._tr.get_or_add_trPr(); th = OxmlElement('w:tblHeader'); th.set(qn('w:val'), 'true'); trPr.append(th)
    for i, r in enumerate(rows):
        for j, v in enumerate(r):
            _cell_text(t.rows[i + 1].cells[j], v, size=size, align=align[j])
    if widths:
        tot = sum(widths); t.autofit = False
        tw = [int(6.5 * 1440 * w / tot) for w in widths]
        grid = t._tbl.tblGrid
        for j, gc in enumerate(grid.findall(qn('w:gridCol'))): gc.set(qn('w:w'), str(tw[j]))
        tblPr = t._tbl.tblPr
        for row in t.rows:
            for j, w in enumerate(widths):
                row.cells[j].width = Inches(6.5 * w / tot)
    if note:
        para(d, note, indent=False, size=10, space_after=10, spacing=1.0)
    else:
        d.add_paragraph()
    return t

def page_break(d):
    d.add_paragraph().add_run().add_break(WD_BREAK.PAGE)
