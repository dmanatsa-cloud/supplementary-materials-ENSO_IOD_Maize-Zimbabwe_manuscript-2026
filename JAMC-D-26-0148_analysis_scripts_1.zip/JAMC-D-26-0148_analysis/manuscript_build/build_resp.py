import sys; sys.path.insert(0, '/home/claude/ms')
from vals import *
from docbuild import *
from loc import L, S, SECS
OUT = '/home/claude/ms/out/JAMC-D-26-0148_response_to_reviewers.docx'
BLUE = '1F4E79'
EP, EO, LO, LM = 'EN+pIOD', 'EN only', 'LN only', 'LN+nIOD'
c = conv
sub = X['subperiod_comp']

d_ = new_doc(line_numbers=False, spacing=1.15)
def C(t):  # reviewer comment, verbatim, black
    para(d_, t, indent=False, space_after=4)
def Rr(t):  # response, blue
    para(d_, '**Response.** ' + t, indent=False, color=BLUE, space_after=4)
def Lc(t):  # location, blue italic
    para(d_, '*Location:* ' + t, indent=False, color=BLUE, space_after=10)
def Hd(t, lvl=1): heading(d_, t, lvl)

para(d_, '**Response to the Editor and Reviewers**', indent=False, align='center', size=13)
para(d_, 'Manuscript JAMC-D-26-0148, “Compound hot-dry drought from co-occurring El Niño and Indian Ocean Dipole events in Zimbabwe: mechanisms, maize impacts, and implications for seasonal forecasting”', indent=False, align='center', space_after=4)
para(d_, '[[HL:Date of resubmission]]', indent=False, align='center', space_after=12)
para(d_, 'Dear Dr. Rozoff,', indent=False, space_after=6)
para(d_, 'Thank you for handling our manuscript and for the three constructive reviews. We have revised the manuscript thoroughly. '
         'Reviewer comments are reproduced below in black. Our responses follow each comment in blue, with the location of each change. '
         'Line numbers refer to the clean revised manuscript with continuous line numbering. Because most paragraphs were rewritten, we also supply a comparison document that marks the changes against the submitted version.', indent=False, space_after=6)
para(d_, 'In addressing Reviewer 1’s request to document the climate indices, we rebuilt the Niño 3.4 and Dipole Mode indices from the ERSSTv5 SST field and reran every analysis from the raw station records. '
         'This process exposed several errors in the submitted analysis. We have corrected them and describe them openly in the next section, because some conclusions changed. '
         'We are grateful to the reviewers: their requests led directly to a more reliable paper.', indent=False, space_after=10)

Hd('Summary of the main changes')
items = [
 f"**Indices rebuilt and documented** (Reviewer 1). Both indices are now computed from the ERSSTv5 field with the NOAA CPC moving 30-year base, with all regions, base periods, trend treatment and averaging months stated ({S('2.6')}). "
 f"The submitted classification corresponds most closely to the KNMI default of a fixed 1981–2010 base without detrending (65 of 67 ENSO phases and 62 of 67 IOD phases agree). Under that convention the indices drift with the long-term warming: the fixed-base SON DMI rises by {X['dmi_trend']['fixed8110_per_decade']:.2f} °C per decade, and the fixed-base DJF Niño 3.4 averages {s(X['dmi_trend']['n34_fixed_mean_1951_1980'],2)} °C over 1951–1980. "
 "The revised classification changes 18 of the 67 seasons of 1951–2017 (Table S1).",
 "**Results reorganised by Natural Region** (Reviewer 3). Every Results section that the data allow now reports the Natural Region values first and the national value as a synthesis.",
 f"**Station data corrected and documented** (Reviewer 3). Station coordinates now come from the MSD station register ({n_moved02 - 1} archive positions were off by more than 0.2°), allocation to Natural Region polygons changed for {n_realloc} stations, quality control removed five implausible seasonal totals and one station’s timing record, and the construction of the regional series is fully described ({S('2.2')}; Tables S5–S7; Fig. S2).",
 f"**Robustness** (Reviewers 1 and 3). A tercile classification (Ficchì et al., 2021), a threshold grid, ten index conventions and eight station or dataset choices are reported ({S('3.5')}; Fig. 5; Tables S2–S4). "
 "El Niño & +IOD remains the driest state, and drier than El Niño only, under all of them. The significance of the co-occurrence deficit is not: it depends on the base period. We now say so in the abstract, Results and Discussion.",
 f"**New analyses** (Reviewers 2 and 3): confounding of the IOD with El Niño strength ({S('3.4')}); sub-period nonstationarity ({S('3.6')}); Botswana High and Angola Low indices and regional circulation maps ({S('3.8')}; Fig. 7; Table 3); timing by Natural Region with station spread ({S('3.11')}; Table 4; Table S11); SPEI-6, land surface and CHIRPS by Natural Region; FAOSTAT maize yield, area harvested and production as a check on the USDA series ({S('3.13')}; Fig. 12).",
 "**Datasets**. Versions and resolutions are stated for every dataset. CRU TS was replaced by ERA5 as the second temperature dataset. The SPEI product is now correctly identified as ERA5–Drought (Keune et al., 2025).",
 "**Title**. We propose a modified title that reflects the Natural Region focus and replaces “mechanisms” with “circulation”, in line with Reviewer 3’s request to temper causal language: “Compound hot–dry drought during co-occurring El Niño and positive Indian Ocean Dipole seasons in Zimbabwe’s agroecological Natural Regions: circulation, maize impacts, and implications for seasonal forecasting.” We are happy to revert to the original title if the Editor prefers.",
]
for k, t in enumerate(items, 1): para(d_, f'{k}. ' + t, indent=False, space_after=4)

Hd('Errors found during revision and how the conclusions changed')
para(d_, 'We list these here so that the Editor and reviewers can see exactly what changed and why.', indent=False, space_after=4)
err = [
 f"**Index convention.** As described above. With the revised indices, 1987 and 1991 move from El Niño with a positive IOD to El Niño only (SON DMI 0.31 and 0.36 °C), and the counts become 24 El Niño, 23 La Niña, 11 positive IOD and 11 negative IOD seasons (previously 18, 27, 17 and 10). The El Niño & +IOD national deficit is {s(nat_ := d(EP))}% relative to neutral ({P(p(EP), False)}), close to the submitted −22.2%. Under the fixed 1981–2010 base it is {s(c['f8110']['d'])}% ({P(c['f8110']['p'], False)}), which we report.",
 f"**Station positions and allocation.** Station coordinates now come from the MSD station register for the {n_register} archive stations it lists. The archive positions of {n_moved02 - 1} of these were off by more than 0.2°, several by enough to place the station at another town (for example Nyanga at Mvurwi and Rusape at Mvuma). The submitted allocation had been reconstructed without the shapefile; allocation by the actual polygons moves {n_realloc} stations. NR V now has {nst['V']} stations instead of 3, and its mean rainfall is {nr_clim['V']:.0f} mm rather than 445 mm.",
 "**Quality control.** Two seasonal totals about ten times the station normal (Belvedere and Kwekwe, 2014; apparently misplaced decimal points) and three totals below 50 mm (Gweru 1958, Rusape 1974, Kezi 1987) were removed. The Lupane timing record, in which onset follows cessation in 30 seasons, was removed (Table S7).",
 "**NR V coverage.** NR V has no reporting station before 1959. This is now stated, and the national series for 1951–1958 is the mean of NR I–IV. Results starting in 1959 are reported (Table S2).",
 "**Maize mapping.** The USDA series changes its year convention at 2000 (the values labelled 1999 and 2000 are identical). Each value is now mapped explicitly to its growing season (section 2.5). With the corrected mapping, the submitted conclusion that ENSO carries all of the unique production signal no longer holds: ENSO and the IOD explain similar unique fractions of production (6.3% and 5.3%) and a larger shared fraction (15.6%). "
 f"We added FAOSTAT yield as an independent check (section 2.5). It confirms the co-occurrence loss ({s(YD['vs_neu'][EP]['d'])} points relative to neutral, {P(YD['vs_neu'][EP]['p'])}) but gives ENSO the larger unique share ({100*YD['uniq_enso']:.1f}% against {100*YD['uniq_iod']:.1f}%), and FAOSTAT area harvested shows no climate signal, so the loss is a loss of yield. The paper now describes the attribution between the modes as uncertain and emphasises the shared variance. [[HL:Authors to confirm how the harvest years were keyed in the submitted analysis, so that this sentence describes it exactly.]]",
 f"**“Replanting buffer”.** The submitted argument that early-season failures are buffered by replanting is not supported: late onset is associated with lower production (r = {s(Z['links']['SOS']['r_yield'],2)}, {P(Z['links']['SOS']['p_yield'])}). The argument was removed.",
 f"**“The IOD governs onset”.** With the revised data, onset tracks ENSO (partial r = {PC['SOS']['enso']['r']:.2f}, {P(PC['SOS']['enso']['p'])}) more than the IOD ({PC['SOS']['iod']['r']:.2f}, {P(PC['SOS']['iod']['p'])}). The IOD signature is clearest in December dry spells. The text was revised accordingly.",
 f"**El Niño with a neutral IOD.** Over the full record these seasons show no deficit, but since 1983 they have been substantially dry ({s(sub['1983-2017']['EN only'][1])}%, n = 5), and 1991/92, the most severe drought, is now an El Niño only season. The co-occurrence seasons were also the stronger El Niño events. The submitted recommendation that El Niño alone “should not, by itself, trigger a severe drought outlook” was withdrawn, and the positive IOD is described as a marker of the most severe El Niño seasons rather than as the single cause.",
 "**2023/24 rank.** CHIRPS ranks 2023/24 as the second driest season (−29.8%), after 1991/92 (−41.0%), not the driest. Corrected.",
 "**Regional scaling.** The submitted Discussion stated that the wetter regions are the most exposed. The revised data show no scaling with mean rainfall; NR III and NR V lose the largest fractions. Corrected.",
 "**Figure 4 caption** referred to “Met Office zonal rainfall”, a dataset not used. Corrected (Reviewer 3, L292).",
]
for t in err: para(d_, '• ' + t, indent=False, space_after=3)
para(d_, '', indent=False)

# =============================================================== EDITOR
Hd('Editor')
C('Along with your revision, please upload a point-by-point response that satisfactorily addresses the concerns and suggestions of each reviewer and the Editor.')
Rr('Done. This document responds to every comment. Changes in the manuscript are indicated by section and line number.')
Lc('Throughout.')

# =============================================================== REVIEWER 1
Hd('Reviewer 1')
C('This study quantifies the individual and combined influences of ENSO and the IOD on seasonal rainfall variability and compound hot-dry drought conditions in Zimbabwe, and their effects on regional maize yields. The paper classifies events based on the ONI and DMI indices, uses composites, and applies statistical analyses to precipitation, temperature, SPEI-6, and atmospheric circulation variables, drawing on station data, gridded datasets, and reanalysis. The statistical analysis is rigorous and well suited to the small sample sizes of ENSO and IOD events and their combinations available in the observational period. Furthermore, the results are presented in a clear and transparent manner, and the authors acknowledge the limitations of the methodologies used. The analysis of multiple variables and different datasets allows the authors to draw solid conclusions, with consistent results across datasets. I really like how the work highlights practical implications and recommends practices for operational users. However, the manuscript needs some corrections.')
Rr('We thank the reviewer for the positive assessment and for the major comment on the indices, which led us to rebuild and document the classification and to correct the errors listed above.')
Lc('See the responses below.')

Hd('Major comments', 2)
C('Although the ONI and DMI indices are publicly available via the KNMI Climate Explorer, critical details regarding their calculation, preprocessing, and definitions are missing. Furthermore, the KNMI Climate Explorer allows users to choose different settings, but the choices made by the authors are not specified in the manuscript. Because these indices are fundamental to all subsequent analyses, the information and criteria used to calculate them should be clearly described.')
Rr('We agree completely. Rather than describe the settings used for the pre-computed series, we rebuilt both indices from the ERSSTv5 SST field so that every choice is explicit and reproducible. '
   'Section 2.6 now gives the regions, the base period, the trend treatment and the averaging months for both indices, and the sensitivity to each choice is reported. The monthly index series and the season classification are provided with the data (Data availability statement).')
Lc(f"{S('2.6')}; Data availability statement ({L('ERSSTv5 and HadISST1 SST and the derived')}).")
C('- The manuscript does not specify the reference periods used to calculate SST anomalies for either index.')
Rr('Anomalies now follow the NOAA CPC convention for the Oceanic Niño Index: each five-year block is referenced to a centred 30-year base (for example, 1956–1960 to 1941–1970), and 1991–2020 is used from 2011 onward. '
   'The same moving base is applied to each of the two DMI boxes; blocks before 1966 use 1950–1979, the earliest 30 years in the field. '
   f"Fixed 1981–2010 and 1991–2020 bases are reported as sensitivity tests. The co-occurrence deficit is {s(c['roll']['d'])}% with the moving base ({P(c['roll']['p'])}), {s(c['f9120']['d'])}% with the fixed 1991–2020 base ({P(c['f9120']['p'])}) and {s(c['f8110']['d'])}% with the fixed 1981–2010 base ({P(c['f8110']['p'])}). "
   'We chose the moving base a priori, as the operational CPC convention, and not because it gives the largest effect.')
Lc(f"Section 2.6, {L('Anomalies follow the convention of the NOAA', 'preserving interannual variability.')} and {L('The moving 30-year base is applied separately', 'No additional detrending is applied.')}; Section 3.5, {L('The deficit is significant with the moving base', 'the fixed 1991–2020 base gives a larger one.')}; Table S2; Fig. 5b.")
C('- The manuscript does not specify how the trend was treated during preprocessing. Was the trend filtered out? Was the SST trend removed before calculating the indices, or was the trend removed from the indices after they were calculated? In the case of the DMI, was the trend removed separately from the SST anomalies in each of the two Indian Ocean boxes before calculating their difference?')
Rr('In the primary analysis no trend is fitted. The moving 30-year base removes the slow warming from the anomalies while preserving interannual variability. '
   'As sensitivity tests we (i) removed a linear trend from the SST anomalies of each Indian Ocean box separately before taking the difference, and (ii) removed a linear trend from the DMI after taking the difference. '
   'For a linear trend fitted over the same period the two are equivalent, because the difference of two least-squares lines is the least-squares line of the difference; the classifications are identical, as expected (Table S2). '
   f"The test showed why trend treatment matters here. With a fixed base and no detrending, the SON DMI rises by {X['dmi_trend']['fixed8110_per_decade']:.2f} °C per decade, from {s(X['dmi_trend']['fixed_mean_1951_1980'],2)} °C in 1951–1980 to {s(X['dmi_trend']['fixed_mean_1995_2024'],2)} °C in 1995–2024, which pushes early seasons towards negative IOD and recent seasons towards positive IOD. "
   f"With the moving base the trend is {X['dmi_trend']['roll_per_decade']:.2f} °C per decade and not significant. With linearly detrended boxes the co-occurrence deficit is {s(c['detr_boxes']['d'])}% ({P(c['detr_boxes']['p'])}).")
Lc(f"Section 2.6, {L('The moving 30-year base is applied separately', 'No additional detrending is applied.')} and {L('*Sensitivity.*'.replace('*',''), 'from the index); the HadISST1 DMI')}; Section 3.5, {L('Under a fixed base without detrending', 'not significant.')}; Table S2; Fig. S3.")
C('- The manuscript should also specify the region of the Pacific Ocean covered by the Niño 3.4 index.')
Rr('Added: 5°N–5°S, 170°–120°W, from ERSSTv5 at 2° resolution, averaged over December–February.')
Lc(f"Section 2.6, {L('The Niño 3.4 index is the area-mean SST anomaly')}.")
C('- The manuscript does not describe the DMI definition used or specify the boundaries of the two boxes in the Indian Ocean.')
Rr('Added. The DMI follows Saji et al. (1999): the western tropical Indian Ocean (50–70°E, 10°S–10°N) minus the southeastern tropical Indian Ocean (90–110°E, 10°S–0°), both cosine-latitude weighted and taken from the same ERSSTv5 field, averaged over September–November.')
Lc(f"Section 2.6, {L('The DMI follows Saji et al. (1999)', 'the same ERSSTv5 field.')}.")
C('Specifying these details is particularly important for the DMI, since it is very sensitive to the dataset used, the reference period, the treatment of the trend, and the temporal scale used (e.g., 1-month or 3-month values). This is well documented in Verdon-Kidd (2018).')
Rr('We thank the reviewer for the reference, which we now cite in the Introduction, Methods and Discussion. Following it, we report the sensitivity to each of these four factors: dataset (HadISST1 versus ERSSTv5), reference period (moving, 1981–2010 and 1991–2020), trend treatment (none, per box, on the index) and temporal scale (September, October and November single months, August–October and September–November means). '
   f"Across these conventions the co-occurrence deficit ranges from {s(max(x['d'] for x in R['conventions']))}% to {s(min(x['d'] for x in R['conventions']))}%, while the El Niño only composite ranges from {s(max(x['d_en'] for x in R['conventions']))}% to {s(min(x['d_en'] for x in R['conventions']))}% and is never significant. "
   f"The co-occurrence state is the driest under every convention, but its deficit is significant at the 5% level in only some of them (moving base, fixed 1991–2020 base, September, November and August–October DMI) and not in others (fixed 1981–2010 base, detrended boxes, HadISST1, October DMI). "
   'This is exactly the sensitivity Verdon-Kidd (2018) describes, and we now present the robust finding as the ordering of the El Niño states rather than a single effect size.')
Lc(f"Introduction, {L('A further obstacle is reproducibility.', 'Kidd, 2018).')}; Section 2.6, {L('*Sensitivity.*'.replace('*',''), '(Fig. S3; Tables S2 and S3).')}; Section 3.5, {L('The ordering of the two El Niño states is robust; the significance', 'not because it gives the largest effect')}; Discussion, {L('The robustness analysis changes how the central result', 'not a single effect size, as the robust finding.')}; Fig. 5b; Table S2; Fig. S3.")
C('Also, please add a reference to support the statement that the IOD peaks in SON.')
Rr('Added Saji et al. (1999) and Saji and Yamagata (2003), with a sentence on why the IOD decays after November.')
Lc(f"Introduction, {L('It grows during austral winter', 'Saji and Yamagata, 2003).')}; Section 2.6, {L('The DMI is averaged over September–November (SON)', 'Saji and Yamagata, 2003).')}.")

Hd('Minor comments: general points', 2)
C('- Reference the figures more consistently and clearly in the text. At the beginning of the manuscript, figures are correctly referenced when the text describes them or refers to something in them. However, later on, the text simply refers to “Figure X” at the beginning of a section without specifying the relevant panels (e.g., Figure Xa) when presenting the results. This makes the manuscript quite difficult to read.')
Rr('Thank you. Every result in Section 3 now cites the specific panel it comes from (for example Fig. 3a,c; Fig. 5b; Fig. 7d), and all captions describe each panel.')
Lc(f"{S('3')}; all figure captions.")
C('- Make more references to the supplementary information where relevant. As in the previous comment, results and conclusions are mentioned in several places without referring to the supplementary information. It is therefore unclear whether these results are not presented in figures or tables or are simply not shown.')
Rr('The supplement was rebuilt as Tables S1–S13 and Figs. S1–S4, and the text now cites the relevant supplementary item wherever a result is not shown in a main figure or table (for example the full composites with *p*, *q* and confidence intervals in Table S8, CHIRPS by region in Table S9, partial correlations in Table S10, timing spread in Table S11, and circulation and maize regressions in Table S13). No result in the revised text is “not shown”.')
Lc('Sections 2 and 3, wherever a supplementary table or figure is cited; Supplementary Material.')
C('- SPEI is often used instead of SPEI-6. Please correct this throughout the manuscript.')
Rr('Corrected. The index is called SPEI-6 throughout. “SPEI” appears only where the generic index family or the dataset name is meant (for example “the ERA5–Drought SPEI” in the Data availability statement).')
Lc('Throughout.')

Hd('Minor comments: specific', 2)
C('- Lines 58-63: The effects of the IOD in the study region are not specified. What does each phase of the IOD do in the study region?')
Rr('Added. A positive IOD (warm west, cool east) shifts convection and moisture convergence towards the western basin and East Africa and has been associated with reduced rainfall and drought over Zimbabwe, particularly early in the season; a negative IOD tends to bring wetter conditions (Manatsa et al., 2008; Manatsa and Matarira, 2009). Our own results for each phase are given in Section 3.2 and Table 2.')
Lc(f"Introduction, {L('During a positive IOD the western basin', 'Manatsa and Matarira, 2009).')}; Section 3.2, {L('The individual modes show the same geography', 'wetter.')}; Table 2.")
C('- Lines 139-140: This repeats information from line 129. Please remove the redundant information.')
Rr('Removed. The national series is now defined once.')
Lc(f"Section 2.2, {L('The national series is the unweighted mean', 'mean of NR I–IV.')}.")
C('- Lines 140: SPEI-6 has not been defined in the text yet. I think it should only be introduced on line 146, since that section deals with droughts.')
Rr('Agreed. SPEI-6 is now introduced only in the drought paragraph of Section 2.4.')
Lc(f"Section 2.4, {L('*Drought.*'.replace('*',''), 'by region.')}.")
C('- Lines 149-150: This repeats information from line 140. I think this information should only be included')
Rr('Removed. The masking of SPEI-6 to the Natural Regions and the choice of the March value are stated once.')
Lc(f"Section 2.4, {L('We take the March value of SPEI-6')}.")
C('- Lines 156-157: The information about CHIRPS feels out of place here. Why not move it to Section 2.2, where the dataset is first introduced?')
Rr('Agreed. All information on CHIRPS, including its version and resolution, is now in one place, the rainfall paragraph of Section 2.4 (“Gridded rainfall”). Section 2.2 now deals only with the station data, and the daily CHIRPS onset definition is with the other timing definitions in Section 2.3.')
Lc(f"Section 2.4, {L('*Rainfall.*'.replace('*',''), 'extend the analysis to 2024 (section 3.12).')}; Section 2.3, {L('As an independent check we derived onset', 'less than 1 mm.')}.")
C('- Lines 175-176: This repeats information from the same paragraph.')
Rr('Removed. The averaging windows of the two indices are stated once, and the order of the two windows (SON precedes DJF) is made explicit.')
Lc(f"Section 2.6, {L('SON lies in the onset year', 'rainfall season.')}.")
C('- Lines 198-202: The entire paragraph repeats information from Section 2.2 and the first paragraph of Section 2.5. Please reorganize this and clarify where the corresponding information should go.')
Rr('Reorganised. Season timing now has its own Methods subsection (Section 2.3), which defines SOS, EOS and LOS, explains how station departures are composited, and describes the cessation bound. The statistical tests are described only in Section 2.7.')
Lc(f"{S('2.3')}; {S('2.7')}.")
C('- Lines 209-210: Poorly phrased sentence. Please correct the punctuation and rephrase (e.g., “Pure events, in which one mode is active while the other is neutral, are...”).')
Rr('Thank you. The paragraph was rewritten. Categories are now named consistently (for example “El Niño only” for El Niño with a neutral IOD), and the sentence no longer exists in its old form.')
Lc(f"Section 3.1, {L('The populated combinations are El Niño with a positive IOD', '(Fig. 2b).')}.")
C('- Lines 253: There is a typo in the caption: “Australian summer maximum-temperature anomalies..”')
Rr('Corrected. The temperature panel is now Fig. 6a, and its caption reads “Detrended DJF maximum temperature over Zimbabwe by state”. CRU TS was replaced by ERA5 as the second dataset (Section 2.4).')
Lc(f"Fig. 6 caption ({L('Compound hot–dry conditions. (a) Detrended DJF')}); Section 2.4, {L('*Temperature.*'.replace('*',''), 'does not depend on station density.')}.")

# =============================================================== REVIEWER 2
Hd('Reviewer 2')
C('The manuscript ... addresses a relevant topic in agrometeorology and climatology, with important implications for understanding climate variability and its impacts on agricultural systems of Zimbabwe and Southern Africa Development Community (SADC) region in general. The study is generally well structured, and the methodology. I considered it adequately described, particularly regarding the use of observational data from Meteorological Services Department, reanalysis data from ERA5-Land), and remote sensing datasets ((CHIRPS; CRU TS 4.08; United States Department of Agriculture estimates; USDA). The results are clearly presented and discussed in relation to previous studies conducted in the region.')
Rr('We thank the reviewer for this assessment. We note that CRU TS 4.08 has been replaced by ERA5 in the revision, for the reason given in Section 2.4.')
Lc(f"Section 2.4, {L('The CRU TS dataset used in the submitted version', 'does not depend on station density.')}.")
C('However, the scientific novelty of the study requires further clarification. My main concern is the scientific novelty of the study. The combined influence of ENSO and the Indian Ocean Dipole (IOD) on southern African rainfall has been examined in previous research conducted in the SADC region, including Ropelewski and Halpert (1987), Nicholson and Kim (1997), Manatsa and Matarira (2009), Reason et al. (2000), and Williams and Hanan (2011). The manuscript should therefore state more explicitly what new scientific insight it provides beyond existing studies. The supplementary material strengthens the methodological documentation and the robustness of the analyses, but it does not, by itself, establish the originality of the contribution.')
Rr('We agree that the contribution needed to be stated explicitly. The Introduction now reviews the studies the reviewer lists and identifies three gaps: (i) previous work analysed national or area-averaged rainfall and does not show how the joint signal differs between the Natural Regions in which agricultural decisions are made; '
   '(ii) previous work did not contrast El Niño seasons with and without a positive IOD against a common neutral baseline, test formally for interaction, or separate the IOD effect from El Niño strength; and (iii) the joint signal had not been traced within one consistent, reproducible classification from rainfall through temperature, drought, timing and circulation to maize. '
   'A final Introduction paragraph lists the contributions, and the first paragraph of the Discussion states what the study adds. '
   'The new findings that go beyond earlier work are: the co-occurrence deficit by Natural Region, with its largest relative impact in NR III and NR V rather than in the wettest regions; the demonstration that the modes add rather than interact; the confounding of the IOD effect with El Niño strength; the narrowing of the IOD contribution since the early 1980s, which extends the nonstationarity analysis of Manatsa and Matarira (2009); the coincidence of the co-occurrence state with descent from October and a stronger Botswana High that adds no rainfall information beyond the modes; and the sensitivity of the result to index conventions.')
Lc(f"Introduction, {L('The combined influence of ENSO and the IOD on southern African rainfall has been examined before.', 'Kidd, 2018).')} and {L('This study addresses these gaps for Zimbabwe.', 'detects at least as well as rainfall.')}; Discussion, {L('The study adds three things', 'reported in full.')}.")
C('In particular, the authors should more explicitly identify the research gap addressed by the manuscript and explain how the combined analysis of ENSO and the Indian Ocean Dipole (IOD) advances current scientific understanding beyond previous studies. Furthermore, a clearer discussion of the methodological limitations, underlying assumptions, and uncertainties would strengthen the interpretation of the results.')
Rr('The research gaps are addressed in the previous response. The limitations paragraph of the Discussion was expanded into nine explicit items: sample size; classification sensitivity; confounding with ENSO strength and nonstationarity; the station network and the assumption behind the representative series; season-timing definitions and the cessation bound; the partial dependence between datasets; the associative nature of the circulation diagnostics; the national, non-climatic character of the maize series; and other drivers not considered. '
   f"For the maize analysis we also added FAOSTAT yield, area harvested and production as an independent check on the USDA series: they confirm the co-occurrence loss, show that it is a loss of yield rather than of harvested area, and show that the split of the signal between ENSO and the IOD depends on the series used (Section 3.13). "
   'Uncertainty is also quantified in the Results: bootstrap confidence intervals and FDR-adjusted *q* values for every regional composite (Table S8), the convention and threshold sensitivity (Section 3.5), and sub-period results (Section 3.6).')
Lc(f"Discussion, {L('Several assumptions and limitations qualify the results.', 'may modulate the response.')}; Sections 3.5 and 3.6; Table S8.")
C('Overall, I consider the manuscript scientifically relevant and potentially suitable for publication, provided that its original contribution is more clearly established and its limitations are more fully discussed. My recommendation is minor revision.')
Rr('Thank you. We hope the revised Introduction, Discussion and limitations meet these requests.')
Lc('See above.')

# =============================================================== REVIEWER 3
Hd('Reviewer 3')
C('This study is timely and highly relevant to all readers, especially in light of the impending ENSO and IOD states, which this research demonstrates have significant impacts on maize production in Zimbabwe. I have provided detailed comments that, once incorporated, will strengthen the manuscript’s clarity, scientific rigor, and practical relevance.')
Rr('We thank the reviewer for the detailed and constructive comments. They led to a reorganised Results section and to several new analyses.')
Lc('See below.')
Hd('Overall assessment and results structure', 2)
C('The manuscript provides valuable insights into the influence of ENSO and the IOD on Zimbabwe’s seasonal rainfall and drought risk, with a focus on agroecological Natural Regions (NRs). However, the presentation of the results would benefit substantially from a clearer and more logically structured narrative that respects the spatial heterogeneity intrinsic to Zimbabwe’s climate and agricultural zones. Currently, the paper presents national aggregate rainfall and drought metrics prior to the detailed NR results. ... the results section should lead with the NR analyses. ... The national aggregates should then be shown as a synthesis of these spatial patterns, providing a comprehensive overview.')
Rr('Agreed and done. After the chronology (Section 3.1), the Results open with the rainfall response in each Natural Region (Section 3.2; Fig. 3; Table 2), followed by the national synthesis (Section 3.3; Fig. 4). '
   'The later sections also report Natural Region values first wherever the data allow: SPEI-6 and the detection gain (Section 3.7; Fig. 6c; Table S12), the land surface (Section 3.9; Fig. 8), season timing (Section 3.11; Table 4; Table S11), CHIRPS (Section 3.12; Fig. 11; Table S9) and the monthly evolution (Fig. S4). '
   'Two diagnostics remain national: maximum temperature, because a 1° grid does not resolve the small NR I, and maize, because production data are not available by region. These are stated as limitations.')
Lc(f"{S('3.2')}; {S('3.3')}; Sections 3.7, 3.9, 3.11 and 3.12; Discussion, {L('The regional results have direct agricultural meaning.', 'the least certain.')}.")
Hd('Methodological clarity and reproducibility', 2)
C('- The method for constructing the representative regional rainfall series from station data, including normalization, averaging, and compositing across NRs should be fully described within the Methods section before any related figures (e.g., Figure 1) are presented. ... Relocating such figures to the Results section, after methodological explanations, would help maintain a logical order.')
Rr('Done. Section 2.2 now describes the station normals, the normalisation, the averaging over reporting stations, the rescaling, the national series and the coverage flag. '
   'The submitted Figure 1, which showed the co-occurrence deficit by region, has moved to the Results as Fig. 3a. The new Fig. 1 shows only the Natural Regions, the corrected station positions, the station counts, the areas and the mean rainfall, so it contains no results.')
Lc(f"Section 2.2, {L('*Representative series.*'.replace('*',''), 'sensitivity of the main result to these choices.')}; Fig. 1; Fig. 3.")
C('- Detailed information should be provided on station density and distribution within each NR, ideally as a figure or table in the Supplementary Material, considering the varying spatial extent and heterogeneity of the zones. Similarly, explicit definitions and calculation methods for season onset (SOS), cessation (EOS), and length (LOS) with associated uncertainties or station-level variability should be stated to strengthen rigor and reproducibility.')
Rr('Station density and distribution: Fig. 1 maps all 46 stations at their corrected positions, and its legend gives the number of stations, area and mean rainfall of each region. Table S5 lists every station with coordinates, region and record length, Table S6 gives density and reporting statistics, and Fig. S2 shows the number of reporting stations in each season. '
   'Timing definitions and uncertainty: Section 2.3 now states the MSD operational definitions. Onset is the first day after 1 October with at least 20 mm of rain within one to three consecutive days, provided that no dry spell of ten or more days follows in the next 30 days. '
   'Cessation comes from a daily soil-water balance: searching forward from 15 February, it is the first day on which plant-available soil water falls to zero without replenishment (or actual evapotranspiration falls below 35–40% of reference evapotranspiration). LOS is the number of days between onset and cessation. '
   f"As a check, we applied the same onset criterion to daily CHIRPS rainfall; CHIRPS onset correlates with station onset at r = {R['daily']['r_onset_station']:.2f} over 1981–2017. "
   'Section 2.3 also explains how the timing variables are composited.Results now include bootstrap confidence intervals, regional composites (Table 4), and the station-level spread as interquartile ranges and the fraction of stations with a later onset or shorter season (Fig. 10b; Table S11).')
Lc(f"Section 2.2, {L('*Station positions and allocation.*'.replace('*',''), 'NR V has no reporting station before 1959.')}; {S('2.3')}; Section 3.11, {L('Over 1951–2017 the mean national season starts', 'grain fill.')}; Fig. 1; Fig. 10b; Tables 4, S5, S6 and S11; Fig. S2.")
C('- The use of ENSO and IOD classification thresholds leads to uneven sample sizes of event years, which could bias composite results. Implementing or comparing a tercile-based classification system (e.g., Ficchi et al., 2021) that balances sample sizes should be considered or at least discussed as a sensitivity check.')
r = TER['warm|pos']; tm = R['tercile_marg']
Rr(f"Done. Seasons are also classified by terciles of the DJF ONI and SON DMI over 1951–2017 (Ficchì et al., 2021), which gives 22–23 seasons in each marginal category. "
   f"The marginal tercile composites confirm the threshold results: warm-ONI seasons are {a(tm['warm ONI']['d'])}% drier than other seasons ({P(tm['warm ONI']['p'])}) and positive-DMI seasons {a(tm['pos DMI']['d'])}% drier ({P(tm['pos DMI']['p'])}). "
   f"The joint warm/positive cell (n = {r['n']}) is {a(r['vs_mid']['d'])}% drier than the middle/middle cell ({P(r['vs_mid']['p'])}) and drier in every region. "
   "We also note a limitation: because the two indices are correlated (r = 0.52), equal margins cannot give equal joint cells, so the tercile approach balances the individual-mode samples but not the co-occurrence samples.")
Lc(f"Section 2.6, {L('Fixed thresholds give unequal sample sizes.', 'shows where the seasons fall (Table S4).')}; Section 3.5, {L('The tercile classification balances the marginal samples', 'correlation.')}; Fig. 5c; Table S4.")
C('- The spatial resolution and version numbers of datasets like CHIRPS must be clearly indicated to ensure reproducibility.')
Rr('Added for every dataset: CHIRPS v2.0 (0.25° aggregation of the native 0.05° product; with our reason for using v2.0 rather than v3.0), ERSSTv5 (2°), HadISST1, ERA5 (0.25°; pressure levels regridded to 0.5°), ERA5-Land, ERA5–Drought SPEI-6 (0.25°, 1991–2020 reference) and Berkeley Earth (1°).')
Lc(f"{S('2.4')}; Section 2.6, {L('(ERSSTv5, 2° resolution; Huang et al., 2017)')}.")
C('- The paper would benefit from integrating relevant regional climate drivers such as the Angola Low and Botswana High, and their interaction with ENSO and IOD, to frame the findings in the broader climatological context of Southern Africa [L63-64]. Including references to relevant studies (e.g., Munday and Washington 2016; Blamey et al. 2018) would also improve the Introduction.')
Rr(f"Done in three places. The Introduction has a new paragraph on the Angola Low and Botswana High and their links to ENSO (Munday and Washington, 2017; Howard and Washington, 2018; Driver and Reason, 2017; Blamey et al., 2018). The paper by Munday and Washington with DOI 10.1002/2016JD025736 appeared in 2017, so we cite it with that year. "
   f"We then built a Botswana High index (Z500) and an Angola Low index (Z850) from ERA5 (Section 2.4). In co-occurrence seasons the Botswana High index is {a(Mx['BH'][EP]['d'])} m higher than in neutral seasons ({P(Mx['BH'][EP]['p'])}) and the Angola Low index {a(Mx['AL'][EP]['d'])} m higher (a weaker low), about twice the El Niño only anomalies. "
   f"Both indices correlate with rainfall, but they are closely tied to ENSO (r = {Mx['BH_r_oni']:.2f} and {Mx['AL_r_oni']:.2f} with the ONI), and added to the ONI and DMI they explain no further rainfall variance (Botswana High, {P(Mx['BH_p_given_modes'])}) or little ({100*Mx['AL_dR2']:.0f}%, {P(Mx['AL_p_given_modes'])}; Angola Low). "
   "We interpret them as pathways of the remote forcing at seasonal scale, while noting that they can matter for individual events (Blamey et al., 2018).")
Lc(f"Introduction, {L('Both modes reach Zimbabwe through regional circulation systems.', 'mediated, or modulated, by them.')}; Section 2.4, {L('A Botswana High index is defined', 'linearly detrended.')}; Section 3.8, {L('Mid-level heights rise over the whole subcontinent', 'explains')}; Fig. 7c,e; Table 3; Table S13a; Discussion, {L('The circulation results are consistent with a coherent physical picture', 'cannot capture that diversity.')}.")
C('- Maintaining Focus on Agroecological Zones: Throughout the manuscript, including in results descriptions and figures, the thematic focus on Natural Regions and their agricultural significance should be consistently maintained. Some sections lose this focus by reverting to broad spatial box composites or national aggregates without connecting results back to NR-specific implications.')
Rr('Agreed. In addition to the reorganisation described above, all regional averages now use the Natural Region polygons rather than boxes (CHIRPS, SPEI-6, ERA5-Land), figures 3, 6c, 8 and 11 and Table 4 are organised by region, and the Discussion has a paragraph on the agricultural meaning of the regional results and on region-specific outlooks.')
Lc(f"Sections 3.2, 3.7, 3.9, 3.11, 3.12; Discussion, {L('The regional results have direct agricultural meaning.', 'before planting.')}.")

Hd('Abstract', 2)
C('1. The introduction of the agroecological Natural Regions (AEZs) in the study is appropriate given Zimbabwe’s agroecological variability. However, the abstract primarily discusses results at the national scale, which may overlook important regional heterogeneities. I recommend clarifying the role of AEZs in the analysis and explicitly addressing how regional-scale findings inform or contrast with the national-level conclusions.')
Rr(f"The abstract was rewritten around the Natural Regions. It now states the aim by region, the regional range of the co-occurrence deficit ({a(d(EP,'I'),0)}% in NR I to {a(d(EP,'III'),0)}% in NR III), where it is significant after multiple-testing control (NR II–V), and that outlooks should express risk by region.")
Lc(f"{S('Abstract')}.")
C('2. The wording in the abstract suggests a causal interpretation of the relationship between ENSO/IOD co-occurrence and drought impacts. Given the complex climate system and multiple drivers influencing Zimbabwean rainfall, it would be prudent to temper causal language considering the potential influence of other regional drivers, such as the Botswana High and Angola Low pressures, which may modulate or interact with the teleconnections studied.')
Rr('Agreed. The abstract and the whole text now use associative language (“coincide with”, “are associated with”, “consistent with”). The abstract notes that the co-occurrence events were also the stronger El Niño events and that the regional highs and lows add no rainfall information beyond the modes. The Results and Discussion state that the circulation composites do not establish the direction of cause, and the title replaces “mechanisms” with “circulation”.')
Lc(f"{S('Abstract')}; Section 3.4, {L('We therefore describe the co-occurrence state as the driest', 'single cause of the deficit.')}; Section 3.8, {L('These diagnostics show that the co-occurrence drought coincides', 'individual events (Blamey et al., 2018).')}; title.")
C('3. The statement regarding depletion of “flowering-season soil moisture” appears to assume a uniform flowering period aligned with common planting dates across Zimbabwe. However, planting dates and maize phenology can vary significantly by agroecological zone and cultivar, meaning that soil moisture deficits could impact crops differently depending on growth stage and region. This nuance should be acknowledged to avoid overgeneralization.')
Rr('Agreed. The phrase was removed from the abstract. Section 3.9 now explains that DJF spans flowering and early grain fill for maize planted in November and December, that planting dates differ by region and season, that short-season cultivars and late plantings in NR III–V can flower in February or March, and that the DJF deficit should be read as a deficit in the main reproductive window for typical plantings. Soil moisture is now also reported by region (Fig. 8a).')
Lc(f"Section 3.9, {L('DJF spans flowering and early grain fill', 'at an earlier growth stage.')}; Fig. 8.")
C('4. The abstract repeats the point that “Because the IOD collapses after December while ENSO peaks thereafter, the IOD governs early-season measures and ENSO the whole-season totals.” To improve conciseness, consider consolidating or rephrasing this information to avoid redundancy.')
Rr('Removed from the abstract. With the revised data the claim also needed qualification: onset tracks ENSO more than the IOD, and the IOD signature is clearest in December dry spells. The point is now made once, in Section 3.10.')
Lc(f"{S('Abstract')}; {S('3.10')}.")

Hd('Detailed comments by line', 2)
C('L63-64. The introduction around these lines could strongly benefit from mentioning the relevant local climate drivers e.g. Angola Low (Munday and Washington - https://doi.org/10.1002/2016JD025736) or the Botswana High and how these interact with the modes being studied in this current paper (e.g. Blamey et al https://doi.org/10.1002/joc.5668).')
Rr('Done; see the response to the corresponding general comment above.')
Lc(f"Introduction, {L('Both modes reach Zimbabwe through regional circulation systems.', 'mediated, or modulated, by them.')}.")
C('L103-104. May I suggest having the full original country zones as a figure in the Supplementary Material in case readers are interested in knowing where the subzones are situated.')
Rr('Added as Fig. S1, which shows the seven zones (I, IIa, IIb, III, IV, Va, Vb) with their areas. The sub-zone boundaries are also drawn as dashed lines in Fig. 1.')
Lc(f"Section 2.1, {L('Boundaries are taken from the revised national Natural Region shapefile', 'giving five regions (Fig. 1).')}; Fig. S1; Fig. 1.")
C('L114-117. There is a need to create a full and detailed explanation of the method used to produce this figure within the Methods section ... Additionally, relocating Figure 1 to the Results section, rather than placing it before the methodological details, would align better with the logical flow of the manuscript.')
Rr('Done. The method is described in Section 2.2, and the deficit maps are now Fig. 3a,b in the Results. Fig. 1 is now a study-area map without results.')
Lc(f"Section 2.2, {L('*Representative series.*'.replace('*',''), 'sensitivity of the main result to these choices.')}; Section 3.2; Figs. 1 and 3.")
C('L120. It would be good to show these in space (even as Supp material), so we can see how many stations are in each respective region')
Rr(f"Done in Fig. 1, which shows all stations at their corrected positions with the number per region (NR I–V: {nst['I']}, {nst['II']}, {nst['III']}, {nst['IV']} and {nst['V']}), and in Tables S5 and S6 and Fig. S2.")
Lc('Fig. 1; Tables S5 and S6; Fig. S2.')
C('L127-128. ... I recommend the authors include explicit definitions or references for SOS and EOS calculation methods in the main text or a dedicated methods subsection; and uncertainty ranges or station-level variability alongside mean seasonal timing shifts.')
Rr(f"Done in the new Section 2.3 and in Section 3.11; see the response to the general comment above. Onset is reported with a 95% bootstrap interval ({a(T['SOS']['boot'][EP][0])}–{a(T['SOS']['boot'][EP][1])} days for the co-occurrence delay)," ' and station-level variability as interquartile ranges and fractions of stations.')
Lc(f"{S('2.3')}; {S('3.11')}; Fig. 10b; Table S11.")
C('L138-139. What’s the rationale behind this number of stations, considering that the NR’s have varying spatial areas?')
Rr(f"The network consists of all stations in the MSD archive with seasonal records for the period; the number was not chosen. Density therefore differs between regions, from {dens['I']:.1f} stations per 10^4^ km^2^ in NR I to {dens['V']:.1f} in NR V, and we now report it (Fig. 1; Table S6). "
   "The representative-series method (station departures from their own normals) prevents changes in the network from creating spurious jumps. "
   f"We tested the effect of the network on the main result: excluding low-coverage region-seasons gives {s(RS['exclude <2-station region-years']['enp'])}%, starting in 1959 when NR V enters gives {s(X['nat_1959'][EP][1])}%, and the MSD allocation gives {s(RS['msd membership']['enp'])}%, against {s(d(EP))}% in the primary analysis. CHIRPS, which averages over the whole of each region regardless of station density, gives the same ordering in every region (Table S9). Station density is listed as a limitation in the Discussion.")
Lc(f"Section 2.2, {L('The number of stations is set by the archive', 'NR V has no reporting station before 1959.')}; Section 3.5, {L('The result is also insensitive to station choices', 'NR I–IV only gives')}; Discussion, limitation (iv); Tables S2 and S6.")
C('L142. What are the spatial resolutions of these data? CHIRPS now has versions 2 and 3. All such details must be stated to ensure reproducibility.')
Rr('Added; see the response above. We use CHIRPS v2.0 because its record is complete for 1981–2024 and it is the version used in most validation studies over southern Africa; v3.0 changes the station blending and is left for future comparison.')
Lc(f"Section 2.4, {L('We retain v2.0 because it is complete', 'left for future comparison.')}.")
C('L164. How sensitive are these results to using a somehow equal sample of events by considering a tercile approach as has been applied in Ficchi et al https://doi.org/10.1016/j.wace.2021.100345? The way these modes have been defined in this study results in an unequal distribution of years, and this may skew the results.')
Rr('Done; see the response to the general tercile comment above.')
Lc('Sections 2.6 and 3.5; Fig. 5c; Table S4.')
C('L171. SON season used here is it before or after the considered DJF season associated with ONI?')
Rr('Before. SON lies in the onset year, so the SON DMI precedes the DJF ONI of the same season and coincides with the first half of the rainfall season. This is now stated explicitly.')
Lc(f"Section 2.6, {L('SON lies in the onset year', 'rainfall season.')}.")
C('L176-177. A form of repetition of L171-172.')
Rr('Removed.')
Lc('Section 2.6.')
C('L198-200. Similar to comment given for L127-128')
Rr('See the response to L127–128.')
Lc(f"{S('2.3')}.")
C('L200-L202. Considering how spatially variable onset dates are over Zimbabwe across the different NR’s, is there a justification for such an approach?')
Rr('This is a fair point. A national mean of raw onset dates would mix very different calendars. In the revision every timing composite is computed from each station’s departure from its own normal before averaging, so a national value is the mean of local departures rather than a departure of one calendar date. '
   'We also report the timing results by Natural Region (Table 4) and the spread across stations (Fig. 10b; Table S11). The delay in co-occurrence seasons occurs in every region and at 87% of stations.')
Lc(f"Section 2.3, {L('Because onset and cessation dates differ strongly across the country', 'one fixed calendar date.')}; Section 3.11; Table 4; Fig. 10b; Table S11.")
C('L208-209. As a result of the adopted definition. The tercile-based approach suggested earlier (see comment for L164) will certainly result in sample years here.')
Rr('Agreed. In the tercile scheme the marginal categories hold 22–23 seasons each, and every joint cell is populated (Table S4; Fig. 5c). The opposing combinations remain small (cold/positive n = 3, warm/negative n = 2) because the modes are correlated. We discuss this in Section 3.5.')
Lc('Section 3.5; Fig. 5c; Table S4.')
C('Full results section (quite confusing in the current form). The results would be clearer and more impactful if the authors first present the NR results ...')
Rr('Done; see the response to the overall assessment.')
Lc(f"{S('3')}.")
C('L292. This dataset was not introduced in the data section.')
Rr('Thank you for spotting this. The caption of the submitted Figure 4 referred to “Met Office zonal rainfall”, which was an error: the figure used the MSD station series. All captions now refer only to datasets introduced in Section 2.')
Lc('All figure captions.')
C('L298-301. The NR focus of the study, as was presented in previous sections, has been lost. Refer to comment on the full results section.')
Rr('The compound hot–dry section (Section 3.7) now reports SPEI-6 by Natural Region and the gain in detection by region (Fig. 6c; Table S12). Temperature remains a country mean because the 1° Berkeley Earth grid does not resolve NR I; SPEI-6, which includes evaporative demand, carries the temperature signal by region.')
Lc(f"{S('3.7')}; Fig. 6c; Table S12.")
C('L335. Are these spatial large (or local) scale patterns? It would be helpful to show the regional picture and overlap countries as opposed to using boxes as has been done in (a) and (b).')
Rr('Fig. 7a–c now show the regional fields over 0–35°S, 11–41°E with country borders. The descent in co-occurrence seasons is a large-scale pattern extending over Zimbabwe, Zambia, southern Angola and Mozambique (Fig. 7a), whereas in El Niño only seasons descent is confined to Angola and South Africa (Fig. 7b). The mid-level height anomaly is subcontinental with a maximum over Botswana (Fig. 7c). Zimbabwe-mean values are shown separately in Fig. 7d.')
Lc(f"Section 3.8, {L('The circulation anomalies differ between the two El Niño states', 'with national rainfall at')}; Fig. 7.")
C('L346. The NR story has been lost')
Rr('Fig. 8 now shows soil moisture and evaporative stress for each Natural Region and nationally, and the text reports the regional values.')
Lc(f"{S('3.9')}; Fig. 8.")
C('L451. Description must be under the data subsection')
Rr('Moved. CHIRPS is described only in Section 2.4.')
Lc(f"Section 2.4, {L('*Rainfall.*'.replace('*',''), 'extend the analysis to 2024 (section 3.12).')}.")
C('L536-539. see comment on the tercile approach (comment for L164).')
Rr('The Discussion now refers to the tercile analysis when discussing sample sizes and classification, and lists the dependence of the joint states on the ENSO–IOD correlation as a limitation.')
Lc(f"Discussion, {L('The robustness analysis changes how the central result', 'not a single effect size')} and limitation (ii).")

para(d_, '', indent=False)
para(d_, 'We thank the Editor and the reviewers again for their time and for comments that substantially improved the paper.', indent=False, space_after=6)
para(d_, 'Yours sincerely,', indent=False)
para(d_, 'Desmond Manatsa, on behalf of all authors', indent=False)
d_.save(OUT); print('saved', OUT)
