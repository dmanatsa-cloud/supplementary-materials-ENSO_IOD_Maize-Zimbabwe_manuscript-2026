import json, re
LINES = json.load(open('/home/claude/ms/out/ms_lines.json'))
_norm = lambda t: re.sub(r'\s+', ' ', t.replace('−', '-').replace('−', '-')).strip()
JOINED = ''; OFF = []
for n, t in LINES:
    OFF.append((len(JOINED), n)); JOINED += _norm(t) + ' '
def line_at(pos):
    ln = OFF[0][1]
    for o, n in OFF:
        if o <= pos: ln = n
        else: break
    return ln
def find(ph, after=0):
    p = _norm(ph); i = JOINED.find(p, after)
    if i < 0:
        # allow hyphenation across line breaks
        i = JOINED.replace('- ', '').find(p.replace('- ', ''))
        if i < 0: raise KeyError(ph)
    return i
def L(start, end=None):
    i = find(start); a = line_at(i)
    if end is None: return f'line {a}'
    j = find(end, i); b = line_at(j + len(_norm(end)) - 1)
    return f'lines {a}–{b}' if b != a else f'line {a}'
SECS = {}
_h = [(n, t.strip()) for n, t in LINES if re.match(r'^(\d(\.\d+)?\s+[A-Z]|Abstract$|Significance statement$|Acknowledgments$|Data availability statement$|References$)', t.strip()) and len(t) < 90]
for k, (n, t) in enumerate(_h):
    key = t.split(' ')[0] if t[0].isdigit() else t
    end = _h[k + 1][0] - 1 if k + 1 < len(_h) else LINES[-1][0]
    SECS[key] = (n, end)
def S(key):
    a, b = SECS[key]
    if key.isdigit():
        nxt = [v[0] for k, v in SECS.items() if k.isdigit() and int(k) == int(key) + 1]
        b = (nxt[0] if nxt else SECS['Acknowledgments'][0]) - 1
    return f'Section {key} (lines {a}–{b})' if key[0].isdigit() else f'{key} (lines {a}–{b})'
