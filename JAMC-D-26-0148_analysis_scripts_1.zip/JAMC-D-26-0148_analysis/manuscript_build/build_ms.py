import sys; sys.path.insert(0,'/home/claude/ms')
import importlib, ms_text; importlib.reload(ms_text)
from ms_text import *
from docbuild import *
OUT = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/ms/out/JAMC-D-26-0148_revised_manuscript.docx'
blocks = list(B)
# move Fig 1 to the end of section 2.1; put Fig 2 after Table 1
i1 = [i for i, b in enumerate(blocks) if b[0] == 'fig' and 'Fig01' in b[1]][0]; f1 = blocks.pop(i1)
i21 = [i for i, b in enumerate(blocks) if b == ('h2', '2.2 Station rainfall and representative regional series')][0]
blocks.insert(i21, f1)
it1 = [i for i, b in enumerate(blocks) if b[0] == 'table' and b[3].startswith('**Table 1.**')][0]
blocks.insert(it1 + 1, ('fig', '/home/claude/figs/' + FIG2[0] + '.png', FIG2[1], 6.5))
d = new_doc()
para(d, '**' + TITLE + '**', indent=False, align='center', space_after=12)
para(d, AUTHORS, indent=False, align='center', space_after=6)
for a_ in AFFIL: para(d, a_, indent=False, align='center', size=11, italic=True)
para(d, CORR, indent=False, align='center', size=11, space_after=12)
heading(d, 'Abstract', 1); para(d, ABSTRACT, indent=False)
heading(d, 'Significance statement', 1); para(d, SIGNIF, indent=False)
for b in blocks:
    k = b[0]
    if k == 'h1': heading(d, b[1], 1)
    elif k == 'h2': heading(d, b[1], 2)
    elif k == 'p': para(d, b[1])
    elif k == 'fig': figure(d, b[1], b[2], b[3])
    elif k == 'table':
        _, header, rows, cap, widths, note, align = b
        table(d, header, rows, caption=cap, widths=widths, note=note, align=align)
heading(d, 'Acknowledgments', 1); para(d, ACK)
heading(d, 'Data availability statement', 1); para(d, DATA, align='left')
heading(d, 'References', 1)
for r in REFS:
    p = para(d, r, indent=False, align='left'); p.paragraph_format.left_indent = Inches(0.3); p.paragraph_format.first_line_indent = Inches(-0.3)
d.save(OUT); print('saved', OUT)
