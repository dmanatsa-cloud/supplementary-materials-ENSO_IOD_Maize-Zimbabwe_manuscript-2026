set -e
cd /home/claude/ms
python3 build_ms.py
PYTHONPATH=/home/claude/analysis python3 build_supp.py
cd out
soffice --headless --convert-to pdf JAMC-D-26-0148_revised_manuscript.docx >/dev/null 2>&1
pdftotext -layout JAMC-D-26-0148_revised_manuscript.pdf ms.txt
cd ..
python3 - << 'PY'
import re,json
txt=open('/home/claude/ms/out/ms.txt').read(); lines=[]
for raw in txt.splitlines():
    m=re.match(r'\s*(\d+)\s{2,}(.*)',raw)
    if m: lines.append((int(m.group(1)),m.group(2)))
json.dump(lines,open('/home/claude/ms/out/ms_lines.json','w'))
PY
PYTHONPATH=/home/claude/analysis python3 build_resp.py
cd out
soffice --headless --convert-to pdf JAMC-D-26-0148_revised_supplementary.docx >/dev/null 2>&1
soffice --headless --convert-to pdf JAMC-D-26-0148_response_to_reviewers.docx >/dev/null 2>&1
C=/tmp/claude-0/-home-claude/9625e588-cb60-5be7-93e7-7592c3bbdaf7/scratchpad/cmp
cp JAMC-D-26-0148_revised_manuscript.docx $C/rev.docx
(cd $C && rm -f compare.docx && timeout 300 python3 cmp.py)
cp $C/compare.docx JAMC-D-26-0148_marked_comparison_with_submitted.docx
ls -la *.docx *.pdf
python3 /home/claude/ms/repair_compare.py /home/claude/ms/out/JAMC-D-26-0148_marked_comparison_with_submitted.docx /home/claude/ms/out/JAMC-D-26-0148_marked_comparison_with_submitted.docx
