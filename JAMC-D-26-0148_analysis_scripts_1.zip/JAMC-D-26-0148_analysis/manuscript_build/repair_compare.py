import zipfile, sys, shutil, os
from lxml import etree
W='http://schemas.openxmlformats.org/wordprocessingml/2006/main'; q=lambda t:'{%s}%s'%(W,t)
src, dst = sys.argv[1], sys.argv[2]
zin = zipfile.ZipFile(src); zout = zipfile.ZipFile(dst + '.tmp', 'w', zipfile.ZIP_DEFLATED)
for it in zin.infolist():
    data = zin.read(it.filename)
    if it.filename in ('word/document.xml', 'word/styles.xml'):
        root = etree.fromstring(data)
        for rpr in root.iter(q('rPr')):
            for tag in ('del', 'ins', 'moveFrom', 'moveTo'):
                for el in rpr.findall(q(tag)): rpr.remove(el); rpr.insert(0, el)
        for c in root.iter(q('color')):
            if c.get(q('val')) is None: c.set(q('val'), 'auto')
        data = etree.tostring(root, xml_declaration=True, encoding='UTF-8', standalone=True)
    zout.writestr(it, data)
zout.close(); os.replace(dst + '.tmp', dst); print('repaired', dst)
