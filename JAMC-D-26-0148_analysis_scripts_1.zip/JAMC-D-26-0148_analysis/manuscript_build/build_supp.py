import sys; sys.path.insert(0, '/home/claude/ms')
from vals import *
from docbuild import *
import pandas as pd
from table1 import T1ext  # noqa
OUT = '/home/claude/ms/out/JAMC-D-26-0148_revised_supplementary.docx'
F = '/home/claude/figs/'
EP, EO, LO, LM = 'EN+pIOD', 'EN only', 'LN only', 'LN+nIOD'
CATS = [EP, EO, LO, LM]
cnt = pd.read_csv('/home/claude/analysis/station_counts_seasonT.csv', index_col=0)

d_ = new_doc(line_numbers=False, spacing=1.15)
para(d_, '**Supplementary Material for**', indent=False, align='center')
para(d_, '**Compound hot–dry drought during co-occurring El Niño and positive Indian Ocean Dipole seasons in Zimbabwe’s agroecological Natural Regions: circulation, maize impacts, and implications for seasonal forecasting**', indent=False, align='center', space_after=6)
para(d_, 'Desmond Manatsa, Terence Mushore, James Ngoma, Isaac Masawana and Rebecca Manzou', indent=False, align='center')
para(d_, '*Journal of Applied Meteorology and Climatology*, manuscript JAMC-D-26-0148 (revised)', indent=False, align='center', space_after=12)
para(d_, '**Contents.** Tables S1–S13 and Figures S1–S4. Season labels are onset years (1951 = October 1951 to March 1952). Unless stated, composites of the four co-occurrence states are relative to the 15 neutral seasons of 1951–2017, individual-mode composites are relative to all other seasons, and *p* values are from Welch’s *t*-test. EN = El Niño, LN = La Niña, +IOD and −IOD = positive and negative IOD.', indent=False, space_after=8)

# ---------------- Table S1
mapc = {('EN', 'P'): EP, ('EN', '0'): EO, ('LN', '0'): LO, ('0', 'P'): 'pIOD only', ('0', 'N'): 'nIOD only', ('LN', 'P'): 'LN+pIOD', ('LN', 'N'): LM, ('0', '0'): 'Neutral', ('EN', 'N'): 'EN+nIOD'}
rows = []
for y in range(1951, 2025):
    r = TC.loc[y]; old = mapc[T1ext[y]] if y in T1ext else ''
    rows.append([f'{y}/{str(y+1)[2:]}', s(r['oni'], 2), s(r['dmi'], 2), LAB[r['cat']], LAB[old] if old else '', 'yes' if old and old != r['cat'] else ''])
heading(d_, 'Table S1', 2)
table(d_, ['Season', 'DJF ONI (°C)', 'SON DMI (°C)', 'Revised category', 'Submitted category', 'Changed'], rows,
      caption='**Table S1.** DJF Oceanic Niño Index and SON Dipole Mode Index for every season, 1951–2024, both from ERSSTv5 with the CPC moving 30-year base (section 2.6), with the revised classification (ONI ±0.5 °C, DMI ±0.4 °C) and the classification in the submitted manuscript (Table 1 of the submitted version, which used a fixed base without detrending). Seasons 2018–2024 are covered by CHIRPS only.',
      widths=[0.8, 0.9, 0.9, 1.4, 1.4, 0.6], size=9)

# ---------------- Table S2
rows = []
lab2 = {'roll': 'Moving 30-yr base, ERSSTv5 (primary)', 'f8110': 'Fixed 1981–2010 base, no detrending', 'f9120': 'Fixed 1991–2020 base, no detrending',
        'detr_boxes': 'Fixed base, linear trend removed from each box', 'detr_index': 'Fixed base, linear trend removed from the DMI', 'had_roll': 'HadISST1 DMI, moving base',
        'months(9,)': 'DMI September only', 'months(10,)': 'DMI October only', 'months(11,)': 'DMI November only', 'months(8, 9, 10)': 'DMI August–October'}
for c in R['conventions']:
    rows.append([lab2.get(c['conv'], c['label']), str(c['n']), s(c['d']), Pn(c['p']), str(c['n_en']), s(c['d_en']), Pn(c['p_en']),
                 f"{c.get('n_lnm','')}", s(c['d_lnm']) if 'd_lnm' in c else '', Pn(c['p_lnm']) if 'p_lnm' in c else '', f"{100*c['agreeE']:.0f}/{100*c['agreeI']:.0f}"])
ss = RS
for k, lab in [('msd membership', 'MSD station-to-region allocation'), ('no QC (poly)', 'No station quality control'), ('exclude <2-station region-years', 'Low-coverage region-seasons excluded'), ('1983-2017 only', 'Stations, 1983–2017 only')]:
    v = ss[k]
    rows.append([lab, str(v.get('n', 9)), s(v['enp']), Pn(v['enp_p']), str(v.get('nen', 14)), s(v['en']), Pn(v['en_p']), '', s(v['lnm']), Pn(v['lnm_p']), '100/100'])
rows.append(['National series from 1959 (NR V present)', '9', s(X['nat_1959'][EP][1]), Pn(X['nat_1959'][EP][2]), '11', s(X['nat_1959'][EO][1]), Pn(X['nat_1959'][EO][2]), '5', s(X['nat_1959'][LM][1]), Pn(X['nat_1959'][LM][2]), '100/100'])
rows.append(['National series from NR I–IV only', '9', s(X['nat_NRI_IV'][EP][1]), Pn(X['nat_NRI_IV'][EP][2]), '14', s(X['nat_NRI_IV'][EO][1]), Pn(X['nat_NRI_IV'][EO][2]), '6', s(X['nat_NRI_IV'][LM][1]), Pn(X['nat_NRI_IV'][LM][2]), '100/100'])
ce = CH['ext']
rows.append(['CHIRPS v2.0, 1981–2024', str(ce[EP]['n']), s(ce[EP]['Nat']['d']), Pn(ce[EP]['Nat']['p']), str(ce[EO]['n']), s(ce[EO]['Nat']['d']), Pn(ce[EO]['Nat']['p']), str(ce[LM]['n']), s(ce[LM]['Nat']['d']), Pn(ce[LM]['Nat']['p']), '100/100'])
cb = R['combined']
rows.append(['Stations 1951–2017 + CHIRPS 2018–2024', str(cb[EP]['n']), s(cb[EP]['Nat']['d']), Pn(cb[EP]['Nat']['p']), str(cb[EO]['n']), s(cb[EO]['Nat']['d']), Pn(cb[EO]['Nat']['p']), str(cb[LM]['n']), s(cb[LM]['Nat']['d']), Pn(cb[LM]['Nat']['p']), '100/100'])
heading(d_, 'Table S2', 2)
table(d_, ['Convention or data choice', 'n', 'EN & +IOD', '*p*', 'n', 'EN only', '*p*', 'n', 'LN & −IOD', '*p*', 'Agree E/I (%)'], rows,
      caption='**Table S2.** Sensitivity of the national composites (% relative to neutral seasons) to the index convention and to station and dataset choices. "Agree E/I" is the percentage of the 67 seasons of 1951–2017 whose ENSO and IOD phases agree with the primary classification. The linear trend removed from each box and from the DMI give identical classifications, as expected for a linear operation applied over the same period. Station-choice rows use the primary classification. Fig. S3 shows the index series.',
      widths=[2.1, 0.3, 0.6, 0.62, 0.3, 0.55, 0.62, 0.3, 0.6, 0.62, 0.7], size=7.5)

# ---------------- Table S3
rows = [[f"±{t['te']:.1f}", f"±{t['ti']:.1f}", str(t['n']), s(t['d']), Pn(t['p']), str(t['n_en']), s(t['d_en']), Pn(t['p_en']), str(t['n_neu'])] for t in thr]
heading(d_, 'Table S3', 2)
table(d_, ['ONI threshold (°C)', 'DMI threshold (°C)', 'n', 'EN & +IOD (%)', '*p*', 'n', 'EN only (%)', '*p*', 'n neutral'], rows,
      caption='**Table S3.** National El Niño & +IOD and El Niño only composites relative to neutral seasons for nine combinations of thresholds, station series 1951–2017 (Fig. 5a). The primary choice is ONI ±0.5 °C and DMI ±0.4 °C.',
      widths=[1, 1, 0.4, 0.9, 0.6, 0.4, 0.9, 0.6, 0.7], size=9)

# ---------------- Table S4
tb = R['tercile_bounds']
rows = []
for oc in ['cold', 'mid', 'warm']:
    for ic in ['neg', 'mid', 'pos']:
        c = TER[f'{oc}|{ic}']
        vm = c.get('vs_mid')
        rows.append([{'cold': 'Cold', 'mid': 'Middle', 'warm': 'Warm'}[oc], {'neg': 'Negative', 'mid': 'Middle', 'pos': 'Positive'}[ic], str(c['n']), s(c['mean']),
                     (s(vm['d']) + f" ({Pn(vm['p'])})") if vm else 'reference', ', '.join(str(y) for y in c['years'])])
tm = R['tercile_marg']
heading(d_, 'Table S4', 2)
table(d_, ['ONI tercile', 'DMI tercile', 'n', 'Mean anomaly (%)', 'vs middle/middle (*p*)', 'Seasons'], rows,
      caption=f"**Table S4.** Tercile classification following Ficchì et al. (2021). Tercile bounds over 1951–2017 are {s(tb['oni'][0],2)} and {s(tb['oni'][1],2)} °C for the DJF ONI and {s(tb['dmi'][0],2)} and {s(tb['dmi'][1],2)} °C for the SON DMI. The mean anomaly is the national rainfall anomaly (% of the 1951–2017 mean). Marginal composites relative to all other seasons: warm ONI {s(tm['warm ONI']['d'])}% (n = {tm['warm ONI']['n']}, *p* = {Pn(tm['warm ONI']['p'])}); cold ONI {s(tm['cold ONI']['d'])}% (n = {tm['cold ONI']['n']}, *p* = {Pn(tm['cold ONI']['p'])}); positive DMI {s(tm['pos DMI']['d'])}% (n = {tm['pos DMI']['n']}, *p* = {Pn(tm['pos DMI']['p'])}); negative DMI {s(tm['neg DMI']['d'])}% (n = {tm['neg DMI']['n']}, *p* = {Pn(tm['neg DMI']['p'])}).",
      widths=[0.8, 0.8, 0.4, 0.9, 1.1, 3.0], size=9, align=['left', 'left', 'center', 'center', 'center', 'left'])

# ---------------- Table S5
DISP = {'Esigodhini': 'Esigodini', 'Mounts_Darwin': 'Mount Darwin', 'Harare_Airport': 'Harare Airport', 'Bulawayo_Goetz': 'Bulawayo (Goetz)', 'Victoria_Falls': 'Victoria Falls Airport', 'Hwange': 'Hwange National Park', 'Marondera': 'Marondera (Grasslands)', 'Belvedere': 'Harare (Belvedere)', 'Kutsaga': 'Harare (Kutsaga)'}
_w = ST.dropna(subset=['WMO_ID']); nmatch = int((_w.Station_Code.astype(str) == _w.WMO_ID.astype(int).astype(str)).sum())
rows = []
for _, r in ST.sort_values(['NR_poly', 'Station']).iterrows():
    moved = f"{r.lon_wb:.2f}, {abs(r.lat_wb):.2f}" if max(abs(r.Longitude - r.lon_wb), abs(r.Latitude - r.lat_wb)) > 0.015 else ''
    src = 'register' if r.coord_note == 'MSD register' else 'archive' 
    rows.append([DISP.get(r.Station, r.Station.replace('_', ' ')), (str(int(r.WMO_ID)) if pd.notna(r.WMO_ID) else f'MSD\u00a0{r.MSD_ID}'), f"{r.Longitude:.3f}", f"{abs(r.Latitude):.3f}", moved, r.NR_poly, r.subzone, r.NR_msd,
                 f"{int(r.First_Season_Year)}–{int(r.Last_Season_Year)}" if pd.notna(r.First_Season_Year) else '', str(int(r.Seasonal_Years)) if pd.notna(r.Seasonal_Years) else ''])
heading(d_, 'Table S5', 2)
table(d_, ['Station', 'Station ID', 'Lon (°E)', 'Lat (°S)', 'Archive lon, lat (if changed)', 'NR', 'Zone', 'Submitted NR', 'Period', 'Seasons'], rows,
      caption='**Table S5.** Station inventory. Station IDs are WMO block indices (67xxx) from the MSD station register. The ' + str(46-n_register) + ' climatological, agrometeorological and cooperative stations without a WMO index are identified by their MSD national climatological register number (prefixed MSD). The station codes in the archive workbook matched the register for only ' + str(nmatch) + ' of these ' + str(n_register) + ' stations and are not used. Longitude and latitude are the positions used in the revised analysis; where they differ from the archive coordinates, the archive values are given. '
      'Coordinates are from the MSD station register for the ' + str(n_register) + ' stations it lists; for the other ' + str(46-n_register) + ' stations the archive coordinates are used, except that the latitude of Chisumbanje was corrected. Archive positions that placed stations at another town include Nyanga (at Mvurwi), Mutoko (at Mutare), Rusape (at Mvuma) and Matopos (at Bulawayo). "NR" is the Natural Region polygon that contains the position used, and "Zone" the sub-zone of the seven-zone shapefile. "Submitted NR" is the allocation used in the submitted manuscript; ' + str(n_realloc) + ' stations differ.',
      widths=[1.25, 0.78, 0.58, 0.55, 0.95, 0.33, 0.42, 0.72, 0.8, 0.6], size=8)

# ---------------- Table S6
rows = []
lowc = RS['lowcov_by_nr']
for nr in NRS:
    rows.append([f'NR {nr}', f"{area[nr]:,}", str(nst[nr]), f"{dens[nr]:.2f}", f"{cnt[nr].median():.0f}", f"{cnt[nr].min():.0f}–{cnt[nr].max():.0f}", str(lowc[nr]),
                 f"{nr_clim[nr]:.0f}", f"{CH['clim_mm'][nr]:.0f}"])
rows.append(['Zimbabwe', f"{sum(area.values()):,}", '46', f"{46/sum(area.values())*1e4:.2f}", '', '', str(RS['lowcov_count']), '', f"{CH['clim_mm']['Nat']:.0f}"])
heading(d_, 'Table S6', 2)
table(d_, ['Region', 'Area (km^2^)', 'Stations', 'Stations per 10^4^ km^2^', 'Median reporting', 'Range reporting', 'Low-coverage seasons', 'Station mean (mm)', 'CHIRPS mean (mm)'], rows,
      caption='**Table S6.** Station density and coverage by Natural Region, 1951–2017. Areas are computed on the Africa Albers equal-area projection. "Reporting" refers to stations with a valid seasonal total in a given season (Fig. S2). Low-coverage seasons have fewer than two reporting stations; in NR V they include the eight seasons of 1951–1958 with no station. Mean ONDJFM totals are for the station series (1951–2017) and CHIRPS (1981–2024).',
      widths=[0.8, 0.9, 0.6, 0.8, 0.7, 0.7, 0.8, 0.8, 0.8], size=9)

# ---------------- Table S7
rows = [[r.station.replace('_', ' '), str(int(r.year)), f"{r.value:.1f}", f"{r.ratio_normal:.2f}", f"{r.ratio_neighbours:.2f}", 'set to missing'] for _, r in QC.iterrows()]
for _, r in QT.iterrows():
    yrs = str(r.years).split(', ')
    rows.append([r.station.replace('_', ' '), (f"{len(yrs)} seasons, {yrs[0]}–{yrs[-1]}" if len(yrs) > 3 else str(r.years)), 'SOS ≥ EOS', '', '', 'timing set to missing' + (' (whole record)' if r.station == 'Lupane' else '')])
heading(d_, 'Table S7', 2)
table(d_, ['Station', 'Season(s)', 'Value (mm)', 'Ratio to station normal', 'Ratio to regional median ratio', 'Action'], rows,
      caption='**Table S7.** Values removed by quality control. Seasonal totals were flagged when the ratio to the station normal was above 5 or below 0.1, or when that ratio was more than 4 or less than 0.15 times the median ratio of the other stations in the same region and season. Timing values were removed when onset was on or after cessation; the Lupane timing record was removed entirely. One onset value of 365 days (no onset found) was also treated as missing.',
      widths=[1.2, 1.4, 0.8, 1.0, 1.1, 1.3], size=9)

# ---------------- Table S8
rows = []
for c in ['EN', 'LN', 'pIOD', 'nIOD']:
    rows.append([f"{LAB[c]} (n = {n(c)}) vs other"] + [f"{s(d(c,nr))} ({Pn(p(c,nr))})" for nr in NRS + ['Nat']])
for c in CATS:
    rows.append([f"{LAB[c]} (n = {n(c)}) vs neutral"] + [f"{s(d(c,nr))} ({Pn(p(c,nr))}; *q* {Pn(R['st_fdr'][f'{c}|{nr}']['q'])})" for nr in NRS] + [f"{s(d(c,'Nat'))} ({Pn(p(c,'Nat'))})"])
    rows.append(['   95% bootstrap CI'] + [f"{s(ci(c,nr)[0])} to {s(ci(c,nr)[1])}" for nr in NRS + ['Nat']])
rows.append(['Neutral mean anomaly (n = 15)'] + [s(R['st']['Neutral']['mean_abs'][nr]) for nr in NRS + ['Nat']])
heading(d_, 'Table S8', 2)
table(d_, ['Category', 'NR I', 'NR II', 'NR III', 'NR IV', 'NR V', 'National'], rows,
      caption='**Table S8.** Rainfall composites by Natural Region, station series 1951–2017 (% of the regional mean), with Welch *p* values, Benjamini–Hochberg *q* values across the 20 region × co-occurrence tests, and 95% bootstrap confidence intervals (10 000 resamples). ANOVA across the four co-occurrence states: *F* = ' + f"{R['anova']['F']:.2f}, *p* = {Pn(R['anova']['p'])}" + '. Tukey: ' + '; '.join(f"{LAB[t['g1']]} vs {LAB[t['g2']]} {s(t['diff'])} (*p* = {Pn(t['p'])})" for t in R['tukey']) + '.',
      widths=[1.6, 0.85, 0.85, 0.85, 0.85, 0.85, 0.8], size=8)

# ---------------- Table S9
rows = [['Station–CHIRPS r, 1981–2017'] + [f"{CH['val'][nr]['r']:.2f}" for nr in NRS + ['Nat']],
        ['CHIRPS mean ONDJFM (mm)'] + [f"{CH['clim_mm'][nr]:.0f}" for nr in NRS + ['Nat']]]
for c in ['EN', 'LN', 'pIOD', 'nIOD']:
    rows.append([f"{LAB[c]} (n = {ce[c]['n']}) vs other"] + [f"{s(ce[c][nr]['d'])} ({Pn(ce[c][nr]['p'])})" for nr in NRS + ['Nat']])
for c in CATS:
    rows.append([f"{LAB[c]} (n = {ce[c]['n']}) vs neutral"] + [f"{s(ce[c][nr]['d'])} ({Pn(ce[c][nr]['p'])})" for nr in NRS + ['Nat']])
rows.append(['OND rainfall vs neutral, national'] + ['', '', '', '', ''] + ['; '.join(f"{LAB[c]} {s(R['monthly']['OND_tests'][c]['d'])}" for c in [EP, EO])])
heading(d_, 'Table S9', 2)
table(d_, ['Quantity', 'NR I', 'NR II', 'NR III', 'NR IV', 'NR V', 'National'], rows,
      caption=f"**Table S9.** CHIRPS v2.0 validation and composites by Natural Region, 1981–2024 (% of the regional mean, Welch *p* in parentheses; 9 neutral seasons). Driest CHIRPS seasons: " + ', '.join(f"{y}/{str(y+1)[2:]} ({s(v)}%)" for y, v in zip(CH['driest'], CH['driest_vals'])) + '. Fig. S4 shows the monthly evolution by region.',
      widths=[1.8, 0.8, 0.8, 0.8, 0.8, 0.8, 1.0], size=8)

# ---------------- Table S10
labp = {'SOS': 'Onset (SOS)', 'OND_LODS': 'OND longest dry spell', 'Dec_LODS': 'December longest dry spell', 'Season_T': 'Seasonal total (sign reversed)', 'JF_LODS': 'Jan–Feb longest dry spell', 'Feb_LODS': 'February longest dry spell', 'LOS': 'Season length (sign reversed)'}
rows = []
for k in ['SOS', 'OND_LODS', 'Dec_LODS', 'Season_T', 'JF_LODS', 'Feb_LODS', 'LOS']:
    sg = -1 if k in ('Season_T', 'LOS') else 1
    rows.append([labp[k], f"{s(sg*PC[k]['iod']['r'],2)} ({Pn(PC[k]['iod']['p'])})", f"{s(sg*PC[k]['enso']['r'],2)} ({Pn(PC[k]['enso']['p'])})", '', ''])
dl = R['daily']
for k, lab in [('onset', 'CHIRPS onset'), ('dec_dry', 'CHIRPS December max dry spell'), ('feb_dry', 'CHIRPS February max dry spell')]:
    rows.append([lab + ' (1981–2024)', f"{s(dl[k]['iod']['r'],2)} ({Pn(dl[k]['iod']['p'])})", f"{s(dl[k]['enso']['r'],2)} ({Pn(dl[k]['enso']['p'])})", f"{s(dl['maize_links'][k]['r'],2)} ({Pn(dl['maize_links'][k]['p'])})", ''])
for k, lab in [('SOS', 'Station onset'), ('Dec_LODS', 'Station December dry spell'), ('Feb_LODS', 'Station February dry spell'), ('Season_T', 'Station seasonal total')]:
    rows.append([lab + ', maize link', '', '', f"{s(Z['links'][k]['r_yield'],2)} ({Pn(Z['links'][k]['p_yield'])})", f"{s(Z['links'][k]['r_rain'],2)}"])
heading(d_, 'Table S10', 2)
table(d_, ['Parameter', 'Partial r, SON DMI | DJF ONI', 'Partial r, DJF ONI | SON DMI', 'r with detrended maize', 'r with seasonal total'], rows,
      caption=f"**Table S10.** Partial correlations of rainfall parameters with each index controlling for the other, station series 1951–2017 (n = 67) and daily CHIRPS 1981–2024 (n = 44), with *p* values. Signs are arranged so that positive values mean drier or later for the station parameters. Station–CHIRPS onset correlation: r = {dl['r_onset_station']:.2f}. Maize correlations use onset years 1960–2017 (station) and 1981–2023 (CHIRPS).",
      widths=[2.2, 1.2, 1.2, 1.0, 0.9], size=9)

# ---------------- Table S11
rows = []
for var in ['SOS', 'EOS', 'LOS']:
    rows.append([f"{var}, neutral mean (day)"] + [f"{T[var]['nr'][nr]['Neutral_mean']:.0f}" for nr in NRS] + [f"{T[var]['comp']['Neutral_mean']:.0f}"])
    for c in [EP, EO]:
        rows.append([f"{var}, {LAB[c]}"] + [f"{s(T[var]['nr'][nr][c]['d'])} ({Pn(T[var]['nr'][nr][c]['p'])})" for nr in NRS] + [f"{s(T[var]['comp'][c]['d'])} ({Pn(T[var]['comp'][c]['p'])})"])
heading(d_, 'Table S11', 2)
table(d_, ['Metric', 'NR I', 'NR II', 'NR III', 'NR IV', 'NR V', 'National'], rows,
      caption='**Table S11a.** Season timing composites relative to neutral seasons by Natural Region (days; Welch *p* in parentheses), station series 1951–2017. Days are counted from 1 July. For individual modes nationally: El Niño onset ' + f"{s(T['SOS']['indiv']['EN']['d'])} d (*p* = {Pn(T['SOS']['indiv']['EN']['p'])}), positive IOD onset {s(T['SOS']['indiv']['pIOD']['d'])} d (*p* = {Pn(T['SOS']['indiv']['pIOD']['p'])}), positive IOD cessation {s(T['EOS']['indiv']['pIOD']['d'])} d (*p* = {Pn(T['EOS']['indiv']['pIOD']['p'])}), positive IOD length {s(T['LOS']['indiv']['pIOD']['d'])} d (*p* = {Pn(T['LOS']['indiv']['pIOD']['p'])})" + ', relative to all other seasons.',
      widths=[1.8, 0.85, 0.85, 0.85, 0.85, 0.85, 0.9], size=8)
rows = []
for var in ['SOS', 'EOS', 'LOS']:
    for c in [EP, EO, LM]:
        x = T['station_spread'][f'{var}|{c}']
        rows.append([var, LAB[c], str(x['n_st']), s(x['median']), f"{s(x['q25'])} to {s(x['q75'])}", f"{100*x['frac_pos']:.0f}", f"{100*x['frac_neg']:.0f}"])
table(d_, ['Metric', 'State', 'Stations', 'Median (days)', 'Interquartile range', '% later/longer', '% earlier/shorter'], rows,
      caption=f"**Table S11b.** Spread of station-level composites relative to neutral seasons (each station compared with its own neutral-season mean). The median of the station standard deviations of onset is {T['sos_station_sd_median']:.0f} days. The earliest recorded EOS is day {T['eos_min']:.0f} and the earliest SOS day {T['sos_min']:.0f}; {100*T['eos_floor_frac']:.0f}% of station-seasons sit at the EOS bound (El Niño & +IOD {100*T['eos_floor_by_cat'][EP]:.0f}%, El Niño only {100*T['eos_floor_by_cat'][EO]:.0f}%, neutral {100*T['eos_floor_by_cat']['Neutral']:.0f}%).",
      widths=[0.6, 1.3, 0.7, 0.9, 1.3, 0.9, 0.9], size=9)

# ---------------- Table S12
rows = []
for c in CATS + ['Neutral']:
    rows.append([f"SPEI-6, {LAB[c]}"] + [f"{s(SP['abs_nr'][c][nr],2)}" for nr in NRS] + [f"{s(SP['abs'][c],2)}"])
for c in CATS:
    rows.append([f"Soil moisture (kg m^−2^), {LAB[c]}"] + [f"{s(L['sm'][nr][c]['d'],1)} ({Pn(L['sm'][nr][c]['p'])})" for nr in NRS + ['Nat']])
rows.append(['Soil moisture DJF mean (kg m^−2^)'] + [f"{L['sm_clim'][nr]:.1f}" for nr in NRS + ['Nat']])
for c in CATS:
    rows.append([f"PET − ET (mm d^−1^), {LAB[c]}"] + [f"{s(L['stress'][nr][c]['d'],2)} ({Pn(L['stress'][nr][c]['p'])})" for nr in NRS + ['Nat']])
rows.append(["Cohen's |*d*|, rainfall / SPEI-6 (El Niño vs other)"] + [f"{abs(R['cohen'][nr]['rain']):.2f} / {abs(R['cohen'][nr]['spei']):.2f}" for nr in NRS + ['Nat']])
heading(d_, 'Table S12', 2)
table(d_, ['Quantity', 'NR I', 'NR II', 'NR III', 'NR IV', 'NR V', 'National'], rows,
      caption=f"**Table S12a.** Drought and land-surface composites by Natural Region. SPEI-6 values are March means of each state, 1951–2017. Soil moisture and evaporative stress (PET − ET) are DJF anomalies relative to neutral seasons, 1951–2024, linearly detrended, with Welch *p* values. SPEI-6 correlates with the station series at r = " + ', '.join(f"{spei_r[nr]:.2f}" for nr in NRS) + f" for NR I–V and {spei_r['Nat']:.2f} nationally.",
      widths=[2.1, 0.8, 0.8, 0.8, 0.8, 0.8, 0.8], size=8)
rows = []
for c in CATS + ['Neutral']:
    rows.append([LAB[c], str(TP['counts'][c]), s(TP['berk_detr'][c], 2), s(TP['era_detr'][c], 2),
                 (f"{s(TP['berk_vs_neu'][c]['d'],2)} ({Pn(TP['berk_vs_neu'][c]['p'])})" if c != 'Neutral' else ''),
                 (f"{s(TP['era_vs_neu'][c]['d'],2)} ({Pn(TP['era_vs_neu'][c]['p'])})" if c != 'Neutral' else '')])
table(d_, ['State', 'n', 'Berkeley Earth (°C)', 'ERA5 (°C)', 'Berkeley vs neutral', 'ERA5 vs neutral'], rows,
      caption=f"**Table S12b.** Detrended DJF maximum temperature over Zimbabwe by state, 1970–2024 (anomaly relative to the 1970–2024 mean), and the difference from neutral seasons with Welch *p* values. Berkeley Earth trend: {TP['trend_berk']*10:.2f} °C per decade. Berkeley–ERA5 correlation: r = {TP['r_berk_era']:.2f}. Rainfall–Tmax correlation, 1970–2017: r = {TP['r_rain_berk_st']:.2f} (Berkeley, station rainfall); 1981–2024: r = {TP['r_rain_era_ch']:.2f} (ERA5, CHIRPS).",
      widths=[1.4, 0.4, 1.0, 0.9, 1.3, 1.3], size=9)

# ---------------- Table S13
rows = [['Botswana High index', f"{Mx['BH_r_rain']:.2f}", f"{Mx['BH_r_oni']:.2f}", f"{Mx['BH_r_dmi']:.2f}", f"{s(Mx['BH_b_given_modes'],3)} ({Pn(Mx['BH_p_given_modes'])})", f"{Mx['BH_dR2']:.3f}"],
        ['Angola Low index', f"{Mx['AL_r_rain']:.2f}", f"{Mx['AL_r_oni']:.2f}", f"{Mx['AL_r_dmi']:.2f}", f"{s(Mx['AL_b_given_modes'],2)} ({Pn(Mx['AL_p_given_modes'])})", f"{Mx['AL_dR2']:.3f}"]]
heading(d_, 'Table S13', 2)
table(d_, ['Index (DJF, detrended)', 'r with CHIRPS rainfall', 'r with DJF ONI', 'r with SON DMI', 'Coefficient given ONI and DMI (*p*)', 'Added R^2^'], rows,
      caption=f"**Table S13a.** Regional circulation indices, 1981–2024. The base regression of national CHIRPS rainfall on the DJF ONI and SON DMI has R^2^ = {Mx['R2_modes_chirps']:.2f}. ω500 over Zimbabwe correlates with national station rainfall at r = {Mx['r_w500_rain']:.2f} (1951–2017).",
      widths=[1.4, 0.9, 0.8, 0.8, 1.5, 0.7], size=9)
rows = [[LAB[c], str(Z['cat'][c]['n']), s(Z['cat'][c]['mean']), (f"{s(Z['vs_neu'][c]['d'])} ({Pn(Z['vs_neu'][c]['p'])})" if c in Z['vs_neu'] else ''), s(YD['fao_prod']['cat'][c]['mean']), (f"{s(YD['fao_prod']['vs_neu'][c]['d'])} ({Pn(YD['fao_prod']['vs_neu'][c]['p'])})" if c in YD['fao_prod']['vs_neu'] else ''), s(YD['cat'][c]['mean']), (f"{s(YD['vs_neu'][c]['d'])} ({Pn(YD['vs_neu'][c]['p'])})" if c in YD['vs_neu'] else ''), s(YD['area']['cat'][c]['mean']), (f"{s(YD['area']['vs_neu'][c]['d'])} ({Pn(YD['area']['vs_neu'][c]['p'])})" if c in YD['area']['vs_neu'] else '')] for c in CATS + ['Neutral']]
table(d_, ['State', 'n', 'USDA prod.', 'vs neutral (*p*)', 'FAO prod.', 'vs neutral (*p*)', 'FAO yield', 'vs neutral (*p*)', 'FAO area', 'vs neutral (*p*)'], rows,
      caption=f"**Table S13b.** Detrended national maize production (USDA and FAOSTAT), yield and area harvested (FAOSTAT) by state, onset years 1960–2023: mean departure from the era trend (%) and difference from neutral seasons (percentage points, Welch *p*). USDA prod. and FAO prod. are USDA and FAOSTAT production; FAO yield and FAO area are FAOSTAT yield and area harvested. The seasons in each state are listed in Table S1. USDA production variance partition: R^2^ = {Z['R2_full']:.3f}; ENSO alone {Z['R2_enso']:.3f}; IOD alone {Z['R2_iod']:.3f}; unique ENSO {Z['uniq_enso']:.3f}; unique IOD {Z['uniq_iod']:.3f}; shared {Z['shared']:.3f}. Standardised coefficients: ONI {s(Z['beta_oni'],2)} (*p* = {Pn(Z['p_oni'])}), DMI {s(Z['beta_dmi'],2)} (*p* = {Pn(Z['p_dmi'])}). Marginal differences: El Niño minus La Niña {s(Z['marg_enso'])}%; positive minus negative IOD {s(Z['marg_iod'])}%. FAOSTAT production variance partition: R^2^ = {YD['fao_prod']['R2_full']:.3f}; unique ENSO {YD['fao_prod']['uniq_enso']:.3f}; unique IOD {YD['fao_prod']['uniq_iod']:.3f}; shared {YD['fao_prod']['shared']:.3f}. FAOSTAT yield variance partition: R^2^ = {YD['R2_full']:.3f}; unique ENSO {YD['uniq_enso']:.3f}; unique IOD {YD['uniq_iod']:.3f}; shared {YD['shared']:.3f}; standardised coefficients ONI {s(YD['beta_oni'],2)} (*p* = {Pn(YD['p_oni'])}), DMI {s(YD['beta_dmi'],2)} (*p* = {Pn(YD['p_dmi'])}). In log terms, yield accounts for {100*YD['decomp'][EP]['yield_share']:.0f}% of the El Niño & +IOD FAOSTAT production deficit and area for the rest. Area harvested correlates with seasonal rainfall at r = {YD['area']['r_rain']:.2f}. Detrended FAOSTAT yield correlates with detrended USDA production at r = {YD['r_with_usda_prod']:.2f}. Excluding the {YD['n_estimated']} FAO estimates (harvests 1961–1966 and 1968), El Niño & +IOD yield is {s(YD['official_only']['vs_neu'][EP]['d'])} points relative to neutral (*p* = {Pn(YD['official_only']['vs_neu'][EP]['p'])}). Correlation of detrended production with seasonal rainfall: r = {Z['r_rain_yield']:.2f}. Lowest harvests since 2000 (thousand tonnes): " + ', '.join(f"{y}/{str(y+1)[2:]} {v:.0f}" for y, v in Z['lowest2000'][:4]) + '.',
      widths=[1.2, 0.38, 0.58, 0.92, 0.58, 0.92, 0.58, 0.92, 0.58, 0.92], size=8)

# ---------------- Figures
page_break(d_)
heading(d_, 'Supplementary figures', 1)
figure(d_, F + 'FigS1_seven_zones.png', '**Figure S1.** The seven zones of the revised national Natural Region shapefile (I, IIa, IIb, III, IV, Va and Vb) with their areas. The sub-zones IIa/IIb and Va/Vb are dissolved into NR II and NR V for the analysis.', 5.5)
figure(d_, F + 'FigS2_station_coverage.png', '**Figure S2.** Number of stations reporting a seasonal total in each Natural Region, 1951–2017, after quality control and polygon allocation. The dashed line marks the low-coverage threshold of two stations.', 6.5)
figure(d_, F + 'FigS3_index_conventions.png', '**Figure S3.** Index series under alternative conventions. (a) DJF Niño 3.4 from ERSSTv5 with the moving 30-year base, a fixed 1981–2010 base, and a fixed base with a linear trend removed. (b) SON DMI from ERSSTv5 with the moving base, fixed 1981–2010 and 1991–2020 bases and a linear trend removed from each box, and from HadISST1 with the moving base. Dashed lines mark the classification thresholds.', 6.5)
figure(d_, F + 'FigS4_monthly_by_NR.png', '**Figure S4.** Monthly CHIRPS rainfall anomaly (% of the monthly climatology) from October to March by Natural Region and state, 1981–2024 (La Niña & −IOD 5 seasons, El Niño only 5, El Niño & +IOD 10).', 6.5)
d_.save(OUT); print('saved', OUT)
