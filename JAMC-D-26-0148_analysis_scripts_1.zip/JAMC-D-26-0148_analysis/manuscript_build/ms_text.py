"""Revised manuscript text. Every number is pulled from the analysis outputs via vals.py."""
from vals import *
F = '/home/claude/figs/'
B = []  # blocks
def H1(t): B.append(('h1', t))
def H2(t): B.append(('h2', t))
def Pp(t): B.append(('p', t))
def FIG(name, cap, w=6.5): B.append(('fig', F + name + '.png', cap, w))
def TAB(header, rows, cap, widths=None, note=None, align=None): B.append(('table', header, rows, cap, widths, note, align))

# ---------- convenience numbers
EP, EO, LO, LM = 'EN+pIOD', 'EN only', 'LN only', 'LN+nIOD'
c51 = chron['counts_51_17']; c524 = chron['counts_51_24']
nat = lambda c: d(c, 'Nat')
fdrq = lambda c, nr: R['st_fdr'][f'{c}|{nr}']['q']
reg = R['regress']; tuk = {(t['g1'], t['g2']): t for t in R['tukey']}
sub = X['subperiod_comp']; sreg = X['subperiod_regress']
tm = T; sos = T['SOS']; eos = T['EOS']; los = T['LOS']; spr = T['station_spread']
Tb, Te = TP['berk_detr'], TP['era_detr']
w = Mx['w500_zim_tests']; wo = Mx['w500_zim_tests_OND']
mz = Z
roll = conv['roll']; f81 = conv['f8110']; f91 = conv['f9120']; dtb = conv['detr_boxes']; had = conv['had_roll']
sep = conv['months(9,)']; octb = conv['months(10,)']; nov = conv['months(11,)']; aso = conv['months(8, 9, 10)']
ch_enp = CH['ext'][EP]; ch_eo = CH['ext'][EO]
thr_d = [t['d'] for t in thr]; thr_p = [t['p'] for t in thr]
nsig_thr = sum(1 for t in thr if t['p'] < 0.05)
convs_all = [roll, f81, f91, dtb, had, sep, octb, nov, aso]
den_d = [c['d'] for c in convs_all]; eo_d = [c['d_en'] for c in convs_all]
nsig_conv = sum(1 for c in convs_all if c['p'] < 0.05)
day = lambda x: x  # days
def rng(c):
    v = sorted(abs(d(c, nr)) for nr in NRS); return f'{v[0]:.1f}–{v[-1]:.1f}'
def mm(nr): return f'{abs(d(EP, nr))/100*nr_clim[nr]:.0f}'

TITLE = ('Compound hot–dry drought during co-occurring El Niño and positive Indian Ocean Dipole seasons in '
         'Zimbabwe’s agroecological Natural Regions: circulation, maize impacts, and implications for seasonal forecasting')
AUTHORS = '**\\*Desmond Manatsa**^1,2^, **Terence Mushore**^3^, **James Ngoma**^4^, **Isaac Masawana**^4^, **Rebecca Manzou**^4^'
AFFIL = ['^1^ Faculty of Science, School of Geosciences, Bindura University of Science and Education, Bindura, Zimbabwe',
         '^2^ Department of Geography, Faculty of Natural and Agricultural Sciences, University of the Free State, Qwaqwa Campus, Phuthaditjhaba 9866, South Africa',
         '^3^ Faculty of Science, Department of Physics and Space Science, University of Zimbabwe, Harare, Zimbabwe',
         '^4^ Zimbabwe Meteorological Services Department, Central Forecasting Office, Harare, Zimbabwe']
CORR = '\\*Corresponding author: D. Manatsa (dmanatsa@gmail.com; ORCID: 0000-0002-8119-6150)'

ABSTRACT = (
 f"Zimbabwe’s rain-fed maize depends on one summer rainfall season whose amount and reliability differ sharply across five agroecological Natural Regions (NRs). "
 f"We examine how the El Niño–Southern Oscillation (ENSO) and the Indian Ocean Dipole (IOD), alone and combined, relate to seasonal rainfall in each NR. "
 f"Representative station rainfall (1951–2017), extended to 2024 with CHIRPS v2.0, is composited by ENSO–IOD state, classified from ERSSTv5 indices with a documented moving 30-year base. "
 f"El Niño seasons with a positive IOD are the driest state in every NR, {a(d(EP,'I'),0)}% (NR I) to {a(d(EP,'III'),0)}% (NR III) below neutral seasons and significant after false-discovery control in NR II–V. "
 f"El Niño seasons with a neutral IOD show no consistent deficit. "
 f"The two modes combine additively. The co-occurrence events were also the stronger El Niño events, and the added IOD deficit is smaller after the early 1980s. "
 f"Significance depends on the index base period; the ordering of the El Niño states does not. "
 f"Co-occurrence seasons are {a(Tb[EP],1)}–{a(Te[EP],1)} °C warmer than average, reach moderate drought on the ERA5-based SPEI-6, start about {a(sos['comp'][EP]['d'],0)} days late and are about {a(los['comp'][EP]['d'],0)} days shorter. "
 f"They coincide with subsidence over Zimbabwe and a stronger Botswana High, but these regional indices add no rainfall information beyond the modes. "
 f"Maize production and yield fall {a(mz['cat'][EP]['mean'],0)}% and {a(YD['cat'][EP]['mean'],0)}% below trend in these seasons; most of the variance the modes explain is shared. "
 f"Because the IOD is observable in September–November, before planting, seasonal outlooks can condition El Niño risk on the IOD state and express it by NR.")

SIGNIF = (
 "Zimbabwe’s maize harvest rises and falls with summer rainfall. Forecasters watch El Niño, but El Niño alone has been an uneven guide. "
 "Over 1951–2024 the driest and hottest seasons came when El Niño coincided with a positive Indian Ocean Dipole, a warm western and cool eastern tropical Indian Ocean. "
 f"Those seasons were dry in all five farming regions, started about three weeks late, and coincided with maize output about a third below trend. "
 "The Indian Ocean signal is visible in September to November, before planting. "
 "Seasonal outlooks that report the Indian Ocean state alongside El Niño, region by region, can give farmers and planners earlier and more specific warning.")

# =====================================================================================  1 INTRODUCTION
H1('1 Introduction')
Pp("Rain-fed agriculture sustains most of Zimbabwe’s population, and the national economy remains tightly coupled to a single austral summer rainfall season that runs from about October to April. "
   "Year-to-year changes in this season translate directly into cereal production, water availability, hydropower generation and food security. "
   "The season is not uniform across the country. Zimbabwe is divided into five agroecological Natural Regions (NRs), defined by rainfall amount and reliability, and these regions are the units used for agricultural planning and advisories (Vincent and Thomas, 1961). "
   "Understanding how large-scale climate drivers affect each region is therefore both a scientific question and a prerequisite for useful early warning.")
Pp("The El Niño–Southern Oscillation (ENSO) is the best-documented driver of southern African summer rainfall. "
   "El Niño events are broadly associated with suppressed rainfall and drought over the subcontinent, and La Niña events with wetter conditions. "
   "These contrasts arise through shifts in the Walker circulation and in the position of tropical convection (Ropelewski and Halpert, 1987; Lindesay, 1988; Nicholson and Kim, 1997; Reason et al., 2000). "
   "The response is season-, region- and event-dependent. The ENSO influence on daily rainfall changes through the wet season (Hoell et al., 2021), and ENSO diversity, including central Pacific events, modulates the southern African signal (Ratnam et al., 2014).")
Pp("The Indian Ocean Dipole (IOD) is a coupled ocean–atmosphere mode defined by the zonal sea surface temperature (SST) gradient between the western and the southeastern tropical Indian Ocean (Saji et al., 1999; Webster et al., 1999). "
   "It grows during austral winter, peaks in September–November (SON) and decays rapidly by December, when the seasonal reversal of the monsoon winds removes the coupled wind–thermocline feedback that sustains it (Saji et al., 1999; Saji and Yamagata, 2003). "
   "During a positive IOD the western basin is anomalously warm and the eastern basin cool. "
   "Convection and low-level moisture convergence shift toward the western basin and East Africa, where the short rains are enhanced (Behera et al., 2005). "
   "Over Zimbabwe, positive IOD seasons have been associated with reduced rainfall and drought, particularly early in the season, while negative IOD seasons tend to be wetter (Manatsa et al., 2008; Manatsa and Matarira, 2009). "
   "Positive IOD events are statistically associated with El Niño and negative events with La Niña, yet each mode retains independent variability and can occur alone (Behera and Yamagata, 2003; Saji and Yamagata, 2003; Ummenhofer et al., 2009). "
   "Separating individual from combined influences has proved powerful for the Indian monsoon (Ashok et al., 2004). "
   "Because the IOD is partly independent of ENSO, its influence can either reinforce or offset the ENSO signal over Africa (Williams and Hanan, 2011).")
Pp("Both modes reach Zimbabwe through regional circulation systems. "
   "The Angola Low is a summer low over southern Angola and northern Namibia that draws moisture from the tropical Atlantic and the Congo basin into the subcontinent and helps organise the tropical–temperate cloud bands that deliver much of the summer rain (Munday and Washington, 2017; Howard and Washington, 2018). "
   "A weaker Angola Low reduces rainfall over the interior, and its strength varies with ENSO (Munday and Washington, 2017). "
   "The Botswana High is a mid-tropospheric anticyclone over Botswana and Namibia in summer. "
   "When it strengthens, subsidence increases and convection is suppressed over the southern African interior (Driver and Reason, 2017). "
   "Blamey et al. (2018) showed that the behaviour of these two systems helps explain why El Niño events of similar strength, such as 2015/16 and earlier events, produced different rainfall impacts. "
   "The regional systems therefore sit between the remote modes and local rainfall, and they carry variability of their own. "
   "Part of any rainfall signal attributed to ENSO or the IOD may be mediated, or modulated, by them.")
Pp("The combined influence of ENSO and the IOD on southern African rainfall has been examined before. "
   "Early studies established the ENSO signal (Ropelewski and Halpert, 1987; Nicholson and Kim, 1997) and its expression across the Indian Ocean basin (Reason et al., 2000). "
   "For Zimbabwe, Manatsa et al. (2008) argued that a positive IOD can dominate ENSO when the two compete, and Manatsa and Matarira (2009) showed that the relative roles of the two modes changed over time. "
   "At continental scale, Williams and Hanan (2011) found that ENSO and IOD effects on African ecosystems can interfere destructively. "
   "To our knowledge, three gaps remain. "
   "First, these studies analysed national or area-averaged rainfall, so they do not show how the joint signal differs between the Natural Regions in which agricultural decisions are made. "
   "Second, they did not contrast El Niño seasons with and without a positive IOD against a common neutral baseline, test formally whether the modes interact or add, or separate the IOD effect from the stronger El Niño events that tend to accompany a positive IOD. "
   "Third, the joint signal has not been traced within one consistent classification from rainfall through temperature, drought, season timing and circulation to maize production. "
   "A further obstacle is reproducibility. The Dipole Mode Index (DMI) is sensitive to the SST dataset, the base period and the treatment of trends, and different choices can change which years are classified as IOD events (Verdon-Kidd, 2018).")
Pp("Southern Africa is also a region where ENSO-related dry and hot extremes increasingly coincide (Hao et al., 2018; Zscheischler et al., 2018). "
   "Rainfall deficit and high evaporative demand then combine to maximise agricultural and hydrological stress. "
   "Rainfall-only metrics neglect this coupling, even though El Niño summers over southern Africa are characteristically hot as well as dry (Mbokodo et al., 2023).")
Pp("This study addresses these gaps for Zimbabwe. "
   "It makes five contributions. "
   "(i) It resolves the individual and co-occurring ENSO–IOD signals in each Natural Region over 1951–2017 and extends them to 2024 with an independent satellite–gauge record. "
   "(ii) It documents the index construction in full and reports the sensitivity of the results to base period, trend treatment, SST dataset, averaging months, thresholds and an equal-margin tercile classification. "
   "(iii) It tests additivity, the confounding of IOD state with El Niño strength, and nonstationarity. "
   "(iv) It assesses compound hot–dry conditions, season timing, regional circulation including the Botswana High and Angola Low, and the land surface, each by Natural Region. "
   "(v) It quantifies the imprint on national maize production. "
   "We test four hypotheses: (H1) El Niño and positive IOD seasons are drier than other seasons in every Natural Region; "
   "(H2) El Niño seasons that coincide with a positive IOD are drier than El Niño seasons with a neutral IOD; "
   "(H3) the rainfall response scales with regional mean rainfall; and "
   "(H4) co-occurrence seasons are compound hot–dry seasons, which an index that includes evaporative demand detects at least as well as rainfall.")

# =====================================================================================  2 DATA AND METHODS
H1('2 Data and methods')
H2('2.1 Study area and Natural Regions')
Pp("Zimbabwe (about 15.6–22.4°S, 25.2–33.1°E) is divided into five Natural Regions (NR I–V) on the basis of rainfall amount, reliability and agricultural potential (Vincent and Thomas, 1961). "
   "Boundaries are taken from the revised national Natural Region shapefile, which contains seven zones: I, IIa, IIb, III, IV, Va and Vb (Fig. S1). "
   "The sub-zones IIa and IIb are dissolved into NR II, and Va and Vb into NR V, giving five regions (Fig. 1). "
   f"Their areas, computed on an Albers equal-area projection, are {area['I']/1000:.1f}, {area['II']/1000:.1f}, {area['III']/1000:.1f}, {area['IV']/1000:.1f} and {area['V']/1000:.1f} × 10^3^ km^2^ for NR I–V. "
   f"Mean October–March (ONDJFM) rainfall from the station series (section 2.2) falls from {nr_clim['I']:.0f} mm in NR I to {nr_clim['II']:.0f}, {nr_clim['III']:.0f}, {nr_clim['IV']:.0f} and {nr_clim['V']:.0f} mm in NR II–V. "
   "NR I–II hold most of the country’s maize, tobacco, plantation and horticultural production. NR III is a semi-intensive mixed-farming zone. NR IV–V are dominated by extensive livestock and drought-tolerant small grains.")

H2('2.2 Station rainfall and representative regional series')
Pp("Station data come from the Meteorological Services Department (MSD) archive of 46 stations for 1951–2017. "
   "For each station and season the archive gives the ONDJFM rainfall total, the longest dry spell in each month from October to March, and the start, end and length of the season (section 2.3). "
   "The record ends in 2017 because station records after that year contain known reporting inconsistencies and are excluded. "
   "Seasons are labelled by their onset year, so 2015 denotes October 2015 to March 2016.")
Pp("*Station positions and allocation.* Station coordinates are taken from the MSD station register for the "
   f"{n_register} archive stations it lists. For the other {46-n_register} stations, the archive coordinates were checked against the named locations, and one (Chisumbanje) was corrected. "
   f"The archive coordinates differ from the register by more than 0.2° for {n_moved02 - 1} stations; for example, the archive positions of Nyanga, Mutoko and Rusape correspond to Mvurwi, Mutare and Mvuma (Table S5). "
   "Each station was then allocated to the Natural Region polygon that contains it. "
   f"This changed the region of {n_realloc} stations relative to the allocation used in the submitted version (Table S5). "
   f"The network has {nst['I']}, {nst['II']}, {nst['III']}, {nst['IV']} and {nst['V']} stations in NR I–V, that is {dens['I']:.1f}, {dens['II']:.1f}, {dens['III']:.1f}, {dens['IV']:.1f} and {dens['V']:.1f} stations per 10^4^ km^2^ (Fig. 1; Table S6). "
   "The number of stations is set by the archive rather than chosen. Density is therefore highest in the small, wet NR I and lowest in the large, dry NR V. "
   "Fig. S2 shows the number of stations reporting in each season. NR V has no reporting station before 1959.")
Pp("*Quality control.* Each seasonal total was compared with its station normal and with the other stations in the same region and season. "
   "A value was flagged if its ratio to the station normal was above 5 or below 0.1, or if that ratio was more than four times, or less than 0.15 times, the median ratio of the other stations in the same region and season. "
   f"Five values failed (Table S7). Two are about ten times the station normal (Belvedere and Kwekwe, 2014) and are consistent with misplaced decimal points. Three are below 50 mm for a full season (Gweru 1958, Rusape 1974 and Kezi 1987). "
   "All five were set to missing. "
   "For the timing variables, seasons with an onset on or after the cessation date were set to missing. "
   "This removed the timing record of Lupane, where onset follows cessation in 30 seasons, and three isolated values elsewhere (Table S7).")
Pp("*Representative series.* Regional series are built so that changes in the station network do not create spurious jumps. "
   "For each station, a normal is computed over 1983–2017 when at least five values exist in that period, and otherwise over the full record when at least three values exist. "
   "Each seasonal total is divided by its station normal. "
   "The ratios are averaged over the stations reporting in a region in each season, and the mean is multiplied by the average of the station normals in that region. "
   "This keeps the regional series in millimetres, while a station with a high or low normal joining or leaving the network does not shift the regional value. "
   "Timing and dry-spell variables are treated in the same way but with additive anomalies: each station value minus its normal is averaged over reporting stations and added to the regional mean normal. "
   "Regional rainfall anomalies are expressed as a percentage of the 1951–2017 regional mean, so the regions are directly comparable. "
   "The national series is the unweighted mean of the five regional percentage anomalies, so each region carries equal weight regardless of area; for 1951–1958 it is the mean of NR I–IV. "
   f"A region-season is flagged as low coverage when fewer than two stations report. Fourteen region-seasons are flagged, ten of them in NR V before 1961 (Table S6). "
   "Section 3.5 tests the sensitivity of the main result to these choices.")

H2('2.3 Season timing and dry-spell metrics')
Pp("The archive gives, for each station and season, the start of season (SOS), the end of season (EOS) and the length of season (LOS), in days from 1 July. "
   "They follow the operational definitions of MSD. "
   "Onset is the first day after 1 October on which at least 20 mm of rain accumulates within one to three consecutive days, provided that no dry spell of ten or more consecutive days follows in the next 30 days. "
   "The dry-spell condition excludes false starts, in which early rains are followed by a dry spell long enough to kill germinating crops. "
   "Cessation is derived from a daily soil-water balance, SW~t~ = max[0, min(AWC, SW~t−1~ + P~t~ − ET~t~)], where SW is the plant-available soil water, P is daily rainfall, "
   "ET is crop evapotranspiration estimated from reference evapotranspiration and crop coefficients, and AWC is the available water capacity of the root zone (60–100 mm, depending on soil and crop). "
   "Searching forward from 15 February, EOS is the first day on which plant-available soil water falls to zero without replenishment, or on which actual evapotranspiration falls below 35–40% of reference evapotranspiration. "
   "It marks the end of the moisture that can sustain crop growth. "
   "LOS is the number of days from onset to cessation. "
   f"The earliest onset in the archive is day {T['sos_min']:.0f} (1 October), consistent with the onset definition. "
   "Because onset and cessation dates differ strongly across the country, every composite is computed from station departures from each station’s own normal before averaging. "
   "A regional or national onset anomaly is therefore the mean of station departures, not a departure of one fixed calendar date. "
   "Timing composites are reported for each Natural Region, and the station-level spread is described by the interquartile range of station composites and the fraction of stations with a later or earlier onset (section 3.11; Table S11). "
   f"The earliest EOS in the archive is day {T['eos_min']:.0f} (2 March), and {100*T['eos_floor_frac']:.0f}% of station-seasons take this value. "
   "EOS is therefore bounded below, which limits its ability to register an early end to the rains (section 3.11). "
   "The monthly dry-spell metric is the longest run of dry days in each month from October to March. "
   "As an independent check we derived onset and monthly maximum dry spells from daily CHIRPS rainfall (section 2.4) for 1981–2024. "
   "CHIRPS onset uses the same MSD criterion, with a dry day defined as less than 1 mm.")

H2('2.4 Gridded rainfall, drought, temperature, land-surface and circulation data')
Pp("*Rainfall.* The Climate Hazards Group InfraRed Precipitation with Station data, version 2.0 (CHIRPS v2.0; Funk et al., 2015), provides daily rainfall for 1981–2024. "
   "We use the 0.25° daily aggregation of the native 0.05° product distributed by the KNMI Climate Explorer. "
   "We retain v2.0 because it is complete for 1981–2024 and is the version used in most validation studies over southern Africa; the newer v3.0, which changes the station blending, is left for future comparison. "
   "Monthly and seasonal totals are averaged over all grid cells whose centres fall inside each Natural Region polygon. "
   "CHIRPS is used to validate the station series over 1981–2017 and to extend the analysis to 2024 (section 3.12).")
Pp("*Drought.* Drought is quantified with the six-month Standardised Precipitation–Evapotranspiration Index (SPEI-6; Vicente-Serrano et al., 2010; Beguería et al., 2014) from the ERA5–Drought dataset (Keune et al., 2025). "
   "ERA5–Drought computes SPEI for several accumulation periods at 0.25° from ERA5 precipitation and potential evapotranspiration, with a generalised logistic distribution fitted over the 1991–2020 reference period. "
   "We take the March value of SPEI-6, whose six-month window spans October–March, and average it within each Natural Region. "
   f"SPEI-6 correlates with the station rainfall series at r = {spei_r['Nat']:.2f} nationally and {min(v for k,v in spei_r.items() if k!='Nat'):.2f}–{max(v for k,v in spei_r.items() if k!='Nat'):.2f} by region.")
Pp("*Temperature.* Daily maximum temperature (Tmax) comes from the Berkeley Earth 1° land product (Rohde and Hausfather, 2020) and from ERA5 2 m temperature at 0.25° (Hersbach et al., 2020). "
   "Both are averaged over Zimbabwe for December–February (DJF), for 1970–2024, and linearly detrended to remove the warming trend "
   f"({TP['trend_berk']*10:.2f} °C per decade in Berkeley Earth). "
   f"The two detrended series correlate at r = {TP['r_berk_era']:.2f}. "
   "The CRU TS dataset used in the submitted version was replaced by ERA5, because CRU TS relaxes towards climatology where station coverage is sparse (Harris et al., 2020) and a reanalysis provides a check that does not depend on station density.")
Pp("*Land surface.* Upper-layer soil moisture (kg m^−2^) comes from ERA5-Land (Muñoz-Sabater et al., 2021), and an evaporative-stress index is computed as ERA5 potential minus actual evaporation (mm d^−1^). "
   "Both are averaged within each Natural Region over DJF, for 1951–2024, and linearly detrended.")
Pp("*Circulation.* Monthly ERA5 500 hPa vertical velocity (ω500, 1950–2024) and 500 and 850 hPa geopotential height (Z500 and Z850, 1980–2024) are regridded to 0.5° over southern Africa (10°N–35°S, 11–41°E). "
   "Positive ω500 denotes descent. "
   "A Zimbabwe-mean ω500 is computed over the land mask of the country. "
   "A Botswana High index is defined as DJF Z500 averaged over 18–26°S, 18–28°E, a box around the climatological mid-level anticyclone (Driver and Reason, 2017). "
   "An Angola Low index is defined as DJF Z850 averaged over 11–19°S, 14–25°E, the region of the low identified by Howard and Washington (2018); lower heights denote a deeper low. "
   "Height fields and both indices are linearly detrended.")

H2('2.5 Maize production')
Pp("National maize production (thousand tonnes) is taken from the United States Department of Agriculture (USDA) Production, Supply and Distribution database for 1960–2024. "
   "Each value is mapped to the growing season that produced it. "
   "The USDA series changes its year convention at 2000: the values labelled 1999 and 2000 are identical, labels up to 1999 refer to the harvest of the season that began in that year, and labels from 2001 refer to the harvest year. "
   "We therefore map labels up to 1999 to the same onset year and labels from 2001 to the previous onset year. "
   "The mapping was checked against known drought harvests: the 1991/92, 2015/16 and 2023/24 seasons map to 360, 512 and 635 thousand tonnes. "
   "Production also varies for non-climatic reasons, including a step change with the fast-track land reform from 2000. "
   "A linear trend is therefore removed separately for 1960–1999 and 2000–2023, and the residual is expressed as a percentage of the trend value. "
   "This residual isolates the year-to-year variability available for a climate signal.")
Pp("National maize yield (kg ha^−1^), area harvested (ha) and production (t) for 1961–2024 are taken from FAOSTAT (FAO, 2026) as a check on the USDA series. "
   "FAOSTAT years are harvest years, so harvest year H is assigned to the season with onset year H − 1. "
   "Values from 1970 onward are mostly official figures; most values for the 1960s are FAO estimates or figures from external organizations. "
   "All three series are detrended in the same two eras as USDA production. "
   "Because production is the product of yield and area, the FAOSTAT series show whether a production loss reflects lower yield per hectare or a smaller harvested area.")

H2('2.6 Climate indices and event classification')
Pp("*ENSO.* The Niño 3.4 index is the area-mean SST anomaly over 5°N–5°S, 170°–120°W from the Extended Reconstructed SST version 5 (ERSSTv5, 2° resolution; Huang et al., 2017). "
   "Anomalies follow the convention of the NOAA Climate Prediction Center (CPC) for the Oceanic Niño Index (ONI). "
   "Each five-year block is referenced to a centred 30-year base (for example, 1956–1960 to 1941–1970), and 1991–2020 is used from 2011 onward. "
   "A moving base removes the slow SST warming from the anomalies without fitting a trend, while preserving interannual variability. "
   "The monthly index is averaged over December–February (DJF) to give the ONI of each season.")
Pp("*IOD.* The DMI follows Saji et al. (1999). It is the difference between area-mean SST over the western tropical Indian Ocean (50–70°E, 10°S–10°N) and the southeastern tropical Indian Ocean (90–110°E, 10°S–0°), both cosine-latitude weighted and taken from the same ERSSTv5 field. "
   "The moving 30-year base is applied separately to each box before the difference is taken. "
   "Blocks before 1966 use 1950–1979, the earliest 30 years available in the field. "
   "No additional detrending is applied. "
   "The DMI is averaged over September–November (SON), the season in which the IOD peaks (Saji et al., 1999; Saji and Yamagata, 2003). "
   "SON lies in the onset year, so it precedes the DJF season used for ENSO and coincides with the first half of the rainfall season.")
Pp("*Classification.* A season is El Niño when its DJF ONI ≥ +0.5 °C and La Niña when it is ≤ −0.5 °C. "
   "It has a positive IOD when its SON DMI ≥ +0.4 °C and a negative IOD when it is ≤ −0.4 °C. "
   "Each season falls into one of nine combinations (Table 1; Table S1). "
   "Composites focus on the four combinations that are populated well enough to composite: El Niño with a positive IOD (EN & +IOD), El Niño with a neutral IOD (EN only), La Niña with a neutral IOD (LN only) and La Niña with a negative IOD (LN & −IOD). "
   "Seasons with neutral ENSO and neutral IOD form the baseline. "
   "El Niño events are also divided into moderate (0.5 ≤ ONI < 1.0 °C) and strong (ONI ≥ 1.0 °C).")
Pp("*Sensitivity.* Because these choices can change the classification (Verdon-Kidd, 2018), we repeat the main analysis with: fixed 1981–2010 and 1991–2020 base periods without detrending; a fixed base with a linear trend removed from each box before differencing (and, equivalently for a linear trend, from the index); the HadISST1 DMI (Rayner et al., 2003) with the moving base; single-month DMI values for September, October and November and an August–October mean; and thresholds of ±0.4, ±0.5 and ±0.6 °C for the ONI and ±0.3, ±0.4 and ±0.5 °C for the DMI (Fig. S3; Tables S2 and S3). "
   "Fixed thresholds give unequal sample sizes. "
   "We therefore also classify seasons by terciles of the DJF ONI and SON DMI over 1951–2017, following Ficchì et al. (2021). "
   "Each tercile holds about 22 seasons, so the marginal categories are balanced and the 3 × 3 table of joint categories shows where the seasons fall (Table S4).")

H2('2.7 Statistical analysis')
Pp("For each Natural Region and nationally, individual-mode composites (all El Niño, all La Niña, all positive IOD and all negative IOD seasons) are compared with the remaining seasons. "
   "Co-occurrence composites are compared with the neutral baseline, so that one state is not contrasted with a mixture of opposite states. "
   "Differences are tested with Welch’s two-sample *t*-test. "
   "Uncertainty in each composite difference is given by a 95% confidence interval from 10 000 bootstrap resamples (Efron, 1979). "
   "Multiple testing across the five regions and four co-occurrence categories (20 tests) is controlled with the Benjamini–Hochberg false-discovery rate (FDR; Benjamini and Hochberg, 1995), and we report the adjusted *q* values. "
   "Differences among the four co-occurrence categories are tested with one-way analysis of variance (ANOVA) and Tukey’s honestly significant difference test.")
Pp("To test whether the modes interact or simply add, national rainfall is regressed on the DJF ONI, the SON DMI and their product, and the model is compared with the additive model by a nested *F*-test. "
   "To test whether the co-occurrence effect reflects the stronger El Niño events that accompany a positive IOD, we regress rainfall within El Niño seasons on the ONI and a positive-IOD indicator, and we compare moderate and strong events separately. "
   "The relation between regional sensitivity and regional mean rainfall is tested with Spearman’s rank correlation. "
   "Partial correlations between each rainfall parameter and each index, controlling for the other index, identify which driver tracks which part of the season. "
   "The ability of SPEI-6 and rainfall to separate El Niño seasons from other seasons is compared with the standardised mean difference (Cohen’s *d*). "
   "Nonstationarity is examined with 20-season sliding correlations between the DJF ONI and national rainfall, with regressions for sub-periods, and with a Pettitt change-point test. "
   "Predictive information is assessed by leave-one-out cross-validation of a linear model of national rainfall on the two indices, for concurrent (DJF ONI and SON DMI), end-of-November (SON) and pre-season (August–September) predictors. "
   "For maize, a variance partition separates the production variance explained uniquely by each index from the variance they share.")

# =====================================================================================  3 RESULTS
H1('3 Results')
H2('3.1 Event chronology and co-occurrence structure')
Pp(f"Over 1951–2017 the classification gives {chron['nEN']} El Niño, {chron['nLN']} La Niña, {chron['nP']} positive IOD and {chron['nM']} negative IOD seasons (Table 1; Fig. 2). "
   f"The two modes are linked: the DJF ONI and SON DMI correlate at r = {chron['r_oni_dmi']:.2f} (Fig. 2a). "
   f"Nine of the {chron['nP']} positive IOD seasons occur with El Niño, and {chron['M_given_LN']} of the {chron['nM']} negative IOD seasons occur with La Niña. "
   f"The opposing combinations are rare: El Niño with a negative IOD (1958) and La Niña with a positive IOD (1967) occur once each. "
   f"The populated combinations are El Niño with a positive IOD ({c51[EP]} seasons), El Niño only ({c51[EO]}), La Niña only ({c51[LO]}), La Niña with a negative IOD ({c51[LM]}) and the neutral baseline ({c51['Neutral']}) (Fig. 2b). "
   f"The extension to 2024 adds three El Niño with positive IOD seasons (2018, 2019 and 2023), three La Niña only seasons and one La Niña with negative IOD season (2022), giving {c524[EP]}, {c524[LO]} and {c524[LM]} seasons in these categories. "
   "Compared with the submitted classification, which used a fixed base without detrending, 18 of the 67 seasons change category. "
   "The ENSO phase changes in 12 seasons and the IOD phase in 17, mostly for seasons with index values close to a threshold (Table S1). "
   "For example, 1987 and 1991 move from El Niño with a positive IOD to El Niño only, because their SON DMI values are 0.31 and 0.36 °C.")
TAB(['Category', 'n', 'Seasons (onset year)'],
    [[LAB[c], str(c51.get(c, 0)) + (f' (+{c524[c]-c51.get(c,0)})' if c524.get(c, 0) > c51.get(c, 0) else ''),
      ', '.join(str(y) for y in chron['years'][c] if y <= 2017) + ((' [' + ', '.join(str(y) for y in chron['years'][c] if y > 2017) + ']') if any(y > 2017 for y in chron['years'][c]) else '')]
     for c in [EP, EO, 'EN+nIOD', 'pIOD only', 'Neutral', 'nIOD only', 'LN+pIOD', LO, LM]],
    '**Table 1.** Classification of austral summer seasons 1951–2017 by DJF ONI (±0.5 °C) and SON DMI (±0.4 °C), both from ERSSTv5 with a moving 30-year base. Numbers in parentheses and years in brackets are the additional seasons in the CHIRPS extension, 2018–2024. Index values for every season are given in Table S1.',
    widths=[1.4, 0.6, 4.5], align=['left', 'center', 'left'])

H2('3.2 Rainfall response by Natural Region')
Pp("The rainfall response is examined first in each Natural Region (Fig. 3; Table 2), because the regions differ by a factor of two in mean rainfall and are the units in which drought is managed. "
   f"El Niño seasons with a positive IOD are the driest state in every region (Fig. 3a,c). "
   f"Relative to neutral seasons, their deficits are {s(d(EP,'I'))}% in NR I, {s(d(EP,'II'))}% in NR II, {s(d(EP,'III'))}% in NR III, {s(d(EP,'IV'))}% in NR IV and {s(d(EP,'V'))}% in NR V. "
   f"All five bootstrap intervals exclude zero (Fig. 3c). After FDR control the deficit is significant in NR II–V (*q* = {min(fdrq(EP,nr) for nr in ['II','III','IV','V']):.3f}–{max(fdrq(EP,nr) for nr in ['II','III','IV','V']):.3f}) but not in NR I ({Q(fdrq(EP,'I'))}), the smallest region with only three stations. "
   f"The deficit is largest in the central NR III ({s(d(EP,'III'))}%, {cis(EP,'III')}), the main semi-intensive farming belt.")
Pp(f"El Niño seasons with a neutral IOD show no consistent deficit in any region (Fig. 3b). "
   f"Their anomalies range from {s(d(EO,'I'))}% in NR I to {s(d(EO,'V'))}% in NR V, and none is significant ({Q(min(fdrq(EO,nr) for nr in NRS))} or larger). "
   f"La Niña seasons with a negative IOD are the wettest state in every region, from {s(d(LM,'I'))}% in NR I to {s(d(LM,'IV'))}% in NR IV. None survives FDR control ({Q(min(fdrq(LM,nr) for nr in NRS))} or larger), although the national composite is significant (section 3.3). "
   f"La Niña only seasons are moderately wet ({s(min(d(LO,nr) for nr in NRS))} to {s(max(d(LO,nr) for nr in NRS))}%) and not significant in any region.")
Pp(f"The individual modes show the same geography (Table 2). "
   f"Compared with all other seasons, El Niño seasons are {rng('EN')}% drier and positive IOD seasons {rng('pIOD')}% drier across the regions. "
   f"The positive IOD composite is the larger of the two because {chron['P_given_EN']} of its {chron['nP']} seasons are also El Niño seasons, and these include the strongest events (section 3.4). "
   f"La Niña seasons are {rng('LN')}% wetter, and negative IOD seasons {rng('nIOD')}% wetter.")
Pp(f"The response does not increase with mean rainfall. "
   f"With five regions, the Spearman correlation between regional mean rainfall and the deficit is ρ = {R['spearman']['EN']['rho']:.1f} ({P(R['spearman']['EN']['p'])}) for all El Niño seasons and ρ = {R['spearman'][EP]['rho']:.1f} ({P(R['spearman'][EP]['p'])}) for the co-occurrence state. "
   "The positive sign means that the wetter regions lose a smaller fraction of their rainfall, not a larger one. "
   "Hypothesis H3 is therefore rejected. "
   f"In absolute terms the losses are similar across the wetter regions. A co-occurrence season removes about {mm('I')} mm in NR I, {mm('II')} mm in NR II and {mm('III')} mm in NR III, against {mm('IV')} mm in NR IV and {mm('V')} mm in NR V. "
   "The central region NR III loses the most rainfall both in millimetres and as a share of its mean, and the dry NR V loses the second-largest share.")

def tabrow(c, ref):
    row = [LAB[c] + ref]
    for nr in NRS + ['Nat']:
        v = d(c, nr); pp = p(c, nr)
        star = ''
        if c in (EP, EO, LO, LM) and nr != 'Nat':
            star = '\\*' if fdrq(c, nr) < 0.05 else ''
        elif pp < 0.05: star = '\\*'
        row.append(f'{s(v)}{star}')
    return row
rows2 = [tabrow(c, ' (vs other)') for c in ['EN', 'LN', 'pIOD', 'nIOD']] + [tabrow(c, ' (vs neutral)') for c in [EP, EO, LO, LM]]
rows2.append(['Mean ONDJFM rainfall (mm)'] + [f"{nr_clim[nr]:.0f}" for nr in NRS] + [''])
rows2.append(['Stations (per 10^4^ km^2^)'] + [f"{nst[nr]} ({dens[nr]:.1f})" for nr in NRS] + [str(46)])
TAB(['Category', 'NR I', 'NR II', 'NR III', 'NR IV', 'NR V', 'National'], rows2,
    '**Table 2.** Composite seasonal (ONDJFM) rainfall anomaly (% of the regional mean) by Natural Region, station series 1951–2017. Individual modes are compared with all other seasons; co-occurrence states are compared with the 15 neutral seasons. Sample sizes: El Niño 24, La Niña 23, positive IOD 11, negative IOD 11, El Niño & +IOD 9, El Niño only 14, La Niña only 16, La Niña & −IOD 6. An asterisk marks *q* < 0.05 after Benjamini–Hochberg FDR control across the 20 region × co-occurrence tests, and *p* < 0.05 (Welch) for the individual modes and the national column. Full *p* values, *q* values and bootstrap intervals are in Table S8.',
    widths=[2.0, 0.75, 0.75, 0.75, 0.75, 0.75, 0.85])

FIG('Fig01_study_area',
    f'**Figure 1.** Zimbabwe’s five agroecological Natural Regions (NR I–V) and the 46 Meteorological Services Department stations, plotted at their corrected positions (Table S5). Symbol size is proportional to the number of seasons with data. Dashed lines mark the sub-zone boundaries (IIa/IIb and Va/Vb) that are dissolved into NR II and NR V (Fig. S1). The legend gives, for each region, the number of stations, the area and the mean ONDJFM rainfall of the station series, 1951–2017. The inset locates Zimbabwe in southern Africa.')
FIG('Fig03_NR_responses',
    f'**Figure 3.** Seasonal rainfall response by Natural Region, station series 1951–2017. (a) El Niño & +IOD minus neutral seasons ({n(EP)} and 15 seasons). (b) El Niño only minus neutral ({n(EO)} seasons). Labels give the regional anomaly in percent of the regional mean; an asterisk marks *q* < 0.05 after FDR control. (c) Composites for the four co-occurrence states in each region, with 95% bootstrap confidence intervals; the mean ONDJFM rainfall of each region is given below its label.')

H2('3.3 National synthesis')
Pp(f"The national series summarises the regional pattern (Fig. 4a). "
   f"El Niño seasons with a positive IOD are {a(nat(EP))}% drier than neutral seasons ({cis(EP)}, {P(p(EP))}). "
   f"El Niño only seasons differ from neutral by {s(nat(EO))}% ({P(p(EO))}). "
   f"La Niña seasons are wetter, by {s(nat(LO))}% with a neutral IOD ({P(p(LO))}) and {s(nat(LM))}% with a negative IOD ({P(p(LM))}). "
   f"The four states differ significantly (ANOVA *F* = {R['anova']['F']:.2f}, {P(R['anova']['p'])}). "
   f"In the Tukey comparisons, El Niño & +IOD differs from both La Niña states ({P(tuk[(EP,LO)]['p'])} and {P(tuk[(EP,LM)]['p'])}), while its difference from El Niño only ({s(tuk[(EO,EP)]['diff'])} percentage points) is marginal ({P(tuk[(EO,EP)]['p'])}). "
   "The national time series (Fig. 4b) shows that five of the six driest seasons in the station record are co-occurrence seasons: 1972/73, 1982/83, 1986/87, 1994/95 and 2015/16. "
   "The driest, 1991/92, is an El Niño only season under the revised classification, because its SON DMI (0.36 °C) is just below the threshold. "
   "The 2023/24 co-occurrence season, outside the station record, is the second driest season in CHIRPS (section 3.12).")
Pp("These national values are a synthesis, not a substitute, for the regional results. "
   "The national deficit is close to the regional mean because all five regions respond in the same direction. "
   f"It hides a range from {a(d(EP,'I'),0)}% in NR I to {a(d(EP,'III'),0)}% in NR III, and a difference in the confidence that each regional value carries, which reflects station density (section 3.5).")
FIG('Fig04_national',
    f'**Figure 4.** National synthesis. (a) National rainfall anomaly relative to neutral seasons for the four co-occurrence states, 1951–2017, with 95% bootstrap intervals and Welch *p* values. (b) National ONDJFM rainfall anomaly by onset year from the station series (1951–2017) and CHIRPS v2.0 (1981–2024); red and blue shading mark El Niño & +IOD and La Niña & −IOD seasons. (c) National March SPEI-6 (ERA5–Drought) by state, with 95% bootstrap intervals; the dashed line marks moderate drought (−1.0). (d) Correlation between DJF ONI and national rainfall in sliding 20-season windows, plotted at the window centre; the dashed line is the 5% significance level.')

H2('3.4 Additivity, El Niño strength and the separate role of the IOD')
Pp(f"The deep co-occurrence deficit does not require an interaction between the modes. "
   f"In a continuous model of national rainfall, the ONI×DMI product term is not significant ({P(reg['pF_int'])}). "
   f"The additive model explains {100*reg['r2']:.0f}% of the variance, with standardised coefficients of {s(reg['beta_oni'],2)} for the ONI ({P(reg['p_oni'])}) and {s(reg['beta_dmi'],2)} for the DMI ({P(reg['p_dmi'])}). "
   f"Using the mean index values of each state, this model predicts {s(R['additive_check'][EP]['pred'])}% for El Niño & +IOD against {s(R['additive_check'][EP]['obs'])}% observed, and {s(R['additive_check'][EO]['pred'])}% for El Niño only against {s(R['additive_check'][EO]['obs'])}% observed. "
   "The co-occurrence state is therefore severe because two drying tendencies add, not because they multiply. "
   "This agrees with Williams and Hanan (2011), who found that ENSO and IOD effects over southeastern Africa can superpose or even offset rather than multiply.")
Pp(f"The two El Niño states also differ in strength. "
   f"The mean DJF ONI is {R['oni_by_cat'][EP]:.2f} °C in El Niño & +IOD seasons and {R['oni_by_cat'][EO]:.2f} °C in El Niño only seasons, and six of the nine co-occurrence seasons are strong events (Fig. 5d). "
   f"Part of the contrast between them is therefore a contrast in ENSO strength. "
   f"Two checks suggest that the IOD still adds information. "
   f"Among strong events, El Niño & +IOD seasons are {a(IN['strong EN+pIOD']['d'])}% drier than neutral (n = {IN['strong EN+pIOD']['n']}, {P(IN['strong EN+pIOD']['p'])}), whereas strong El Niño only seasons are {a(IN['strong EN only']['d'])}% drier (n = {IN['strong EN only']['n']}, {P(IN['strong EN only']['p'])}). "
   f"Among moderate events the values are {s(IN['moderate EN+pIOD']['d'])}% (n = {IN['moderate EN+pIOD']['n']}) and {s(IN['moderate EN only']['d'])}% (n = {IN['moderate EN only']['n']}). "
   f"Within the {R['en_matched']['n']} El Niño seasons, a positive-IOD indicator adds {s(R['en_matched']['b_p'])} percentage points after controlling for the ONI ({P(R['en_matched']['p_p'])}). "
   "The IOD effect is thus of the expected sign and similar size at both strengths, but with these sample sizes it cannot be fully separated from ENSO intensity. "
   "We therefore describe the co-occurrence state as the driest ENSO–IOD state and the positive IOD as a marker of the most severe El Niño seasons, rather than as the single cause of the deficit.")

H2('3.5 Robustness to index conventions, thresholds and terciles')
Pp(f"The ordering of the two El Niño states is robust; the significance of the co-occurrence deficit is not (Fig. 5; Tables S2–S4). "
   f"Across the nine threshold combinations, the El Niño & +IOD composite ranges from {s(max(thr_d))}% to {s(min(thr_d))}% and is significant in {nsig_thr} of them (Fig. 5a). "
   f"In every combination it is drier than El Niño only. "
   f"Across the index conventions it ranges from {s(max(den_d))}% to {s(min(den_d))}%, while El Niño only ranges from {s(max(eo_d))}% to {s(min(eo_d))}% and is never significant (Fig. 5b). "
   f"The deficit is significant with the moving base ({P(roll['p'])}), the fixed 1991–2020 base ({P(f91['p'])}), single-month September ({P(sep['p'])}) and November ({P(nov['p'])}) DMI values and the August–October DMI ({P(aso['p'])}). "
   f"It is weaker and not significant with the fixed 1981–2010 base ({s(f81['d'])}%, {P(f81['p'])}), with linearly detrended boxes ({s(dtb['d'])}%, {P(dtb['p'])}), with the HadISST1 DMI ({s(had['d'])}%, {P(had['p'])}) and with the October DMI ({s(octb['d'])}%, {P(octb['p'])}). "
   "The fixed 1981–2010 base reproduces the submitted classification most closely (65 of 67 ENSO and 62 of 67 IOD phases). "
   f"Under a fixed base without detrending, the indices drift with the long-term warming. The fixed-base SON DMI rises by {X['dmi_trend']['fixed8110_per_decade']:.2f} °C per decade, from a mean of {s(X['dmi_trend']['fixed_mean_1951_1980'],2)} °C in 1951–1980 to {s(X['dmi_trend']['fixed_mean_1995_2024'],2)} °C in 1995–2024, and the fixed-base DJF Niño 3.4 averages {s(X['dmi_trend']['n34_fixed_mean_1951_1980'],2)} °C over 1951–1980. "
   f"Early seasons are therefore pushed towards La Niña and negative IOD, and recent seasons towards positive IOD. With the moving base the DMI trend is {X['dmi_trend']['roll_per_decade']:.2f} °C per decade and not significant. "
   "We use the moving base as the primary convention because it is the CPC operational convention for the ONI, not because it gives the largest effect; the fixed 1991–2020 base gives a larger one.")
Pp(f"The result is also insensitive to station choices (Fig. 5b; Table S2). "
   f"Using the MSD station allocation instead of the polygon allocation gives {s(RS['msd membership']['enp'])}% ({P(RS['msd membership']['enp_p'])}). "
   f"Omitting the quality control gives {s(RS['no QC (poly)']['enp'])}%, and excluding the low-coverage region-seasons gives {s(RS['exclude <2-station region-years']['enp'])}%. "
   f"Starting in 1959, when NR V enters the record, gives {s(X['nat_1959']['EN+pIOD'][1])}% ({P(X['nat_1959']['EN+pIOD'][2])}), and a national mean of NR I–IV only gives {s(X['nat_NRI_IV']['EN+pIOD'][1])}%.")
tw = TER['warm|pos']; tm_ = R['tercile_marg']
Pp(f"The tercile classification balances the marginal samples at 22–23 seasons each (Fig. 5c; Table S4). "
   f"Seasons in the warm ONI tercile are {a(tm_['warm ONI']['d'])}% drier than other seasons ({P(tm_['warm ONI']['p'])}), and seasons in the positive DMI tercile {a(tm_['pos DMI']['d'])}% drier ({P(tm_['pos DMI']['p'])}). "
   f"Seasons in the cold ONI tercile are {a(tm_['cold ONI']['d'])}% wetter ({P(tm_['cold ONI']['p'])}), and those in the negative DMI tercile {a(tm_['neg DMI']['d'])}% wetter ({P(tm_['neg DMI']['p'])}). "
   f"The joint warm/positive cell holds {tw['n']} seasons, with a mean anomaly of {s(tw['mean'])}%. It is {a(tw['vs_mid']['d'])}% drier than the middle/middle cell ({P(tw['vs_mid']['p'])}) and drier in every region, most strongly in NR III ({s(tw['nr']['III'])}%). "
   f"The warm/middle cell, the nearest tercile analogue of El Niño only, has a mean anomaly of {s(TER['warm|mid']['mean'])}% (n = {TER['warm|mid']['n']}). "
   "The joint cells remain unequal because the two indices are correlated, so equal margins cannot give equal joint samples. "
   "The tercile analysis therefore confirms the direction of the result without the threshold-dependent sample sizes, but it does not remove the dependence of the joint states on the ENSO–IOD correlation.")
FIG('Fig05_robustness',
    '**Figure 5.** Robustness of the co-occurrence signal, national station series. (a) El Niño & +IOD minus neutral (%) for nine combinations of ONI and DMI thresholds; the lower line in each cell gives El Niño only minus neutral; bold marks *p* < 0.05. (b) El Niño & +IOD (circles) and El Niño only (squares) minus neutral under alternative index conventions and data choices, with 95% bootstrap intervals; the right column gives the two sample sizes. (c) Mean national anomaly (% of the 1951–2017 mean) in each cell of a tercile classification of DJF ONI and SON DMI (Ficchì et al., 2021), with the number of seasons. (d) Moderate (0.5 ≤ ONI < 1.0 °C) and strong (ONI ≥ 1.0 °C) El Niño seasons with and without a positive IOD, relative to neutral.')

H2('3.6 Nonstationarity')
Pp(f"The ENSO teleconnection has strengthened over the record (Fig. 4d). "
   f"The 20-season correlation between the DJF ONI and national rainfall rises in magnitude from {s(NS['first'],2)} in 1951–1970 to {s(NS['min_r'],2)} in {NS['min_win']}–{NS['min_win']+19}, and it is {s(NS['last'],2)} in the final window, 1998–2017. "
   f"The regression slope steepens from {s(NS['slope_pre'])}% per °C before 1990 to {s(NS['slope_post'])}% per °C after. "
   f"National rainfall shows a weak, non-significant decline ({s(NS['trend_pct_per_decade'])}% per decade, {P(NS['trend_p'])}) and no significant change point (Pettitt {P(NS['pettitt_p'])}).")
Pp(f"The change affects the co-occurrence contrast. "
   f"Before 1983, El Niño & +IOD seasons were {a(sub['1951-1982']['EN+pIOD'][1])}% drier than neutral (n = {sub['1951-1982']['EN+pIOD'][0]}), while El Niño only seasons were not dry ({s(sub['1951-1982']['EN only'][1])}%, n = {sub['1951-1982']['EN only'][0]}). "
   f"Over 1983–2017 the values are {s(sub['1983-2017']['EN+pIOD'][1])}% (n = {sub['1983-2017']['EN+pIOD'][0]}, {P(sub['1983-2017']['EN+pIOD'][2])}) and {s(sub['1983-2017']['EN only'][1])}% (n = {sub['1983-2017']['EN only'][0]}, {P(sub['1983-2017']['EN only'][2])}). "
   f"The co-occurrence state is the driest in both periods, but in the later period El Niño alone also produces substantial deficits. "
   f"Regressions for the two periods tell the same story. "
   f"The standardised DMI coefficient is {s(sreg['1951-1982']['beta_dmi'],2)} before 1983 and {s(sreg['1983-2017']['beta_dmi'],2)} after, while the ONI coefficient grows from {s(sreg['1951-1982']['beta_oni'],2)} to {s(sreg['1983-2017']['beta_oni'],2)} ({P(sreg['1983-2017']['p_oni'])}). "
   "Manatsa and Matarira (2009) also found that the relative roles of the two modes over Zimbabwe have changed with time; the sub-period results here quantify such a change for the co-occurrence states. "
   "It means that the large difference between El Niño with and without a positive IOD in the full record is driven partly by the early decades, when the ENSO teleconnection was weak and most El Niño only seasons occurred.")

H2('3.7 Compound hot–dry conditions')
Pp(f"Dry seasons are also hot seasons. "
   f"National rainfall and detrended DJF Tmax correlate at r = {TP['r_rain_berk_st']:.2f} over 1970–2017 ({P(TP['p_rain_berk_st'])}; Fig. 6b). "
   f"El Niño & +IOD seasons are the hottest state: detrended DJF Tmax is {s(Tb[EP],2)} °C in Berkeley Earth and {s(Te[EP],2)} °C in ERA5, compared with {s(Tb[EO],2)} and {s(Te[EO],2)} °C in El Niño only seasons (Fig. 6a). "
   f"Relative to neutral seasons the co-occurrence anomaly is {s(TP['berk_vs_neu'][EP]['d'],2)} °C ({P(TP['berk_vs_neu'][EP]['p'])}) and {s(TP['era_vs_neu'][EP]['d'],2)} °C ({P(TP['era_vs_neu'][EP]['p'])}), while the El Niño only anomaly ({s(TP['berk_vs_neu'][EO]['d'],2)} °C) is not significant. "
   f"La Niña & −IOD seasons are the coolest ({s(Tb[LM],2)} and {s(Te[LM],2)} °C). "
   "The driest state is therefore also the hottest, which defines a compound hot–dry regime.")
Pp(f"SPEI-6 shows the same ordering in every region (Fig. 4c; Table S12). "
   f"The national March SPEI-6 is {s(SP['abs'][EP],2)} in El Niño & +IOD seasons, at the threshold of moderate drought, against {s(SP['abs'][EO],2)} in El Niño only and {s(SP['abs']['Neutral'],2)} in neutral seasons. "
   f"By region it ranges from {s(max(SP['abs_nr'][EP].values()),2)} in NR I to {s(min(SP['abs_nr'][EP].values()),2)} in NR III, and the difference from neutral is significant everywhere ({P(max(SP['comp'][EP][nr]['p'] for nr in NRS))} or smaller). "
   f"SPEI-6 separates El Niño seasons from other seasons more sharply than rainfall in every region (Fig. 6c). "
   f"Nationally, |*d*| rises from {a(R['cohen']['Nat']['rain'],2)} for rainfall to {a(R['cohen']['Nat']['spei'],2)} for SPEI-6, and the largest gains are in "
   + ' and '.join(f"NR {nr} ({a(R['cohen'][nr]['rain'],2)} to {a(R['cohen'][nr]['spei'],2)})" for nr in sorted(NRS, key=lambda k: abs(R['cohen'][k]['spei'])-abs(R['cohen'][k]['rain']), reverse=True)[:2]) + '. '
   "Because SPEI-6 includes evaporative demand, this gain is consistent with the temperature signal adding to the rainfall signal. "
   "Hypothesis H4 is supported. "
   "SPEI-6 and the station series share part of their rainfall information, so the two are not fully independent tests.")
FIG('Fig06_hot_dry',
    f"**Figure 6.** Compound hot–dry conditions. (a) Detrended DJF maximum temperature over Zimbabwe by state, Berkeley Earth and ERA5, 1970–2024 (anomaly relative to the 1970–2024 mean; sample sizes {TP['counts'][LM]}, {TP['counts'][LO]}, {TP['counts'][EO]}, {TP['counts'][EP]} and {TP['counts']['Neutral']}). (b) National station rainfall anomaly against Berkeley Earth DJF Tmax anomaly, 1970–2017, coloured by state, with the least-squares line. (c) Absolute standardised mean difference (Cohen’s *d*) between El Niño and other seasons for station rainfall and March SPEI-6, by Natural Region, 1951–2017.")

H2('3.8 Regional circulation')
Pp(f"The circulation anomalies differ between the two El Niño states (Fig. 7; Table 3). "
   f"In El Niño & +IOD seasons, DJF ω500 is positive, indicating anomalous descent, over Zimbabwe, Zambia, southern Angola and Mozambique (Fig. 7a). "
   f"The Zimbabwe-mean anomaly is {s(w[EP]['d']*100,2)} × 10^−2^ Pa s^−1^ ({P(w[EP]['p'])}). "
   f"In El Niño only seasons the anomaly over Zimbabwe is weak and slightly negative ({s(w[EO]['d']*100,2)} × 10^−2^ Pa s^−1^, {P(w[EO]['p'])}), with descent confined to Angola and South Africa (Fig. 7b). "
   f"The descent in co-occurrence seasons is already present in October–December ({s(wo[EP]['d']*100,2)} × 10^−2^ Pa s^−1^, {P(wo[EP]['p'])}; Fig. 7d), when the IOD is still active. "
   f"Both La Niña states show anomalous ascent ({s(w[LM]['d']*100,2)} and {s(w[LO]['d']*100,2)} × 10^−2^ Pa s^−1^). "
   f"ω500 over Zimbabwe correlates with national rainfall at r = {Mx['r_w500_rain']:.2f}.")
Pp(f"Mid-level heights rise over the whole subcontinent in El Niño & +IOD seasons, with a maximum over Botswana and Namibia (Fig. 7c). "
   f"The Botswana High index is {a(Mx['BH'][EP]['d'])} m above neutral in co-occurrence seasons ({P(Mx['BH'][EP]['p'])}) and {a(Mx['BH'][EO]['d'])} m above in El Niño only seasons (Fig. 7e). "
   f"The Angola Low index is {a(Mx['AL'][EP]['d'])} m and {a(Mx['AL'][EO]['d'])} m higher, which indicates a weaker low. "
   "A stronger Botswana High and a weaker Angola Low are both associated with reduced summer rainfall over the interior (Driver and Reason, 2017; Howard and Washington, 2018), so both anomalies are consistent with the rainfall deficit. "
   f"Both indices correlate with national CHIRPS rainfall over 1981–2024 (r = {Mx['BH_r_rain']:.2f} and {Mx['AL_r_rain']:.2f}). "
   f"They are, however, closely tied to the modes: the Botswana High index correlates with the DJF ONI at r = {Mx['BH_r_oni']:.2f}, and the Angola Low index at r = {Mx['AL_r_oni']:.2f}. "
   "Part of this tie reflects the rise of tropospheric heights across the tropics and subtropics during El Niño, visible in Fig. 7c as a positive anomaly over the whole domain. "
   f"Added to a regression of CHIRPS rainfall on the ONI and DMI (R^2^ = {Mx['R2_modes_chirps']:.2f}, 1981–2024), the Botswana High index explains no further variance ({P(Mx['BH_p_given_modes'])}), and the Angola Low index explains {100*Mx['AL_dR2']:.0f}% more ({P(Mx['AL_p_given_modes'])}).")
Pp("These diagnostics show that the co-occurrence drought coincides with large-scale descent and a stronger mid-level anticyclone over the interior. "
   "They do not establish the direction of cause. Reduced convection and latent heating would themselves favour descent and higher heights. "
   "Over 1980–2024 the regional systems behave mainly as part of the ENSO–IOD response, rather than as independent modulators that add rainfall information, although their own variability may matter for individual events (Blamey et al., 2018).")
def trow(name, key, scale=1, dd=1, pkey=None):
    out = [name]
    for c in [EP, EO, LO, LM]:
        if key == 'w': x = Mx['w500_zim_tests'][c]
        elif key == 'wo': x = Mx['w500_zim_tests_OND'][c]
        else: x = Mx[key][c]
        out.append(f"{s(x['d']*scale,dd)} ({Pn(x['p'])})")
    return out
rows3 = [trow('ω500, DJF (10^−2^ Pa s^−1^)', 'w', 100, 2), trow('ω500, OND (10^−2^ Pa s^−1^)', 'wo', 100, 2),
         trow('Botswana High, Z500 (m)', 'BH'), trow('Angola Low, Z850 (m)', 'AL')]
rows3.append(['Z500 over Zimbabwe (m)'] + [s(Mx['z500_DJF'][c]['zim']) for c in [EP, EO, LO, LM]])
rows3.append(['Seasons, ω500 / heights'] + [f"{Mx['w500_zim_tests'][c]['na']} / {Mx['BH'][c]['na']}" for c in [EP, EO, LO, LM]])
TAB(['Variable (minus neutral)', 'El Niño & +IOD', 'El Niño only', 'La Niña only', 'La Niña & −IOD'], rows3,
    '**Table 3.** ERA5 circulation anomalies by state relative to neutral seasons, with Welch *p* values in parentheses. ω500 covers 1951–2024 over the Zimbabwe land mask; positive values denote descent. Heights cover 1980–2024 and are linearly detrended; the Botswana High index is Z500 over 18–26°S, 18–28°E and the Angola Low index Z850 over 11–19°S, 14–25°E (a positive value denotes a weaker low).',
    widths=[2.2, 1.1, 1.1, 1.1, 1.1])
FIG('Fig07_mechanism',
    f"**Figure 7.** Circulation anomalies relative to neutral seasons. (a) DJF ω500 in El Niño & +IOD seasons, 1951–2024 (red denotes descent). (b) As (a), El Niño only seasons. (c) DJF Z500 (detrended) in El Niño & +IOD seasons, 1980–2024, with the Botswana High (BH) and Angola Low (AL) index boxes. Dots mark *p* < 0.05 (Welch), plotted at every second grid point. (d) Zimbabwe-mean ω500 by state for OND (hatched) and DJF (solid); asterisks mark *p* < 0.05. (e) Botswana High (Z500) and Angola Low (Z850) indices by state, 1980–2024.")

H2('3.9 Land surface by Natural Region')
Pp(f"The land surface responds in the same way (Fig. 8). "
   f"In El Niño & +IOD seasons, DJF upper-layer soil moisture is below neutral in every region, by {a(L['sm']['I'][EP]['d'])} kg m^−2^ in NR I to {a(L['sm']['III'][EP]['d'])} kg m^−2^ in NR III. "
   f"Nationally the deficit is {a(L['sm']['Nat'][EP]['d'])} kg m^−2^ ({P(L['sm']['Nat'][EP]['p'])}), about {100*abs(L['sm']['Nat'][EP]['d'])/L['sm_clim']['Nat']:.0f}% of the DJF mean of {L['sm_clim']['Nat']:.1f} kg m^−2^. "
   f"In El Niño only seasons the change is small and not significant anywhere ({s(L['sm']['Nat'][EO]['d'])} kg m^−2^ nationally). "
   f"Evaporative stress rises by {a(L['stress']['Nat'][EP]['d'],2)} mm d^−1^ in co-occurrence seasons ({P(L['stress']['Nat'][EP]['p'])}), with significant increases in NR III–V and smaller, non-significant ones in NR I–II. "
   f"Both La Niña states are wetter at the surface, most strongly with a negative IOD.")
Pp("DJF spans flowering and early grain fill for maize planted in November and December, which is the common planting window on the central plateau. "
   "Planting dates differ by region and by season, however, and short-season cultivars and late plantings in NR III–V can flower in February or March. "
   "The DJF deficit should therefore be read as a deficit during the main reproductive window for typical plantings, not as a uniform flowering-stage deficit across all farms. "
   "A crop planted late after a delayed onset (section 3.11) would also meet the deficit at an earlier growth stage.")
FIG('Fig08_land_surface',
    '**Figure 8.** Land-surface response by Natural Region relative to neutral seasons, 1951–2024. (a) ERA5-Land DJF upper-layer soil moisture (kg m^−2^). (b) DJF evaporative stress, ERA5 potential minus actual evaporation (mm d^−1^). Fields are linearly detrended; asterisks mark *p* < 0.05 (Welch).')

H2('3.10 Which rainfall parameters track which driver')
Pp(f"The two modes peak at different times (Fig. 9b). "
   f"The interannual standard deviation of the DMI falls from {SEA['sd_son']:.2f} °C in SON to {SEA['sd_djf']:.2f} °C in DJF, and the SON and DJF values correlate at only r = {SEA['r_son_djf']:.2f}. "
   f"Niño 3.4 variability peaks in December–January. "
   f"Seasonal rainfall correlates with the SON DMI at r = {SEA['r_rain_son']:.2f} ({P(SEA['p_rain_son'])}) but with the DJF DMI at r = {s(SEA['r_rain_djf'],2)} ({P(SEA['p_rain_djf'])}). "
   "An IOD index averaged over the summer peak of the rains therefore misses the signal, and the IOD must be read in its active season.")
Pp(f"Partial correlations separate the two drivers (Fig. 9a; Table S10). "
   f"The December dry spell tracks the IOD (partial r = {PC['Dec_LODS']['iod']['r']:.2f}, {P(PC['Dec_LODS']['iod']['p'])}) more than ENSO ({PC['Dec_LODS']['enso']['r']:.2f}, {P(PC['Dec_LODS']['enso']['p'])}). "
   f"The February dry spell tracks ENSO ({PC['Feb_LODS']['enso']['r']:.2f}, {P(PC['Feb_LODS']['enso']['p'])}) rather than the IOD ({PC['Feb_LODS']['iod']['r']:.2f}). "
   f"Onset tracks ENSO ({PC['SOS']['enso']['r']:.2f}, {P(PC['SOS']['enso']['p'])}) more than the IOD ({PC['SOS']['iod']['r']:.2f}, {P(PC['SOS']['iod']['p'])}). "
   f"The seasonal total and season length track both, with partial correlations of {a(PC['Season_T']['iod']['r'],2)} and {a(PC['Season_T']['enso']['r'],2)} for the total and {a(PC['LOS']['iod']['r'],2)} and {a(PC['LOS']['enso']['r'],2)} for the length (IOD and ENSO). "
   "The submitted conclusion that the IOD governs onset is therefore not supported. "
   "The IOD signature is clearest in December dry spells, and the ENSO signature in February dry spells and onset. "
   f"The daily CHIRPS check gives the same signs for the dry spells (December, IOD r = {R['daily']['dec_dry']['iod']['r']:.2f}; February, ENSO r = {R['daily']['feb_dry']['enso']['r']:.2f}). "
   f"CHIRPS onset, computed with the MSD criterion, correlates with station onset at r = {R['daily']['r_onset_station']:.2f}. "
   f"It is {a(R['daily']['onset_comp'][EP]['d'],0)} days later than neutral in co-occurrence seasons ({P(R['daily']['onset_comp'][EP]['p'])}, n = {R['daily']['onset_comp'][EP]['na']}), close to the station delay (section 3.11). "
   f"Over the shorter 1981–2024 record, however, neither mode is a significant partial control of CHIRPS onset (IOD r = {R['daily']['onset']['iod']['r']:.2f}, ENSO r = {R['daily']['onset']['enso']['r']:.2f}).")
Pp(f"Monthly CHIRPS rainfall shows how the deficit develops (Fig. 9c; Fig. S4). "
   f"In El Niño & +IOD seasons, rainfall is near or above normal in October, a month that contributes little to the seasonal total, and then {a(R['monthly'][EP]['Nat'][1],0)}–{a(R['monthly'][EP]['Nat'][4],0)}% below normal from November to February. "
   f"In El Niño only seasons the deficit is concentrated in January and February. "
   f"Consistent with this, October–December rainfall is {a(R['monthly']['OND_tests'][EP]['d'])}% below neutral in co-occurrence seasons ({P(R['monthly']['OND_tests'][EP]['p'])}) and {s(R['monthly']['OND_tests'][EO]['d'])}% in El Niño only seasons. "
   "The co-occurrence deficit is therefore early and persistent, while the El Niño only deficit comes later in the season. "
   "The same sequence appears in every region (Fig. S4).")
FIG('Fig09_timing_drivers',
    '**Figure 9.** Separation of IOD and ENSO influence. (a) Partial correlation of each station rainfall parameter with the SON DMI controlling for the DJF ONI, and with the DJF ONI controlling for the SON DMI, 1951–2017; signs are arranged so that positive values mean drier or later; asterisks mark *p* < 0.05. (b) Interannual standard deviation of the DMI and Niño 3.4 by month. (c) National CHIRPS monthly rainfall anomaly (% of the monthly climatology) by state, 1981–2024, with the number of seasons.')

H2('3.11 Onset, cessation and length of the season by Natural Region')
Pp(f"Over 1951–2017 the mean national season starts on about 30 November (day {sos['clim']:.0f}), ends on about 20 March (day {eos['clim']:.0f}) and lasts {los['clim']:.0f} days. "
   f"Relative to neutral seasons, El Niño & +IOD seasons start {a(sos['comp'][EP]['d'])} days later ({P(sos['comp'][EP]['p'])}; 95% CI {a(sos['boot'][EP][0])}–{a(sos['boot'][EP][1])} days) and are {a(los['comp'][EP]['d'])} days shorter ({P(los['comp'][EP]['p'])}) (Fig. 10a). "
   f"Cessation is {a(eos['comp'][EP]['d'])} days earlier, which is not significant. "
   f"El Niño only seasons show no timing change (onset {s(sos['comp'][EO]['d'])} days, length {s(los['comp'][EO]['d'])} days). "
   f"The timing change is widespread. Onset is later in {100*spr['SOS|EN+pIOD']['frac_pos']:.0f}% of stations and the season shorter in {100*spr['LOS|EN+pIOD']['frac_neg']:.0f}% of stations in co-occurrence seasons (Fig. 10b). "
   f"The median station delay is {spr['SOS|EN+pIOD']['median']:.0f} days (interquartile range {spr['SOS|EN+pIOD']['q25']:.0f}–{spr['SOS|EN+pIOD']['q75']:.0f} days), and the median shortening is {a(spr['LOS|EN+pIOD']['median'],0)} days ({a(spr['LOS|EN+pIOD']['q75'],0)}–{a(spr['LOS|EN+pIOD']['q25'],0)} days).")
Pp(f"The delay occurs in every region (Table 4). "
   f"It is largest in NR V ({s(sos['nr']['V'][EP]['d'])} days, {P(sos['nr']['V'][EP]['p'])}) and NR I ({s(sos['nr']['I'][EP]['d'])} days, {P(sos['nr']['I'][EP]['p'])}), and smallest and not significant in NR IV ({s(sos['nr']['IV'][EP]['d'])} days). "
   f"The season is shortened most in NR V ({s(los['nr']['V'][EP]['d'])} days) and NR III ({s(los['nr']['III'][EP]['d'])} days). "
   f"In NR III and NR V the season also ends earlier ({s(eos['nr']['III'][EP]['d'])} and {s(eos['nr']['V'][EP]['d'])} days). "
   f"These cessation values are conservative, because EOS cannot fall below early March and {100*T['eos_floor_by_cat'][EP]:.0f}% of station-seasons in co-occurrence seasons sit at that bound, against {100*T['eos_floor_by_cat']['Neutral']:.0f}% in neutral seasons. "
   "A season that starts three weeks late and is three to four weeks shorter compresses the window for planting, establishment and grain fill.")
def timrow(var, c):
    out = [f"{var}, {LAB[c]}"]
    for nr in NRS + ['Nat']:
        x = T[var]['nr'][nr][c] if nr != 'Nat' else T[var]['comp'][c]
        out.append(f"{s(x['d'],0)}" + ('\\*' if x['p'] < 0.05 else ''))
    return out
rows4 = [['Neutral SOS (day from 1 Jul)'] + [f"{T['SOS']['nr'][nr]['Neutral_mean']:.0f}" for nr in NRS] + [f"{T['SOS']['comp']['Neutral_mean']:.0f}"]]
rows4 += [timrow('SOS', EP), timrow('SOS', EO), timrow('EOS', EP), timrow('EOS', EO), timrow('LOS', EP), timrow('LOS', EO)]
TAB(['Metric and state (minus neutral, days)', 'NR I', 'NR II', 'NR III', 'NR IV', 'NR V', 'National'], rows4,
    '**Table 4.** Season timing anomalies relative to neutral seasons by Natural Region, station series 1951–2017 (days). SOS, EOS and LOS are the start, end and length of the season; positive SOS and EOS values are later dates. The first row gives the neutral-season mean onset. An asterisk marks *p* < 0.05 (Welch). The station-level spread is given in Table S11.',
    widths=[2.3, 0.65, 0.65, 0.65, 0.65, 0.65, 0.75])
FIG('Fig10_season_timing',
    f"**Figure 10.** Season timing, station series 1951–2017. (a) National onset (SOS), cessation (EOS) and length (LOS) anomalies relative to neutral seasons by state, with 95% bootstrap intervals. (b) Distribution across stations of the station composite difference for onset and length (boxes: interquartile range; whiskers: 1.5 × interquartile range); labels give the share of stations with a later onset or a shorter season in El Niño & +IOD seasons. (c) Composite season windows from the national mean onset and cessation; the dashed line marks the earliest cessation date recorded in the archive, at which {100*T['eos_floor_frac']:.0f}% of station-seasons sit.")

H2('3.12 Validation with CHIRPS and extension to 2024')
Pp(f"CHIRPS reproduces the interannual variability of the station series (Fig. 11a,b). "
   f"Over 1981–2017 the two national anomaly series correlate at r = {CH['val']['Nat']['r']:.2f}. "
   f"The regional correlations are {CH['val']['II']['r']:.2f}, {CH['val']['III']['r']:.2f}, {CH['val']['IV']['r']:.2f} and {CH['val']['V']['r']:.2f} in NR II–V and {CH['val']['I']['r']:.2f} in NR I, where three stations sample a narrow mountain zone that a 0.25° grid resolves poorly. "
   f"Mean totals differ (CHIRPS {CH['clim_mm']['I']:.0f}, {CH['clim_mm']['II']:.0f}, {CH['clim_mm']['III']:.0f}, {CH['clim_mm']['IV']:.0f} and {CH['clim_mm']['V']:.0f} mm for NR I–V), so the comparison is made in anomaly space.")
Pp(f"Over 1981–2024 CHIRPS confirms that El Niño & +IOD is the driest state in every region (Fig. 11c; Table S9). "
   f"El Niño & +IOD seasons are {a(ch_enp['Nat']['d'])}% drier than neutral nationally (n = {ch_enp['n']}, {P(ch_enp['Nat']['p'])}), and the deficit is significant in NR I, II, III and V. "
   f"El Niño only seasons are {a(ch_eo['Nat']['d'])}% drier (n = {ch_eo['n']}, {P(ch_eo['Nat']['p'])}). "
   "The CHIRPS contrast is smaller than in the full station record, consistent with section 3.6, because CHIRPS covers only the period of the stronger ENSO teleconnection. "
   f"Combining the station series for 1951–2017 with CHIRPS for 2018–2024 gives {s(R['combined'][EP]['Nat']['d'])}% for El Niño & +IOD seasons (n = {R['combined'][EP]['n']}, {P(R['combined'][EP]['Nat']['p'])}).")
Pp(f"The extension adds three co-occurrence seasons. "
   f"The national CHIRPS anomaly is {s(CH['a2018'])}% in 2018/19, {s(CH['a2019'])}% in 2019/20 and {s(CH['a2023'])}% in 2023/24. "
   f"The 2023/24 season is the second driest in the CHIRPS record, after 1991/92 ({s(CH['a1991'])}%). "
   "The submitted statement that it was the driest was incorrect and has been withdrawn.")
FIG('Fig11_chirps',
    f"**Figure 11.** Validation and extension with CHIRPS v2.0. (a) National CHIRPS against station rainfall anomalies, 1981–2017, coloured by state. (b) Correlation between CHIRPS and station anomalies by Natural Region, 1981–2017. (c) CHIRPS composites relative to neutral seasons by region, 1981–2024, with the number of seasons; asterisks mark *p* < 0.05 (Welch).")

H2('3.13 Imprint on national maize production')
Pp(f"Detrended maize production follows seasonal rainfall (r = {mz['r_rain_yield']:.2f}; Fig. 12a). "
   f"Production is {a(mz['cat'][EP]['mean'],0)}% below trend in El Niño & +IOD seasons (n = {mz['cat'][EP]['n']}), {a(mz['cat'][EO]['mean'],0)}% below in El Niño only seasons and {a(mz['cat']['Neutral']['mean'],0)}% above in neutral seasons (Fig. 12b). "
   f"The co-occurrence value is {a(mz['vs_neu'][EP]['d'],0)} percentage points below the neutral value ({P(mz['vs_neu'][EP]['p'])}), while the El Niño only value is {a(mz['vs_neu'][EO]['d'],0)} points below it ({P(mz['vs_neu'][EO]['p'])}). "
   f"Since 2000, the four lowest harvests followed the 2001/02, 2015/16, 2007/08 and 2023/24 seasons. "
   f"Two of these, 2015/16 ({mz['prod2015']:.0f} thousand tonnes) and 2023/24 ({mz['prod2023']:.0f} thousand tonnes), were co-occurrence seasons, against a post-2000 mean of {mz['mean2000']:.0f} thousand tonnes. "
   "The other two followed a neutral and a La Niña season, which shows that non-climatic shocks also drive the national harvest.")
Pp(f"FAOSTAT data confirm the production result and locate it in yield (Fig. 12b). "
   f"Detrended yield correlates with detrended USDA production at r = {YD['r_with_usda_prod']:.2f} and with seasonal rainfall at r = {YD['r_rain']:.2f}. "
   f"Yield is {a(YD['cat'][EP]['mean'],0)}% below trend in El Niño & +IOD seasons, {a(YD['vs_neu'][EP]['d'],0)} percentage points below the neutral value ({P(YD['vs_neu'][EP]['p'])}). "
   f"El Niño only seasons are {a(YD['vs_neu'][EO]['d'],0)} points below neutral ({P(YD['vs_neu'][EO]['p'])}). "
   f"Excluding the FAO estimates, the co-occurrence state is {a(YD['official_only']['vs_neu'][EP]['d'],0)} points below neutral ({P(YD['official_only']['vs_neu'][EP]['p'])}). "
   f"The 2015/16 and 2023/24 yields were {YD['y2015']:.0f} and {YD['y2023']:.0f} kg ha^−1^, against a post-2000 mean of {YD['mean_post2000']:.0f} kg ha^−1^. "
   f"Area harvested shows no climate signal: it is uncorrelated with seasonal rainfall (r = {YD['area']['r_rain']:.2f}, {P(YD['area']['p_rain'])}) and only {a(YD['area']['vs_neu'][EP]['d'],1)} points below neutral in co-occurrence seasons ({P(YD['area']['vs_neu'][EP]['p'])}). "
   f"FAOSTAT production is {a(YD['fao_prod']['vs_neu'][EP]['d'],0)} points below neutral in these seasons ({P(YD['fao_prod']['vs_neu'][EP]['p'])}), and in logarithmic terms {100*YD['decomp'][EP]['yield_share']:.0f}% of that deficit comes from yield and the rest from area. "
   "The co-occurrence loss is therefore a loss of yield per hectare, not of harvested area.")
Pp(f"The attribution between the two modes is less robust (Fig. 12c). "
   f"Together the DJF ONI and SON DMI explain {100*mz['R2_full']:.0f}% of the variance of detrended production. "
   f"Of this, {100*mz['uniq_enso']:.1f}% is unique to ENSO, {100*mz['uniq_iod']:.1f}% unique to the IOD, and {100*mz['shared']:.1f}% shared. "
   f"The standardised coefficients are {s(mz['beta_oni'],2)} for the ONI ({P(mz['p_oni'])}) and {s(mz['beta_dmi'],2)} for the DMI ({P(mz['p_dmi'])}). "
   "The submitted conclusion that ENSO carries all of the unique production signal does not hold once each harvest is mapped to its own growing season (section 2.5). "
   f"For yield, the indices explain {100*YD['R2_full']:.0f}% of the variance: {100*YD['uniq_enso']:.1f}% unique to ENSO, {100*YD['uniq_iod']:.1f}% unique to the IOD and {100*YD['shared']:.1f}% shared, and neither coefficient is significant (ONI {s(YD['beta_oni'],2)}, {P(YD['p_oni'])}; DMI {s(YD['beta_dmi'],2)}, {P(YD['p_dmi'])}). "
   f"FAOSTAT production gives an intermediate split ({100*YD['fao_prod']['uniq_enso']:.1f}% unique to ENSO and {100*YD['fao_prod']['uniq_iod']:.1f}% to the IOD; ONI {s(YD['fao_prod']['beta_oni'],2)}, {P(YD['fao_prod']['p_oni'])}; DMI {s(YD['fao_prod']['beta_dmi'],2)}, {P(YD['fao_prod']['p_dmi'])}). "
   "ENSO therefore has the larger unique share in both FAOSTAT series, but neither coefficient is significant in either, and the two shares are similar in the USDA series. "
   "The separate contributions of the two modes depend on the maize series. The robust results are that the co-occurrence state is the worst for production and yield in both databases, and that most of the variance the modes explain is shared. "
   f"Late onset is associated with lower production (r = {mz['links']['SOS']['r_yield']:.2f}, {P(mz['links']['SOS']['p_yield'])}), and the February dry spell has the strongest link of the timing measures (r = {mz['links']['Feb_LODS']['r_yield']:.2f}, {P(mz['links']['Feb_LODS']['p_yield'])}). "
   f"The December dry spell has a weaker link (r = {mz['links']['Dec_LODS']['r_yield']:.2f}, {P(mz['links']['Dec_LODS']['p_yield'])}). "
   f"Yield shows the same links (onset r = {YD['links']['SOS']['r']:.2f}, {P(YD['links']['SOS']['p'])}; February dry spell r = {YD['links']['Feb_LODS']['r']:.2f}, {P(YD['links']['Feb_LODS']['p'])}). "
   "The data therefore do not support the submitted argument that early-season failures are buffered by replanting. "
   "National production and yield also depend on inputs, prices and policy, which these composites do not capture, and the attribution should be read with that in mind.")
FIG('Fig12_maize',
    f"**Figure 12.** ENSO–IOD imprint on national maize, 1960–2023 onset years. (a) USDA production by season onset year, with El Niño & +IOD and El Niño only seasons marked and the linear trend fitted separately before and after 2000. (b) Mean departure from the era trend by state for USDA production (solid), FAOSTAT yield (hatched) and FAOSTAT area harvested (dotted outline), with 95% bootstrap intervals; values are given in Table S13b. (c) Partition of the variance explained by the DJF ONI and SON DMI into the part unique to ENSO, the shared part and the part unique to the IOD, for USDA production, FAOSTAT production and FAOSTAT yield.")

H2('3.14 Predictive information')
Pp(f"The indices carry modest but useful predictive information for national rainfall. "
   f"A leave-one-out cross-validated linear model using the concurrent DJF ONI and SON DMI gives a correlation skill of {SK['concurrent_r']:.2f} and the correct sign in {100*SK['concurrent_hit']:.0f}% of seasons. "
   f"Using indices available at the end of November (SON Niño 3.4 and SON DMI) gives {SK['son_r']:.2f} and {100*SK['son_hit']:.0f}%. "
   f"Using pre-season August–September indices gives {SK['preseason_r']:.2f} and {100*SK['preseason_hit']:.0f}%. "
   "Most of the skill is therefore available before the core of the season, and much of it before planting.")

# =====================================================================================  4 DISCUSSION
H1('4 Discussion')
Pp("The study adds three things to the existing picture of ENSO–IOD influence on Zimbabwe. "
   "First, it resolves the joint signal by Natural Region. "
   f"The co-occurrence deficit is present in all five regions, significant after multiple-testing control in four, and largest as a fraction of rainfall in NR III and NR V. "
   "Previous work, including our own (Manatsa et al., 2008; Manatsa and Matarira, 2009; Manatsa and Mukwada, 2012), described the signal at national scale. "
   "Second, it separates El Niño seasons with and without a positive IOD against a common neutral baseline and tests what lies behind the difference. "
   "The modes add rather than interact, the co-occurrence events were also the stronger El Niño events, and the extra IOD deficit was large before the early 1980s and small afterwards. "
   "Third, it traces the same classification through temperature, SPEI-6, season timing, circulation, the land surface and maize production, with its sensitivity to the index conventions reported in full.")
Pp("The robustness analysis changes how the central result should be stated. "
   "The ordering of the two El Niño states, with El Niño & +IOD drier than El Niño only, holds under every convention, threshold, tercile scheme and dataset we tried. "
   "The size and significance of the co-occurrence deficit do not. "
   "They depend on the base period and on trend treatment, as Verdon-Kidd (2018) found for IOD event classification more generally. "
   "Under the fixed 1981–2010 base that reproduces the submitted classification, the deficit is about 15% and not significant. "
   "We therefore present the moving-base result with its sensitivity range, and we regard the ordering, not a single effect size, as the robust finding.")
Pp("The nonstationarity has practical weight. "
   "Since the early 1980s the ENSO teleconnection has been stronger, El Niño alone has produced substantial deficits (1991/92 is the most severe drought in the record and is an El Niño only season under our classification), and the IOD has added less independent information. "
   "Changes in the relative roles of the two modes were also reported by Manatsa and Matarira (2009). "
   "It would be wrong to conclude that El Niño with a neutral IOD is a safe season. "
   "The more defensible statement is that a positive IOD during an El Niño identifies the seasons with the earliest, most widespread and most persistent deficits, and that it is observable before planting.")
Pp("The circulation results are consistent with a coherent physical picture, but they do not prove its direction. "
   "Co-occurrence seasons combine anomalous descent over the country from October onward, higher mid-level heights centred on the Botswana High, a weaker Angola Low, drier soils and higher evaporative stress. "
   "Descent suppresses convection and warms the column adiabatically under clearer skies, which would account for both the rainfall deficit and the temperature excess (Mbokodo et al., 2023). "
   "The same anomalies would also follow from reduced convection. "
   "The regional circulation indices correlate strongly with the ONI and add little rainfall information beyond the two modes. "
   "This suggests that, at seasonal scale and over 1980–2024, they act mainly as pathways for the remote forcing rather than as independent drivers. "
   "Blamey et al. (2018) showed that their behaviour can still differ between individual El Niño events, and a seasonal composite cannot capture that diversity.")
Pp("The regional results have direct agricultural meaning. "
   f"NR II–III, the main maize regions, lose about a fifth to nearly a third of their rainfall in co-occurrence seasons, and the onset is delayed by two to three weeks. "
   f"NR IV–V lose a similar or larger fraction of a smaller total, together with the largest shortening of the season in NR V. "
   "In these semi-arid regions an evaporative-demand-aware index such as SPEI-6 separates El Niño seasons from others more sharply than rainfall, which supports its use in drought monitoring. "
   "NR I, the wettest and smallest region, shows the weakest relative response, but its result rests on three stations and is the least certain.")
Pp("These findings support a simple, region-specific approach to seasonal outlooks. "
   "The state of the IOD in September–November should be reported alongside ENSO in the national outlook. "
   "When El Niño coincides with a positive IOD, the outlook should signal a high likelihood of a late onset, early-season dry spells and below-normal totals in all regions, with the largest relative deficits in NR III–V. "
   "When El Niño occurs with a neutral IOD, the outlook should still signal elevated drought risk, because in recent decades such seasons have also been dry, but with less confidence about the early season. "
   "Regional magnitudes should be expressed by Natural Region rather than as a single national figure. "
   "Because most of the statistical skill is available from pre-season indices, these statements can be issued before planting.")
Pp("Several assumptions and limitations qualify the results. "
   "(i) Sample size. The co-occurrence composite rests on 9 station seasons and 12 seasons in the combined record. Confidence intervals are wide, and the effect sizes should be read as central estimates with their uncertainty, not as precise values. "
   "(ii) Classification. Event membership depends on the index convention, thresholds and dataset. The ordering of the El Niño states is robust, but significance is not, and the tercile analysis shows that the joint states cannot be balanced because the modes are correlated. "
   "(iii) Confounding with ENSO strength and nonstationarity. The IOD contribution cannot be fully separated from El Niño intensity, and its size has changed over time. "
   "(iv) Station network. Density varies by a factor of nine between regions and over time; NR V has no station before 1959 and NR I only three stations. The representative series assume that station departures from their own normals are representative of the region. "
   f"(v) Season timing. Cessation is bounded below in early March, so early cessation is under-recorded, and onset from CHIRPS with the same definition agrees only moderately with gauge onset (r = {R['daily']['r_onset_station']:.2f}). "
   "(vi) Independence of datasets. CHIRPS blends gauges, and ERA5 and SPEI-6 share rainfall information with the station record, so they are corroborating rather than fully independent evidence. "
   "(vii) Circulation. The composites are associations; a moisture-budget analysis or model experiments would be needed to establish cause. "
   "(viii) Maize. National production and yield integrate non-climatic factors and are not resolved by region, and the attribution between modes differs between the production and yield series. "
   "(ix) Other drivers. We consider only the tropical IOD and ENSO; the subtropical Indian Ocean dipole (Hoell et al., 2017) and ENSO diversity (Ratnam et al., 2014) may modulate the response.")

# =====================================================================================  5 CONCLUSIONS
H1('5 Conclusions')
Pp("This study examined how ENSO and the IOD, alone and together, relate to seasonal rainfall in Zimbabwe’s five agroecological Natural Regions over 1951–2017, extended to 2024 with CHIRPS. "
   "Events were classified from ERSSTv5 indices with a fully documented convention and tested against alternatives.")
Pp(f"El Niño seasons that coincide with a positive IOD are the driest ENSO–IOD state in every Natural Region, with deficits of {a(d(EP,'I'),0)}–{a(d(EP,'III'),0)}% relative to neutral seasons. "
   "They are also the hottest seasons, reach moderate drought on SPEI-6, start about three weeks late and are about four weeks shorter. "
   "They coincide with anomalous descent over the country from October, a stronger Botswana High, drier soils and maize production about a third below trend. "
   "El Niño seasons with a neutral IOD were not consistently dry over the full record, but they have been drier since the early 1980s, when the ENSO teleconnection strengthened. "
   "The two modes combine additively, and the co-occurrence events were also the stronger El Niño events. "
   "The position of El Niño & +IOD as the driest state is robust to the index convention, thresholds and a tercile classification, while the significance of the co-occurrence deficit depends on the base period.")
Pp("For seasonal forecasting, the IOD state in September–November should be reported with ENSO, and the risk it implies should be expressed region by region. "
   "A positive IOD during an El Niño marks the seasons with the most severe, earliest and most widespread deficits, and it is visible before planting. "
   "SPEI-6 should complement rainfall percentiles in drought monitoring, especially in the semi-arid regions.")

# =====================================================================================  BACK MATTER
ACK = ("Station rainfall records were provided by the Meteorological Services Department (MSD) of Zimbabwe and are published in the Zimbabwe National Statistics Agency 2023 Environment Statistics Report (Physical Conditions Series). "
       "CHIRPS v2.0 data were obtained from the Climate Hazards Center, University of California, Santa Barbara, through the KNMI Climate Explorer. "
       "We thank three anonymous reviewers and the Editor for comments that substantially improved the manuscript. "
       "No external funding was received for this study. The authors declare no conflicts of interest.")
DATA = ("ERSSTv5 and HadISST1 SST and the derived Niño 3.4 and Dipole Mode indices were obtained from the KNMI Climate Explorer (https://climexp.knmi.nl). "
        "CHIRPS v2.0 is available from the Climate Hazards Center (https://www.chc.ucsb.edu/data/chirps). "
        "ERA5, ERA5-Land and the ERA5–Drought SPEI are available from the Copernicus Climate Data Store (https://cds.climate.copernicus.eu). "
        "Berkeley Earth temperature is available from https://berkeleyearth.org/data. "
        "Maize production is from the USDA Foreign Agricultural Service Production, Supply and Distribution database (https://apps.fas.usda.gov/psdonline), and maize yield, area harvested and production from FAOSTAT (https://www.fao.org/faostat/en/#data/QCL). "
        "The Natural Region boundaries are from the revised national Natural Region shapefile. "
        "The station records are available from MSD subject to its data policy. "
        "The derived index series, the season classification, the representative regional series, the station inventory and the analysis scripts are available at https://github.com/dmanatsa-cloud/supplementary-materials-SADC_IOD_ENSO_manuscript-2026.")

REFS = [
 "Ashok, K., Z. Guan, N. H. Saji, and T. Yamagata, 2004: Individual and combined influences of ENSO and the Indian Ocean Dipole on the Indian summer monsoon. *J. Climate*, **17**, 3141–3155.",
 "Beguería, S., S. M. Vicente-Serrano, F. Reig, and B. Latorre, 2014: Standardized precipitation evapotranspiration index (SPEI) revisited: parameter fitting, evapotranspiration models, tools, datasets and drought monitoring. *Int. J. Climatol.*, **34**, 3001–3023.",
 "Behera, S. K., and T. Yamagata, 2003: Influence of the Indian Ocean Dipole on the Southern Oscillation. *J. Meteor. Soc. Japan*, **81**, 169–177.",
 "Behera, S. K., J.-J. Luo, S. Masson, P. Delecluse, S. Gualdi, A. Navarra, and T. Yamagata, 2005: Paramount impact of the Indian Ocean dipole on the East African short rains: A CGCM study. *J. Climate*, **18**, 4514–4530.",
 "Benjamini, Y., and Y. Hochberg, 1995: Controlling the false discovery rate: A practical and powerful approach to multiple testing. *J. Roy. Stat. Soc.*, **57B**, 289–300.",
 "Blamey, R. C., S. R. Kolusu, P. Mahlalela, M. C. Todd, and C. J. C. Reason, 2018: The role of regional circulation features in regulating El Niño climate impacts over southern Africa: A comparison of the 2015/2016 drought with previous events. *Int. J. Climatol.*, **38**, 4276–4295, https://doi.org/10.1002/joc.5668.",
 "Driver, P., and C. J. C. Reason, 2017: Variability in the Botswana High and its relationships with rainfall and temperature characteristics over southern Africa. *Int. J. Climatol.*, **37**, 570–581, https://doi.org/10.1002/joc.5022.",
 "Efron, B., 1979: Bootstrap methods: Another look at the jackknife. *Ann. Stat.*, **7**, 1–26.",
 "FAO, 2026: FAOSTAT statistical database: Crops and livestock products (QCL), Maize (corn), Zimbabwe: yield, area harvested and production, 1961–2024. Food and Agriculture Organization of the United Nations, Rome, accessed 22 October 2026, https://www.fao.org/faostat/en/#data/QCL.",
 "Ficchì, A., H. Cloke, C. Neves, S. Woolnough, E. Coughlan de Perez, E. Zsoter, I. Pinto, A. Meque, and E. Stephens, 2021: Beyond El Niño: Unsung climate modes drive African floods. *Wea. Climate Extremes*, **33**, 100345, https://doi.org/10.1016/j.wace.2021.100345.",
 "Funk, C., and Coauthors, 2015: The climate hazards infrared precipitation with stations: A new environmental record for monitoring extremes. *Sci. Data*, **2**, 150066.",
 "Hao, Z., F. Hao, V. P. Singh, and X. Zhang, 2018: Changes in the severity of compound drought and hot extremes over global land areas. *Environ. Res. Lett.*, **13**, 124022.",
 "Harris, I., T. J. Osborn, P. Jones, and D. Lister, 2020: Version 4 of the CRU TS monthly high-resolution gridded multivariate climate dataset. *Sci. Data*, **7**, 109.",
 "Hersbach, H., and Coauthors, 2020: The ERA5 global reanalysis. *Quart. J. Roy. Meteor. Soc.*, **146**, 1999–2049.",
 "Hoell, A., A. E. Gaughan, S. Shukla, and T. Magadzire, 2017: The hydrologic effects of synchronous El Niño–Southern Oscillation and subtropical Indian Ocean Dipole events over southern Africa. *J. Hydrometeor.*, **18**, 2407–2425.",
 "Hoell, A., A. E. Gaughan, T. Magadzire, and L. Harrison, 2021: The modulation of daily southern Africa precipitation by El Niño–Southern Oscillation across the summertime wet season. *J. Climate*, **34**, 1115–1134, https://doi.org/10.1175/JCLI-D-20-0379.1.",
 "Howard, E., and R. Washington, 2018: Characterizing the synoptic expression of the Angola Low. *J. Climate*, **31**, 7147–7165, https://doi.org/10.1175/JCLI-D-18-0017.1.",
 "Huang, B., and Coauthors, 2017: Extended Reconstructed Sea Surface Temperature, version 5 (ERSSTv5): Upgrades, validations, and intercomparisons. *J. Climate*, **30**, 8179–8205.",
 "Keune, J., F. Di Giuseppe, C. Barnard, E. Damasio da Costa, and F. Wetterhall, 2025: ERA5–Drought: Global drought indices based on ECMWF reanalysis. *Sci. Data*, **12**, 616, https://doi.org/10.1038/s41597-025-04896-y.",
 "Lindesay, J. A., 1988: South African rainfall, the Southern Oscillation and a Southern Hemisphere semi-annual cycle. *J. Climatol.*, **8**, 17–30.",
 "Manatsa, D., and C. H. Matarira, 2009: Changing dependence of Zimbabwean rainfall variability on ENSO and the Indian Ocean dipole/zonal mode. *Theor. Appl. Climatol.*, **98**, 375–396.",
 "Manatsa, D., and G. Mukwada, 2012: Rainfall mechanisms for the dominant rainfall mode over Zimbabwe relative to ENSO and/or IODZM. *Sci. World J.*, **2012**, 926310.",
 "Manatsa, D., W. Chingombe, and C. H. Matarira, 2008: The impact of the positive Indian Ocean dipole on Zimbabwe droughts. *Int. J. Climatol.*, **28**, 2011–2029.",
 "Mbokodo, I. L., M.-J. M. Bopape, T. Ndarana, and Coauthors, 2023: Heatwave variability and structure in South Africa during summer drought. *Climate*, **11**, 38.",
 "Munday, C., and R. Washington, 2017: Circulation controls on southern African precipitation in coupled models: The role of the Angola Low. *J. Geophys. Res. Atmos.*, **122**, 861–877, https://doi.org/10.1002/2016JD025736.",
 "Muñoz-Sabater, J., and Coauthors, 2021: ERA5-Land: A state-of-the-art global reanalysis dataset for land applications. *Earth Syst. Sci. Data*, **13**, 4349–4383.",
 "Nicholson, S. E., and J. Kim, 1997: The relationship of the El Niño–Southern Oscillation to African rainfall. *Int. J. Climatol.*, **17**, 117–135.",
 "Ratnam, J. V., S. K. Behera, Y. Masumoto, and T. Yamagata, 2014: Remote effects of El Niño and Modoki events on the austral summer precipitation of southern Africa. *J. Climate*, **27**, 3802–3815.",
 "Rayner, N. A., D. E. Parker, E. B. Horton, C. K. Folland, L. V. Alexander, D. P. Rowell, E. C. Kent, and A. Kaplan, 2003: Global analyses of sea surface temperature, sea ice, and night marine air temperature since the late nineteenth century. *J. Geophys. Res.*, **108**, 4407, https://doi.org/10.1029/2002JD002670.",
 "Reason, C. J. C., R. J. Allan, J. A. Lindesay, and T. J. Ansell, 2000: ENSO and climatic signals across the Indian Ocean basin in the global context: Part I, interannual composite patterns. *Int. J. Climatol.*, **20**, 1285–1327.",
 "Rohde, R. A., and Z. Hausfather, 2020: The Berkeley Earth land/ocean temperature record. *Earth Syst. Sci. Data*, **12**, 3469–3479.",
 "Ropelewski, C. F., and M. S. Halpert, 1987: Global and regional scale precipitation patterns associated with the El Niño/Southern Oscillation. *Mon. Wea. Rev.*, **115**, 1606–1626.",
 "Saji, N. H., and T. Yamagata, 2003: Possible impacts of Indian Ocean Dipole mode events on global climate. *Climate Res.*, **25**, 151–169.",
 "Saji, N. H., B. N. Goswami, P. N. Vinayachandran, and T. Yamagata, 1999: A dipole mode in the tropical Indian Ocean. *Nature*, **401**, 360–363.",
 "Ummenhofer, C. C., M. H. England, P. C. McIntosh, G. A. Meyers, M. J. Pook, J. S. Risbey, A. Sen Gupta, and A. S. Taschetto, 2009: What causes southeast Australia’s worst droughts? *Geophys. Res. Lett.*, **36**, L04706.",
 "USDA, 2025: Production, Supply and Distribution database: Zimbabwe corn production. Foreign Agricultural Service, accessed 2025, https://apps.fas.usda.gov/psdonline.",
 "Verdon-Kidd, D. C., 2018: On the classification of different flavours of Indian Ocean Dipole events. *Int. J. Climatol.*, **38**, 4924–4937, https://doi.org/10.1002/joc.5707.",
 "Vicente-Serrano, S. M., S. Beguería, and J. I. López-Moreno, 2010: A multiscalar drought index sensitive to global warming: The Standardized Precipitation Evapotranspiration Index. *J. Climate*, **23**, 1696–1718.",
 "Vincent, V., and R. G. Thomas, 1961: *An Agricultural Survey of Southern Rhodesia. Part I: Agro-Ecological Survey*. Government Printer, Salisbury, 124 pp.",
 "Webster, P. J., A. M. Moore, J. P. Loschnigg, and R. R. Leben, 1999: Coupled ocean–atmosphere dynamics in the Indian Ocean during 1997–98. *Nature*, **401**, 356–360.",
 "Williams, C. A., and N. P. Hanan, 2011: ENSO and IOD teleconnections for African ecosystems: Evidence of destructive interference between climate oscillations. *Biogeosciences*, **8**, 27–40.",
 "Zscheischler, J., and Coauthors, 2018: Future climate risk from compound events. *Nat. Climate Change*, **8**, 469–477.",
]
FIG2 = ('Fig02_chronology', f"**Figure 2.** ENSO–IOD chronology. (a) DJF ONI against SON DMI for every season, 1951–2024, coloured by state; dashed lines mark the event thresholds and dotted lines the tercile bounds for 1951–2017; diamonds mark the 2018–2024 seasons covered only by CHIRPS. (b) Number of seasons in each of the nine states for 1951–2017 (solid) and 2018–2024 (hatched).")
