"""Representative Natural Region series from the MSD 46-station archive, with QC."""
import pandas as pd, numpy as np
X='/home/claude/data/zim/zimbabwe_natural_region_representative_timeseries_1951_2017_to be used.xlsx'
NRS=['I','II','III','IV','V']
import os
MEMBERSHIP=os.environ.get('NR_MEMBERSHIP','poly')   # 'poly' (point-in-polygon, corrected coordinates) or 'msd'
def load_raw(membership=None):
    membership=membership or MEMBERSHIP
    x=pd.read_excel(X,sheet_name=None)
    reg=x['Station_Regions'][['Station','Natural_Region','Longitude','Latitude']]
    if membership=='poly':
        st=pd.read_csv('/home/claude/analysis/stations_table.csv')[['Station','NR_poly','Longitude','Latitude']].rename(columns={'NR_poly':'Natural_Region'})
        reg=st
    raw=x['Raw_Station_Data']
    raw=raw.drop(columns=[c for c in raw.columns if c.startswith('Natural_Region')]+['Longitude','Latitude']).merge(reg,on='Station',how='left')
    raw=raw[pd.to_numeric(raw.Year,errors='coerce').notna()].copy(); raw['Year']=raw.Year.astype(int)
    return raw, reg
def station_normal(s, years):
    v=s[(years>=1983)&(years<=2017)].dropna()
    if len(v)>=5: return v.mean()
    v=s.dropna(); return v.mean() if len(v)>=3 else np.nan
def qc(raw, verbose=False):
    raw=raw.copy(); log=[]
    # 1. timing variables: impossible ordering
    bad=(raw.SOS.notna()&raw.EOS.notna()&(raw.SOS>=raw.EOS))|(raw.LOS<0)
    # Lupane: SOS exceeds EOS in every season 1983-2017 -> whole timing record unusable
    for st,g in raw[bad].groupby('Station'): log.append(('timing SOS>=EOS',st,sorted(g.Year.tolist())))
    raw.loc[bad,['SOS','EOS','LOS']]=np.nan
    raw.loc[raw.Station=='Lupane',['SOS','EOS','LOS']]=np.nan
    # SOS=365 means no onset found -> treat as missing for timing composites
    raw.loc[raw.SOS>=365,['SOS','LOS']]=np.nan
    # 2. seasonal totals: ratio to station normal vs median ratio of other stations in same NR-year
    nrm=raw.groupby('Station').apply(lambda g: station_normal(g.Season_T,g.Year))
    raw['ratio']=raw.Season_T/raw.Station.map(nrm)
    def rel(g):
        out=[]
        for i,row in g.iterrows():
            oth=g.drop(i).ratio.dropna(); out.append(row.ratio/oth.median() if len(oth)>=2 else np.nan)
        return pd.Series(out,index=g.index)
    raw['rel']=raw.groupby(['Natural_Region','Year'],group_keys=False).apply(rel)
    flag=(raw.rel>4)|(raw.rel<0.15)|(raw.ratio>5)|(raw.ratio<0.1)
    for _,r in raw[flag].iterrows(): log.append(('Season_T outlier',r.Station,r.Year,round(r.Season_T,1),round(r.ratio,2),round(r.rel,2) if pd.notna(r.rel) else None))
    raw.loc[flag,'Season_T']=np.nan
    return raw, log
def representative(raw, var, how='ratio'):
    """how='ratio' for rainfall (value/normal averaged, rescaled); 'anom' for timing and LODS."""
    nrm=raw.groupby('Station').apply(lambda g: station_normal(g[var],g.Year))
    st_n=raw.Station.map(nrm)
    d=raw.assign(n=st_n)
    d=d[d[var].notna()&d.n.notna()]
    out={}; cnt={}
    for nr in NRS:
        g=d[d.Natural_Region==nr]
        regnorm=nrm[raw[raw.Natural_Region==nr].Station.unique()].mean()
        if how=='ratio': s=(g[var]/g.n).groupby(g.Year).mean()*regnorm
        else: s=(g[var]-g.n).groupby(g.Year).mean()+regnorm
        out[nr]=s; cnt[nr]=g.groupby('Year').size()
    o=pd.DataFrame(out).reindex(range(1951,2018)); c=pd.DataFrame(cnt).reindex(range(1951,2018)).fillna(0).astype(int)
    return o,c
def pct_anom(df):
    return (df/df.mean()-1)*100
def national(anom_df):
    return anom_df.mean(axis=1, skipna=True)
if __name__=='__main__':
    raw,reg=load_raw(); q,log=qc(raw)
    for l in log: print(l)
    R,C=representative(q,'Season_T')
    R0,C0=representative(raw,'Season_T')
    print(R.mean().round(0).to_dict(), R0.mean().round(0).to_dict())
    print('2014 before/after', R0.loc[2014].round(0).to_dict(), R.loc[2014].round(0).to_dict())
    print(C.describe().round(1))
    q.to_pickle('station_qc.pkl')
