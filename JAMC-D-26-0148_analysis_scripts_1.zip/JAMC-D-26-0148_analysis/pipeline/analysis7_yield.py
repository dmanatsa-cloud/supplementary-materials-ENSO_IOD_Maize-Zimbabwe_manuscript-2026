"""FAOSTAT national maize yield (QCL, element 5412, kg/ha) as a robustness check on the USDA production analysis.
FAOSTAT years are harvest years; harvest year H belongs to the season with onset year H-1. -> results_yield.json"""
import json, numpy as np, pandas as pd
import statsmodels.formula.api as smf
from scipy import stats
F = '/home/claude/data/fao/FAOSTAT_maize_yield_Zimbabwe_2026-10-22.csv'
f = pd.read_csv(F)
f = f[(f.Element == 'Yield') & (f.Area == 'Zimbabwe')]
yld = pd.Series(f.Value.values.astype(float), index=f.Year.values.astype(int) - 1).sort_index().loc[1960:2023]   # onset years
flag = pd.Series(f.Flag.values, index=f.Year.values.astype(int) - 1).sort_index().loc[1960:2023]
D = pd.read_pickle('cache_data.pkl'); A = D['A']; Tm = D['T']
T = pd.read_csv('season_class_primary.csv', index_col=0)
M = pd.read_pickle('maize_series.pkl'); ma = M['ma']
CATS4 = ['LN+nIOD', 'LN only', 'EN only', 'EN+pIOD']
def era_detrend(s):
    out = pd.Series(index=s.index, dtype=float); fit = pd.Series(index=s.index, dtype=float)
    for a, b in [(1960, 1999), (2000, 2023)]:
        ss = s.loc[a:b]; p = np.polyfit(ss.index, ss.values, 1); fv = np.polyval(p, ss.index); fit.loc[a:b] = fv; out.loc[a:b] = (ss.values - fv) / fv * 100
    return out, fit
def welch(x, y):
    x = np.asarray(x, float); y = np.asarray(y, float); return dict(d=float(x.mean() - y.mean()), p=float(stats.ttest_ind(x, y, equal_var=False).pvalue), na=len(x), nb=len(y))
ya, yfit = era_detrend(yld)
def comps(s, years):
    t = T.loc[list(years)]; s = s.reindex(list(years)); neu = s[(t.cat == 'Neutral').values]
    cat = {c: dict(mean=float(s[(t.cat == c).values].mean()), n=int((t.cat == c).sum())) for c in CATS4 + ['Neutral']}
    vs = {c: welch(s[(t.cat == c).values], neu) for c in CATS4}
    return cat, vs
yrs = range(1960, 2024)
cat, vs = comps(ya, yrs)
dM = pd.DataFrame({'m': ya, 'oni': T.loc[1960:2023, 'oni'], 'dmi': T.loc[1960:2023, 'dmi']}).dropna()
r2 = lambda fo: smf.ols(fo, dM).fit().rsquared
R2f, R2e, R2i = r2('m~oni+dmi'), r2('m~oni'), r2('m~dmi')
zs = (dM - dM.mean()) / dM.std(); fit_s = smf.ols('m~oni+dmi', zs).fit()
yy = list(range(1960, 2018))
links = {}
for v, s in [('SOS', Tm['SOS']['Nat']), ('Dec_LODS', Tm['Dec_LODS']['Nat']), ('Feb_LODS', Tm['Feb_LODS']['Nat']), ('Season_T', A['Nat'])]:
    r, p = stats.pearsonr(s.loc[yy], ya.loc[yy]); links[v] = dict(r=float(r), p=float(p))
# official-value sensitivity: drop FAOSTAT estimated values (flag E)
off = [y for y in yrs if flag.loc[y] != 'E']
cat_off, vs_off = comps(ya, off)
out = dict(source='FAOSTAT QCL, Maize (corn), Zimbabwe, Yield (kg/ha), downloaded 22 Oct 2026', n=len(ya),
           n_estimated=int((flag == 'E').sum()), estimated_years=[int(y) + 1 for y in flag.index[flag == 'E']],
           mean_pre2000=float(yld.loc[1960:1999].mean()), mean_post2000=float(yld.loc[2000:2023].mean()),
           cat=cat, vs_neu=vs, R2_full=R2f, R2_enso=R2e, R2_iod=R2i, uniq_enso=R2f - R2i, uniq_iod=R2f - R2e, shared=R2e + R2i - R2f,
           beta_oni=float(fit_s.params.oni), p_oni=float(fit_s.pvalues.oni), beta_dmi=float(fit_s.params.dmi), p_dmi=float(fit_s.pvalues.dmi),
           links=links, r_rain=links['Season_T']['r'], p_rain=links['Season_T']['p'],
           r_with_usda_prod=float(np.corrcoef(ya.loc[1960:2023], ma.loc[1960:2023])[0, 1]),
           official_only=dict(n=len(off), vs_neu=vs_off, cat=cat_off),
           y2015=float(yld.loc[2015]), y2023=float(yld.loc[2023]), y1991=float(yld.loc[1991]))
# ---- FAOSTAT area harvested and production (same download date)
G = pd.read_csv('/home/claude/data/fao/FAOSTAT_maize_area_production_Zimbabwe_2026-10-22.csv')
def fser(el):
    x = G[G.Element == el]; return pd.Series(x.Value.values.astype(float), index=x.Year.values.astype(int) - 1).sort_index().loc[1960:2023]
area_h, prod_f = fser('Area harvested'), fser('Production')
def full_stats(series):
    an, _ = era_detrend(series); c_, v_ = comps(an, yrs)
    dd = pd.DataFrame({'m': an, 'oni': T.loc[1960:2023, 'oni'], 'dmi': T.loc[1960:2023, 'dmi']})
    rr = lambda fo: smf.ols(fo, dd).fit().rsquared; zz = (dd - dd.mean()) / dd.std(); ff = smf.ols('m~oni+dmi', zz).fit()
    r_, p_ = stats.pearsonr(A['Nat'].loc[yy], an.loc[yy])
    return an, dict(cat=c_, vs_neu=v_, R2_full=rr('m~oni+dmi'), uniq_enso=rr('m~oni+dmi') - rr('m~dmi'), uniq_iod=rr('m~oni+dmi') - rr('m~oni'),
                    shared=rr('m~oni') + rr('m~dmi') - rr('m~oni+dmi'), beta_oni=float(ff.params.oni), p_oni=float(ff.pvalues.oni),
                    beta_dmi=float(ff.params.dmi), p_dmi=float(ff.pvalues.dmi), r_rain=float(r_), p_rain=float(p_))
aa, out['area'] = full_stats(area_h)
pa, out['fao_prod'] = full_stats(prod_f)
out['fao_prod']['r_with_usda_prod'] = float(np.corrcoef(pa, ma.loc[1960:2023])[0, 1])
out['r_area_yield'] = float(np.corrcoef(aa, ya)[0, 1])
# log decomposition of the production deficit relative to neutral: log P = log A + log Y
def edlog(sr):
    o = pd.Series(index=sr.index, dtype=float); l = np.log(sr)
    for a_, b_ in [(1960, 1999), (2000, 2023)]:
        ss = l.loc[a_:b_]; p_ = np.polyfit(ss.index, ss.values, 1); o.loc[a_:b_] = (ss.values - np.polyval(p_, ss.index)) * 100
    return o
la, lyy, lp = edlog(area_h), edlog(yld), edlog(prod_f); cat_ = T.loc[1960:2023, 'cat']; neu_ = cat_ == 'Neutral'
out['decomp'] = {c: dict(prod=float(lp[cat_ == c].mean() - lp[neu_].mean()), area=float(la[cat_ == c].mean() - la[neu_].mean()),
                         yld=float(lyy[cat_ == c].mean() - lyy[neu_].mean())) for c in ['EN+pIOD', 'EN only']}
for c in out['decomp']: out['decomp'][c]['yield_share'] = out['decomp'][c]['yld'] / out['decomp'][c]['prod']
out['source'] = 'FAOSTAT QCL, Maize (corn), Zimbabwe: yield, area harvested and production, downloaded 22 Oct 2026'
pd.to_pickle(dict(aa=aa, pa=pa), 'fao_area_prod_series.pkl')
json.dump(out, open('results_yield.json', 'w'), indent=1, default=float)
print('area', {c: (round(v['d'], 1), round(v['p'], 3)) for c, v in out['area']['vs_neu'].items()}, 'r_rain', round(out['area']['r_rain'], 2))
print('fao prod', {c: (round(v['d'], 1), round(v['p'], 3)) for c, v in out['fao_prod']['vs_neu'].items()}, round(out['fao_prod']['uniq_enso'], 3), round(out['fao_prod']['uniq_iod'], 3))
print('decomp', {c: {k: round(v, 2) for k, v in d.items()} for c, d in out['decomp'].items()})
pd.to_pickle(dict(yld=yld, ya=ya, yfit=yfit, flag=flag), 'yield_series.pkl')
print(json.dumps({k: (round(v, 3) if isinstance(v, float) else v) for k, v in out.items() if k not in ('cat', 'vs_neu', 'links', 'official_only')}))
print({c: (round(v['d'], 1), round(v['p'], 3), v['na']) for c, v in vs.items()}); print({c: round(v['mean'], 1) for c, v in cat.items()})
print('official only', {c: (round(v['d'], 1), round(v['p'], 3), v['na']) for c, v in vs_off.items()})
print('links', {k: (round(v['r'], 2), round(v['p'], 3)) for k, v in links.items()})
