"""Assemble all season-indexed series (index = onset year y; season Oct y - Mar y+1)."""
import pandas as pd, numpy as np, xarray as xr, warnings
warnings.filterwarnings('ignore')
from stations import load_raw, qc, representative, pct_anom, NRS
from indices import build, seasonal_table
from masks import nr_means
G='/home/claude/data/grid/'; Z='/home/claude/data/zim/'
def station_block():
    q=pd.read_pickle('/home/claude/analysis/station_qc.pkl')
    R,C=representative(q,'Season_T'); A=pct_anom(R); A['Nat']=A[NRS].mean(axis=1)
    T={}
    for v in ['SOS','EOS','LOS']+[f'{m}_LODS' for m in ['Oct','Nov','Dec','Jan','Feb','Mar']]:
        r,c=representative(q,v,how='anom'); r['Nat']=r[NRS].mean(axis=1); T[v]=r
    return q,R,C,A,T
def chirps_block():
    d=pd.read_pickle('/home/claude/analysis/chirps_daily_nr.pkl')
    mon=d.resample('MS').sum(min_count=25)
    seas={}
    for y in range(1981,2026):
        sel=mon[(mon.index>=f'{y}-10-01')&(mon.index<=f'{y+1}-03-01')]
        if len(sel)==6: seas[y]=sel.sum()
    S=pd.DataFrame(seas).T
    A=(S/S.loc[1981:2024].mean()-1)*100
    return d,mon,S,A
def spei_block():
    s=pd.read_csv(Z+'spei6_seasonal_by_zone.csv',index_col=0); s['Nat']=s[NRS].mean(axis=1); return s
def berkeley_tmax():
    ds=xr.open_dataset(G+'TMAX_Daily_LatLong1_25.25-33.50E_-22.50--15.25N_1970-2026_su.nc',decode_times=False)
    t=pd.Timestamp('1970-01-01')+pd.to_timedelta(ds.time.values,unit='D')
    x=ds.TMAX.assign_coords(time=t)
    out,_=nr_means(x)
    nat=out['Nat'].to_series()
    res={}
    for y in range(1970,2026):
        s=nat[(nat.index>=f'{y}-12-01')&(nat.index<f'{y+1}-03-01')]
        if s.notna().sum()>80: res[y]=s.mean()
    return pd.Series(res)
def era5_tmax():
    z=np.load(G+'era5_tmax_seasonal_zim.npz')
    da=xr.DataArray(z['DJF'],dims=('year','lat','lon'),coords=dict(year=z['years'],lat=z['lat'],lon=z['lon']))
    out,_=nr_means(da)
    s=out['Nat'].to_series(); return s-s.loc[1981:2010].mean()
def soil_evap():
    ds=xr.open_dataset(G+'mrsos_ERA5-Land_soil moisture_mon_19500101-20251201.nc')
    sm=ds.mrsos
    sm=sm.sel(lat=slice(-23,-15),lon=slice(25,34)) if sm.lat[0]<sm.lat[-1] else sm.sel(lat=slice(-15,-23),lon=slice(25,34))
    out,_=nr_means(sm)
    SM=pd.DataFrame({k:v.to_series() for k,v in out.items()}); SM.index=pd.to_datetime(SM.index).to_period('M').to_timestamp()
    def knmi(f,var):
        d=xr.open_dataset(G+f,decode_times=False)
        t=pd.DatetimeIndex([pd.Timestamp(1950,1,1)+pd.DateOffset(months=int(m)) for m in d.time.values])
        return d[var].assign_coords(time=t)
    ev=knmi('era5_evap_25-34E_-15.12--22.88N_-999-2026_25-34E_-15.25--22.75N_-999-2026.nc','evap')
    pe=knmi('era5_potevap_25-34E_-15--23N_-999-lastyear.nc','potevap')
    # KNMI ERA5 evaporation fluxes: check sign convention later
    oe,_=nr_means(ev); op,_=nr_means(pe)
    EV=pd.DataFrame({k:v.to_series() for k,v in oe.items()}); PE=pd.DataFrame({k:v.to_series() for k,v in op.items()})
    def djf(M):
        r={}
        for y in range(1950,2026):
            s=M[(M.index>=f'{y}-12-01')&(M.index<f'{y+1}-03-01')]
            if len(s)==3: r[y]=s.mean()
        return pd.DataFrame(r).T
    return djf(SM), djf(EV), djf(PE), EV, PE
def maize():
    m=pd.read_excel(Z+'Zim maize production 1960 to 2025.xlsx')
    s=pd.Series(m.Production.values.astype(float),index=m['Market Year'].astype(int))
    # USDA PSD changed the Zimbabwe marketing-year convention at 1999/2000: MY 1999 and MY 2000 carry the
    # same value (2148). Up to MY 1999 the label is the season-onset year (harvest MY+1); from MY 2000 the
    # label is the harvest year. Map both to season-onset year y (season Oct y - Mar y+1).
    out={}
    for my,v in s.items():
        if my<=1999: out[my]=v
        else: out[my-1]=v if my>=2001 else out.get(1999,v)
    return pd.Series(out).sort_index()
if __name__=='__main__':
    q,R,C,A,T=station_block(); print(A.loc[[1991,2014,2015]].round(1))
    d,mon,S,CA=chirps_block(); print(S.mean().round(0).to_dict()); print(CA.loc[[1991,2015,2023]].round(1))
    sp=spei_block(); print('SPEI-station corr', np.corrcoef(sp.loc[1951:2017,'Nat'],A.loc[1951:2017,'Nat'])[0,1])
    print('SPEI shifted corr (label=March year)', np.corrcoef(sp.loc[1952:2018,'Nat'].values,A.loc[1951:2017,'Nat'].values)[0,1])
    b=berkeley_tmax(); e=era5_tmax(); print('Berkeley-ERA5 Tmax r', b.corr(e), len(b))
    print('Tmax vs CHIRPS rain r', b.loc[1981:2024].corr(CA.loc[1981:2024,'Nat']), 'vs station', b.loc[1970:2017].corr(A.loc[1970:2017,'Nat']))
    sm,ev,pe,EVm,PEm=soil_evap(); print(sm.mean().round(1).to_dict()); print('evap DJF mean',ev.mean().round(2).to_dict(),'pot',pe.mean().round(2).to_dict())
    mz=maize(); print(mz.loc[[2015,2023]])
    pd.to_pickle(dict(q=q,R=R,C=C,A=A,T=T,chd=d,chm=mon,chS=S,chA=CA,spei=sp,tb=b,te=e,sm=sm,ev=ev,pe=pe,EVm=EVm,PEm=PEm,mz=mz),'cache_data.pkl')
