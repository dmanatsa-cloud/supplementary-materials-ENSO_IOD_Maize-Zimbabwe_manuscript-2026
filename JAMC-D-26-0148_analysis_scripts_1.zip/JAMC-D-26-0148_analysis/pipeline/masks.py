import geopandas as gpd, numpy as np, regionmask, xarray as xr
SHP='/home/claude/data/shp/x/AEZ_revised_final.shp'
def nr_polygons():
    g=gpd.read_file(SHP)
    g['NR']=g.Rev_Region.str.replace('a','').str.replace('b','')
    d=g.dissolve(by='NR').reset_index()[['NR','geometry']]
    d=d.set_index('NR').loc[['I','II','III','IV','V']].reset_index()
    return g,d
def mask_for(lon,lat):
    _,d=nr_polygons()
    rm=regionmask.Regions([geom for geom in d.geometry],names=list(d.NR),abbrevs=list(d.NR),numbers=list(range(5)),overlap=False)
    m=rm.mask(lon,lat)   # NaN outside
    return m, d
def nr_means(da, latname='lat', lonname='lon'):
    """Area-weighted mean of da over each NR polygon and the whole country. Small regions with no cell centre use nearest cell."""
    lon=da[lonname]; lat=da[latname]
    m,d=mask_for(lon,lat)
    w=np.cos(np.deg2rad(da[latname]))
    out={}
    for k,nr in enumerate(['I','II','III','IV','V']):
        sel=(m==k)
        if int(sel.sum())==0:
            c=d.geometry[k].centroid
            out[nr]=da.sel({lonname:c.x,latname:c.y},method='nearest')
        else:
            out[nr]=da.where(sel).weighted(w).mean((latname,lonname))
    out['Nat']=da.where(m.notnull()).weighted(w).mean((latname,lonname))
    return out, m
