# Table 1 classification from the submitted manuscript (onset years), 1951-2017
EN_P=[1963,1972,1982,1986,1987,1991,1994,1997,2002,2006,2015]
pureEN=[1957,1965,1968,1976,2004,2009,2014]
pureLN=[1954,1955,1962,1964,1966,1970,1971,1973,1974,1983,1984,1985,1988,1995,1999,2000,2007,2008]
pureP=[1977,2012]; pureN=[1958,1960,1990,1996,2016]
LN_P=[1961,1967,2011,2017]; LN_N=[1956,1975,1998,2005,2010]
NN=[1951,1952,1953,1959,1969,1978,1979,1980,1981,1989,1992,1993,2001,2003,2013]
# CHIRPS-extension years (event table csv)
EXT={2018:('EN','P'),2019:('EN','P'),2020:('LN','0'),2021:('LN','0'),2022:('LN','N'),2023:('EN','P'),2024:('0','0')}
T1={}
for y in EN_P: T1[y]=('EN','P')
for y in pureEN: T1[y]=('EN','0')
for y in pureLN: T1[y]=('LN','0')
for y in pureP: T1[y]=('0','P')
for y in pureN: T1[y]=('0','N')
for y in LN_P: T1[y]=('LN','P')
for y in LN_N: T1[y]=('LN','N')
for y in NN: T1[y]=('0','0')
assert len(T1)==67, len(T1)
T1ext=dict(T1); T1ext.update(EXT)
