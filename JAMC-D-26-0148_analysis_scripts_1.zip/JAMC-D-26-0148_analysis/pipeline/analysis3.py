from analysis import *
R=json.load(open('results_part2.json'))
A=D['A']; Tm=D['T']; q=D['q']; cols=NRS+['Nat']
def lin_detr(s):
    s=s.dropna(); t=np.arange(len(s)); p=np.polyfit(s.index.values.astype(float),s.values,1); return s-np.polyval(p,s.index.values.astype(float))
def cat_vs_neutral(S,t,years,cats=CATS4,col=None):
    t=t.loc[list(years)]; S=S.reindex(list(years))
    neu=t.cat=='Neutral'; out={}
    for c in cats:
        m=t.cat==c
        x=S[m.values] if col is None else S.loc[m.values,col]; y=S[neu.values] if col is None else S.loc[neu.values,col]
        out[c]=welch(x,y)
    out['Neutral_mean']=float((S[neu.values] if col is None else S.loc[neu.values,col]).mean())
    return out
# ---------------- timing (SOS/EOS/LOS)
tim={}
for v in ['SOS','EOS','LOS']:
    s=Tm[v]['Nat']
    tim[v]=dict(clim=float(s.loc[1951:2017].mean()),comp=cat_vs_neutral(s,T,yrs_st,CATS4+['nIOD only']),
               indiv={nm:welch(s[(T.loc[1951:2017,f]==val).values],s[(T.loc[1951:2017,f]!=val).values]) for nm,f,val in [('EN','enso','EN'),('LN','enso','LN'),('pIOD','iod','P'),('nIOD','iod','M')]},
               nr={nr:cat_vs_neutral(Tm[v][nr],T,yrs_st,['EN+pIOD','EN only']) for nr in NRS})
# station spread: per-station composite difference (category minus neutral) for SOS and LOS
qq=q.copy(); qq=qq[(qq.Year>=1951)&(qq.Year<=2017)]
qq['cat']=qq.Year.map(T.cat)
spread={}
for v in ['SOS','EOS','LOS']:
    for c in ['EN+pIOD','EN only','LN+nIOD']:
        diffs=[]
        for st,g in qq.groupby('Station'):
            a=g.loc[g.cat==c,v].dropna(); b=g.loc[g.cat=='Neutral',v].dropna()
            if len(a)>=3 and len(b)>=3: diffs.append(a.mean()-b.mean())
        diffs=np.array(diffs)
        spread[f'{v}|{c}']=dict(n_st=len(diffs),median=float(np.median(diffs)),q25=float(np.percentile(diffs,25)),q75=float(np.percentile(diffs,75)),
                                frac_pos=float((diffs>0).mean()),frac_neg=float((diffs<0).mean()))
tim['station_spread']=spread
tim['eos_floor_frac']=float((q.EOS==245).sum()/q.EOS.notna().sum())
tim['eos_floor_by_cat']={c:float((qq.loc[qq.cat==c,'EOS']==245).sum()/max(1,qq.loc[qq.cat==c,'EOS'].notna().sum())) for c in CATS4+['Neutral']}
tim['sos_min']=float(q.SOS.min()); tim['eos_min']=float(q.EOS.min())
# per-year across-station SD of SOS anomalies (uncertainty of national mean)
sosanom=qq.assign(a=qq.SOS-qq.groupby('Station').SOS.transform(lambda s: s.loc[(qq.loc[s.index,'Year']>=1983)].mean()))
tim['sos_station_sd_median']=float(sosanom.groupby('Year').a.std().median())
# bootstrap CI for national timing composites
for v in ['SOS','LOS']:
    s=Tm[v]['Nat'].loc[1951:2017]; t=T.loc[1951:2017]
    tim[v]['boot']={c:boot(s[(t.cat==c).values],s[(t.cat=='Neutral').values]) for c in ['EN+pIOD','EN only']}
R['timing']=tim
# ---------------- partial correlations (national, 1951-2017)
t=T.loc[1951:2017]
P=pd.DataFrame({'SOS':Tm['SOS']['Nat'],'LOS':Tm['LOS']['Nat'],'Season_T':A['Nat'],
   'OND_LODS':(Tm['Oct_LODS']['Nat']+Tm['Nov_LODS']['Nat']+Tm['Dec_LODS']['Nat'])/3,'Dec_LODS':Tm['Dec_LODS']['Nat'],
   'JF_LODS':(Tm['Jan_LODS']['Nat']+Tm['Feb_LODS']['Nat'])/2,'Feb_LODS':Tm['Feb_LODS']['Nat']}).loc[1951:2017]
P['oni']=t.oni; P['dmi']=t.dmi
def pcor(y,x,z):
    d=P[[y,x,z]].dropna(); rx=sm.OLS(d[x],sm.add_constant(d[z])).fit().resid; ry=sm.OLS(d[y],sm.add_constant(d[z])).fit().resid
    r,p=stats.pearsonr(rx,ry); return dict(r=float(r),p=float(p),n=len(d))
R['pcor']={v:dict(iod=pcor(v,'dmi','oni'),enso=pcor(v,'oni','dmi')) for v in ['SOS','OND_LODS','Dec_LODS','Season_T','JF_LODS','Feb_LODS','LOS']}
# seasonality of indices
mon_sd={}
for mname,m in [('Sep',9),('Oct',10),('Nov',11),('Dec',12),('Jan',1),('Feb',2),('Mar',3)]:
    sel=[pd.Timestamp(y+(1 if m<7 else 0),m,1) for y in range(1951,2018)]
    mon_sd[mname]=dict(dmi=float(IDX.dmi_roll.reindex(sel).std()),n34=float(IDX.n34_roll.reindex(sel).std()))
dmi_djf=pd.Series({y:seas(IDX.dmi_roll,y,(12,1,2)) for y in range(1951,2018)})
R['seasonality']=dict(mon_sd=mon_sd,sd_son=float(t.dmi.std()),sd_djf=float(dmi_djf.std()),r_son_djf=float(np.corrcoef(t.dmi,dmi_djf)[0,1]),
   r_rain_son=float(np.corrcoef(A.loc[1951:2017,'Nat'],t.dmi)[0,1]),p_rain_son=float(stats.pearsonr(A.loc[1951:2017,'Nat'],t.dmi)[1]),
   r_rain_djf=float(np.corrcoef(A.loc[1951:2017,'Nat'],dmi_djf)[0,1]),p_rain_djf=float(stats.pearsonr(A.loc[1951:2017,'Nat'],dmi_djf)[1]))
# ---------------- non-stationarity, trend, Pettitt, skill
nat=A.loc[1951:2017,'Nat']
def pettitt(x):
    x=np.asarray(x); n=len(x); U=[np.sum(np.sign(x[:k+1,None]-x[None,k+1:])) for k in range(n-1)]
    K=np.max(np.abs(U)); k=int(np.argmax(np.abs(U))); p=2*np.exp(-6*K**2/(n**3+n**2)); return K,k,min(1,p)
K,k,pp=pettitt(nat.values); tr=stats.linregress(nat.index,nat.values)
win={}
for y0 in range(1951,1999):
    w=list(range(y0,y0+20)); win[y0]=float(np.corrcoef(A.loc[w,'Nat'],T.loc[w,'oni'])[0,1])
pre=list(range(1951,1990)); post=list(range(1990,2018))
R['nonstat']=dict(pettitt_K=float(K),pettitt_year=int(nat.index[k]),pettitt_p=float(pp),trend_pct_per_decade=float(tr.slope*10),trend_p=float(tr.pvalue),
   sliding=win,first=win[1951],last=win[1998],min_win=int(min(win,key=win.get)),min_r=float(min(win.values())),
   slope_pre=float(stats.linregress(T.loc[pre,'oni'],A.loc[pre,'Nat']).slope),slope_post=float(stats.linregress(T.loc[post,'oni'],A.loc[post,'Nat']).slope),
   r_pre=float(np.corrcoef(T.loc[pre,'oni'],A.loc[pre,'Nat'])[0,1]),r_post=float(np.corrcoef(T.loc[post,'oni'],A.loc[post,'Nat'])[0,1]))
# LOOCV skill
def loocv(Xm,y):
    pr=[]
    for i in range(len(y)):
        msk=np.ones(len(y),bool); msk[i]=False
        b=np.linalg.lstsq(np.c_[np.ones(msk.sum()),Xm[msk]],y[msk],rcond=None)[0]; pr.append(np.r_[1,Xm[i]]@b)
    pr=np.array(pr); return float(np.corrcoef(pr,y)[0,1]), float(np.mean(np.sign(pr)==np.sign(y)))
yv=nat.values
X1=np.c_[t.oni.values,t.dmi.values]
AS=lambda s,y: seas(s,y,(8,9))
X2=np.c_[[AS(IDX.n34_roll,y) for y in range(1951,2018)],[AS(IDX.dmi_roll,y) for y in range(1951,2018)]]
X3=np.c_[[seas(IDX.n34_roll,y,(9,10,11)) for y in range(1951,2018)],t.dmi.values]
r1,h1=loocv(X1,yv); r2,h2=loocv(X2,yv); r3,h3=loocv(X3,yv)
R['skill']=dict(concurrent_r=r1,concurrent_hit=h1,preseason_r=r2,preseason_hit=h2,son_r=r3,son_hit=h3)
# ---------------- CHIRPS validation and extension
CA=D['chA']
val={c:dict(r=float(np.corrcoef(A.loc[1981:2017,c],CA.loc[1981:2017,c])[0,1]),p=float(stats.pearsonr(A.loc[1981:2017,c],CA.loc[1981:2017,c])[1])) for c in cols}
ext=composites(CA,T,yrs_ch,cols)
rank=CA.loc[1981:2024,'Nat'].rank()
R['chirps']=dict(val=val,ext=ext,clim_mm={c:float(D['chS'].loc[1981:2024,c].mean()) for c in cols},
   a2023=float(CA.loc[2023,'Nat']),a2015=float(CA.loc[2015,'Nat']),a1991=float(CA.loc[1991,'Nat']),a2018=float(CA.loc[2018,'Nat']),a2019=float(CA.loc[2019,'Nat']),
   rank2023=int(rank.loc[2023]),rank2015=int(rank.loc[2015]),rank1991=int(rank.loc[1991]),driest=[int(y) for y in CA.loc[1981:2024,'Nat'].sort_values().index[:5]],
   driest_vals=[float(v) for v in CA.loc[1981:2024,'Nat'].sort_values().values[:5]])
# combined station 1951-2017 + CHIRPS 2018-2024 composite
comb=pd.concat([A.loc[1951:2017,cols],CA.loc[2018:2024,cols]])
R['combined']=composites(comb,T,range(1951,2025),cols)
# ---------------- SPEI-6
sp=D['spei']
R['spei']=dict(comp=composites(sp,T,yrs_st,cols),abs={c:float(sp.loc[[y for y in yrs_st if T.loc[y,'cat']==c],'Nat'].mean()) for c in CATS4+['Neutral']},
   abs_nr={c:{nr:float(sp.loc[[y for y in yrs_st if T.loc[y,'cat']==c],nr].mean()) for nr in NRS} for c in CATS4+['Neutral']},
   r_station={c:float(np.corrcoef(sp.loc[1951:2017,c],A.loc[1951:2017,c])[0,1]) for c in cols})
en=(T.loc[1951:2017,'enso']=='EN').values
R['cohen']={c:dict(rain=cohen_d(A.loc[1951:2017,c][en],A.loc[1951:2017,c][~en]),spei=cohen_d(sp.loc[1951:2017,c][en],sp.loc[1951:2017,c][~en])) for c in cols}
enp=(T.loc[1951:2017,'cat']=='EN+pIOD').values
R['cohen_enp']={c:dict(rain=cohen_d(A.loc[1951:2017,c][enp],A.loc[1951:2017,c][~enp]),spei=cohen_d(sp.loc[1951:2017,c][enp],sp.loc[1951:2017,c][~enp])) for c in cols}
# ---------------- temperature (Berkeley Earth daily TMAX, ERA5 Tmax), 1970-2024 DJF
tb=D['tb'].loc[1970:2024]; te_=D['te'].loc[1970:2024]
tbd=lin_detr(tb); ted=lin_detr(te_)
yrsT=range(1970,2025)
def absmeans(S): return {c:float(S.reindex([y for y in yrsT if T.loc[y,'cat']==c]).mean()) for c in CATS4+['Neutral']}
R['temp']=dict(berk_raw=absmeans(tb-tb.loc[1981:2010].mean()),era_raw=absmeans(te_-te_.loc[1981:2010].mean()),berk_detr=absmeans(tbd),era_detr=absmeans(ted),
   berk_vs_neu=cat_vs_neutral(tbd,T,yrsT),era_vs_neu=cat_vs_neutral(ted,T,yrsT),
   r_berk_era=float(tb.corr(te_)),trend_berk=float(np.polyfit(tb.index,tb.values,1)[0]*10),
   r_rain_berk_st=float(np.corrcoef(A.loc[1970:2017,'Nat'],tbd.loc[1970:2017])[0,1]),p_rain_berk_st=float(stats.pearsonr(A.loc[1970:2017,'Nat'],tbd.loc[1970:2017])[1]),
   r_rain_era_ch=float(np.corrcoef(CA.loc[1981:2024,'Nat'],ted.loc[1981:2024])[0,1]),
   r_rain_berk_st_raw=float(np.corrcoef(A.loc[1970:2017,'Nat'],tb.loc[1970:2017])[0,1]),
   counts={c:int(sum(T.loc[y,'cat']==c for y in yrsT)) for c in CATS4+['Neutral']})
# ---------------- land surface (ERA5-Land soil moisture, ERA5 PET-ET), DJF 1951-2024, detrended
sm_=D['sm'].loc[1951:2024]; stress=(D['pe']-D['ev']).loc[1951:2024]
smd=sm_.apply(lin_detr); std_=stress.apply(lin_detr)
yrsL=range(1951,2025)
R['land']=dict(sm={c:cat_vs_neutral(smd[c],T,yrsL,CATS4+['nIOD only']) for c in cols},stress={c:cat_vs_neutral(std_[c],T,yrsL,CATS4+['nIOD only']) for c in cols},
   sm_clim={c:float(sm_[c].mean()) for c in cols},stress_clim={c:float(stress[c].mean()) for c in cols},
   sm_trend=float(np.polyfit(sm_.index,sm_['Nat'],1)[0]*10),stress_trend=float(np.polyfit(stress.index,stress['Nat'],1)[0]*10),
   r_sm_rain=float(np.corrcoef(smd.loc[1951:2017,'Nat'],A.loc[1951:2017,'Nat'])[0,1]),counts={c:int(sum(T.loc[y,'cat']==c for y in yrsL)) for c in CATS4+['Neutral']})
json.dump(R,open('results_part3.json','w'),indent=1,default=float)
if __name__=='__main__':
    for v in ['SOS','EOS','LOS']:
        print(v,'clim',round(R['timing'][v]['clim'],1),{c:(round(x['d'],1),round(x['p'],3)) for c,x in R['timing'][v]['comp'].items() if isinstance(x,dict)},{c:(round(x['d'],1),round(x['p'],3)) for c,x in R['timing'][v]['indiv'].items()})
    print(R['timing']['station_spread']); print('EOS floor',R['timing']['eos_floor_frac'],R['timing']['eos_floor_by_cat'],R['timing']['sos_station_sd_median'])
    print({v:{k:(round(x['r'],2),round(x['p'],3)) for k,x in d.items()} for v,d in R['pcor'].items()})
    print(R['seasonality']); print({k:v for k,v in R['nonstat'].items() if k!='sliding'}); print(R['skill'])
    print(R['chirps']['val']); print({k:(v['n'],round(v['Nat']['d'],1),round(v['Nat']['p'],3)) for k,v in R['chirps']['ext'].items() if 'Nat' in v}); print({k:R['chirps'][k] for k in R['chirps'] if k.startswith(('a','rank','driest'))})
    print({k:(v['n'],round(v['Nat']['d'],1),round(v['Nat']['p'],4)) for k,v in R['combined'].items() if 'Nat' in v})
    print('SPEI abs',R['spei']['abs'], {k:(round(v['Nat']['d'],2),round(v['Nat']['p'],3)) for k,v in R['spei']['comp'].items() if 'Nat' in v}, R['spei']['r_station'])
    print('cohen',R['cohen']); print('cohen enp',R['cohen_enp'])
    print('temp',{k:R['temp'][k] for k in R['temp'] if k not in ('berk_vs_neu','era_vs_neu')}); print({c:(round(x['d'],2),round(x['p'],3)) for c,x in R['temp']['berk_vs_neu'].items() if isinstance(x,dict)},{c:(round(x['d'],2),round(x['p'],3)) for c,x in R['temp']['era_vs_neu'].items() if isinstance(x,dict)})
    print('land sm',{c:(round(x['d'],2),round(x['p'],3)) for c,x in R['land']['sm']['Nat'].items() if isinstance(x,dict)},'clim',R['land']['sm_clim']['Nat'],'trend',R['land']['sm_trend'])
    print('land stress',{c:(round(x['d'],2),round(x['p'],3)) for c,x in R['land']['stress']['Nat'].items() if isinstance(x,dict)},R['land']['stress_clim']['Nat'],R['land']['stress_trend'],R['land']['counts'])
    print('sm by NR EN+pIOD',{nr:(round(R['land']['sm'][nr]['EN+pIOD']['d'],2),round(R['land']['sm'][nr]['EN+pIOD']['p'],3)) for nr in cols})
