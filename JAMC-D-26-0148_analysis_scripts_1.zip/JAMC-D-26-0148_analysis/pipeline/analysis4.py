from analysis3 import *
import xarray as xr
from masks import mask_for
R=json.load(open('results_part3.json'))
G='/home/claude/data/grid/'
def load_npz(name):
    z=np.load(G+name); return {k:z[k] for k in z.files}
def field_composite(F,years,season,t,cats,detrend=False):
    arr=F[season]; yrs=list(F['years'])
    sel=[yrs.index(y) for y in years if y in yrs]
    yy=[yrs[i] for i in sel]; X=arr[sel].astype(float)
    if detrend:
        tt=np.array(yy,float); A_=np.c_[np.ones(len(tt)),tt]
        Xf=X.reshape(len(tt),-1); ok=~np.isnan(Xf).any(0)
        b=np.linalg.lstsq(A_,Xf[:,ok],rcond=None)[0]; Xf[:,ok]=Xf[:,ok]-A_@b+Xf[:,ok].mean(0); X=Xf.reshape(X.shape)
    cat=np.array([t.loc[y,'cat'] for y in yy])
    neu=X[cat=='Neutral']; out={}
    for c in cats:
        a=X[cat==c]; tt_,pp=stats.ttest_ind(a,neu,axis=0,equal_var=False)
        out[c]=dict(diff=a.mean(0)-neu.mean(0),p=pp,n=int((cat==c).sum()))
    out['clim']=X.mean(0); out['n_neu']=int((cat=='Neutral').sum())
    return out
W=load_npz('era5_w500_seasonal_0p5.npz'); Z5=load_npz('era5_z500_seasonal_0p5.npz'); Z8=load_npz('era5_z850_seasonal_0p5.npz')
cats=['EN+pIOD','EN only','LN+nIOD','LN only']
yrs=range(1951,2025); yrsZ=range(1980,2025)
cw=field_composite(W,yrs,'DJF',T,cats); cwo=field_composite(W,yrs,'OND',T,cats)
cz5=field_composite(Z5,yrsZ,'DJF',T,cats,detrend=True); cz8=field_composite(Z8,yrsZ,'DJF',T,cats,detrend=True)
cz5r=field_composite(Z5,yrsZ,'DJF',T,cats,detrend=False)
pd.to_pickle(dict(cw=cw,cwo=cwo,cz5=cz5,cz8=cz8,cz5r=cz5r,lat=W['lat'],lon=W['lon'],latz=Z5['lat'],lonz=Z5['lon']),'mech_fields.pkl')
# Zimbabwe-mean values (mask)
def zim_mean(diff,lat,lon):
    m,_=mask_for(np.asarray(lon,float),np.asarray(lat,float))
    mm=m.notnull().values; w=np.cos(np.deg2rad(lat))[:,None]*np.ones((1,len(lon)))
    return float(np.nansum(diff*w*mm)/np.nansum(w*mm))
def box_series(F,season,la0,la1,lo0,lo1,detrend=False):
    lat=F['lat']; lon=F['lon']; ii=(lat>=la0)&(lat<=la1); jj=(lon>=lo0)&(lon<=lo1)
    w=np.cos(np.deg2rad(lat[ii]))[:,None]
    s=pd.Series([float(np.nansum(F[season][k][np.ix_(ii,jj)]*w)/np.nansum(w*np.ones(jj.sum()))) for k in range(len(F['years']))],index=F['years'])
    s=s.dropna(); return lin_detr(s) if detrend else s
mech={}
for nm,c_,lat,lon in [('w500_DJF',cw,W['lat'],W['lon']),('w500_OND',cwo,W['lat'],W['lon']),('z500_DJF',cz5,Z5['lat'],Z5['lon']),('z850_DJF',cz8,Z8['lat'],Z8['lon'])]:
    mech[nm]={c:dict(zim=zim_mean(c_[c]['diff'],lat,lon),n=c_[c]['n']) for c in cats}
    # fraction of Zimbabwe cells with p<0.05
    m,_=mask_for(np.asarray(lon,float),np.asarray(lat,float)); mm=m.notnull().values
    for c in cats: mech[nm][c]['frac_sig']=float(np.mean(c_[c]['p'][mm]<0.05))
# Zimbabwe-mean omega series tests (season-level Welch)
def zim_series(F,season):
    lat=F['lat'];lon=F['lon']
    m,_=mask_for(np.asarray(lon,float),np.asarray(lat,float)); mm=m.notnull().values
    w=np.cos(np.deg2rad(lat))[:,None]*np.ones((1,len(lon)))
    return pd.Series([float(np.nansum(F[season][k]*w*mm)/np.nansum(w*mm)) for k in range(len(F['years']))],index=F['years'])
wz=zim_series(W,'DJF'); wzo=zim_series(W,'OND')
mech['w500_zim_tests']={c:cat_vs_neutral(wz,T,yrs,[c])[c] for c in cats}
mech['w500_zim_tests_OND']={c:cat_vs_neutral(wzo,T,yrs,[c])[c] for c in cats}
mech['r_w500_rain']=float(np.corrcoef(wz.loc[1951:2017],A.loc[1951:2017,'Nat'])[0,1])
mech['w500_clim']=float(wz.loc[1951:2024].mean())
# Botswana High and Angola Low indices (detrended, 1980-2024)
bh=box_series(Z5,'DJF',-26,-18,18,28,True); al=box_series(Z8,'DJF',-19,-11,14,25,True)
mech['BH']={c:cat_vs_neutral(bh,T,yrsZ,[c])[c] for c in cats}; mech['AL']={c:cat_vs_neutral(al,T,yrsZ,[c])[c] for c in cats}
for nm,s in [('BH',bh),('AL',al)]:
    y=[yy for yy in range(1981,2025) if yy in s.index]
    mech[nm+'_r_rain']=float(np.corrcoef(s.loc[y],D['chA'].loc[y,'Nat'])[0,1]); mech[nm+'_p_rain']=float(stats.pearsonr(s.loc[y],D['chA'].loc[y,'Nat'])[1])
    mech[nm+'_r_oni']=float(np.corrcoef(s.loc[y],T.loc[y,'oni'])[0,1]); mech[nm+'_r_dmi']=float(np.corrcoef(s.loc[y],T.loc[y,'dmi'])[0,1])
    # partial of rain on index controlling for ONI and DMI
    d=pd.DataFrame({'r':D['chA'].loc[y,'Nat'],'x':s.loc[y],'oni':T.loc[y,'oni'],'dmi':T.loc[y,'dmi']})
    m=smf.ols('r~x+oni+dmi',d).fit(); mech[nm+'_b_given_modes']=float(m.params.x); mech[nm+'_p_given_modes']=float(m.pvalues.x)
    m0=smf.ols('r~oni+dmi',d).fit(); mech[nm+'_dR2']=float(m.rsquared-m0.rsquared); mech['R2_modes_chirps']=float(m0.rsquared)
pd.to_pickle(dict(bh=bh,al=al,wz=wz,wzo=wzo),'mech_series.pkl')
R['mech']=mech
# ---------------- maize
mz=D['mz'].loc[1960:2023]   # onset years 1960..2023
def era_detrend(s):
    out=pd.Series(index=s.index,dtype=float); fit=pd.Series(index=s.index,dtype=float)
    for a,b in [(1960,1999),(2000,2023)]:
        ss=s.loc[a:b]; p=np.polyfit(ss.index,ss.values,1); f=np.polyval(p,ss.index); fit.loc[a:b]=f; out.loc[a:b]=(ss.values-f)/f*100
    return out,fit
ma,mfit=era_detrend(mz)
yrsM=range(1960,2024)
mcat={c:dict(mean=float(ma.reindex([y for y in yrsM if T.loc[y,'cat']==c]).mean()),n=int(sum(T.loc[y,'cat']==c for y in yrsM)),
             years=[int(y) for y in yrsM if T.loc[y,'cat']==c]) for c in CATS4+['Neutral']}
mvs={c:cat_vs_neutral(ma,T,yrsM,[c])[c] for c in CATS4}
low2000=mz.loc[2000:2023].sort_values()
dM=pd.DataFrame({'m':ma,'oni':T.loc[1960:2023,'oni'],'dmi':T.loc[1960:2023,'dmi']}).dropna()
r2=lambda f: smf.ols(f,dM).fit().rsquared
R2f=r2('m~oni+dmi'); R2e=r2('m~oni'); R2i=r2('m~dmi')
zs=(dM-dM.mean())/dM.std(); mz_s=smf.ols('m~oni+dmi',zs).fit()
tM=T.loc[1960:2023]
marg_enso=float(ma[tM.enso=='EN'].mean()-ma[tM.enso=='LN'].mean()); marg_iod=float(ma[tM.iod=='P'].mean()-ma[tM.iod=='M'].mean())
# links with rainfall parameters (station era 1959-2017)
yy=list(range(1960,2018))
lk={}
for v,s in [('SOS',Tm['SOS']['Nat']),('Dec_LODS',Tm['Dec_LODS']['Nat']),('Feb_LODS',Tm['Feb_LODS']['Nat']),('Season_T',A['Nat'])]:
    lk[v]=dict(r_yield=float(np.corrcoef(s.loc[yy],ma.loc[yy])[0,1]),p_yield=float(stats.pearsonr(s.loc[yy],ma.loc[yy])[1]),
               r_rain=float(np.corrcoef(s.loc[yy],A.loc[yy,'Nat'])[0,1]) if v!='Season_T' else 1.0)
R['maize']=dict(cat=mcat,vs_neu=mvs,lowest2000=[(int(k),float(v)) for k,v in low2000.items()][:6],mean2000=float(mz.loc[2000:2023].mean()),
   R2_full=float(R2f),R2_enso=float(R2e),R2_iod=float(R2i),uniq_enso=float(R2f-R2i),uniq_iod=float(R2f-R2e),shared=float(R2e+R2i-R2f),
   beta_oni=float(mz_s.params.oni),beta_dmi=float(mz_s.params.dmi),p_oni=float(mz_s.pvalues.oni),p_dmi=float(mz_s.pvalues.dmi),
   marg_enso=marg_enso,marg_iod=marg_iod,links=lk,r_rain_yield=float(np.corrcoef(A.loc[yy,'Nat'],ma.loc[yy])[0,1]),
   prod2015=float(mz.loc[2015]),prod2023=float(mz.loc[2023]),prod1991=float(mz.loc[1991]),
   anom2015=float(ma.loc[2015]),anom2023=float(ma.loc[2023]),anom1991=float(ma.loc[1991]))
pd.to_pickle(dict(ma=ma,mz=mz,mfit=mfit),'maize_series.pkl')
json.dump(R,open('results_part4.json','w'),indent=1,default=float)
if __name__=='__main__':
    for k,v in mech.items(): print(k,v)
    print(json.dumps({k:v for k,v in R['maize'].items()},default=float)[:3000])
