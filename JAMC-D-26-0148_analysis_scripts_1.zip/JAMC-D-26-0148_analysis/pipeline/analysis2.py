from analysis import *
R=json.load(open('results_part1.json'))
A=D['A']; cols=NRS+['Nat']
def coocc_deficit(t,A,years,cat='EN+pIOD',col='Nat'):
    t=t.loc[list(years)]; A=A.reindex(list(years))
    m=t.cat==cat; neu=t.cat=='Neutral'
    w=welch(A.loc[m.values,col],A.loc[neu.values,col]); w['n_neu']=int(neu.sum()); return w
# --- threshold grid (primary convention)
grid=[]
for te in [0.4,0.5,0.6]:
    for ti in [0.3,0.4,0.5]:
        t=classify('roll',te,ti)
        w1=coocc_deficit(t,A,yrs_st,'EN+pIOD'); w2=coocc_deficit(t,A,yrs_st,'EN only')
        grid.append(dict(te=te,ti=ti,n=w1['na'],d=w1['d'],p=w1['p'],n_neu=w1['n_neu'],n_en=w2['na'],d_en=w2['d'],p_en=w2['p']))
R['thr_grid']=grid
# --- index conventions (Verdon-Kidd style sensitivity)
conv=[]
for c,lab in [('roll','Rolling 30-yr base (CPC ONI convention), primary'),('f8110','Fixed 1981-2010 base, no detrending'),('f9120','Fixed 1991-2020 base, no detrending'),
              ('detr_boxes','Fixed base, linear trend removed from each box'),('detr_index','Fixed base, linear trend removed from index'),('had_roll','HadISST1 DMI, rolling base')]:
    t=classify(c)
    w1=coocc_deficit(t,A,yrs_st,'EN+pIOD'); w2=coocc_deficit(t,A,yrs_st,'EN only'); w3=coocc_deficit(t,A,yrs_st,'LN+nIOD')
    agreeE=float((t.loc[1951:2017,'enso']==T.loc[1951:2017,'enso']).mean()); agreeI=float((t.loc[1951:2017,'iod']==T.loc[1951:2017,'iod']).mean())
    conv.append(dict(conv=c,label=lab,n=w1['na'],d=w1['d'],p=w1['p'],n_en=w2['na'],d_en=w2['d'],p_en=w2['p'],n_lnm=w3['na'],d_lnm=w3['d'],p_lnm=w3['p'],n_neu=w1['n_neu'],agreeE=agreeE,agreeI=agreeI))
# 1-month DMI
for mm,lab in [((9,),'DMI September only'),((10,),'DMI October only'),((11,),'DMI November only'),((8,9,10),'DMI ASO')]:
    t=classify('roll',iodmonths=mm)
    w1=coocc_deficit(t,A,yrs_st,'EN+pIOD'); w2=coocc_deficit(t,A,yrs_st,'EN only')
    conv.append(dict(conv='months'+str(mm),label=lab,n=w1['na'],d=w1['d'],p=w1['p'],n_en=w2['na'],d_en=w2['d'],p_en=w2['p'],n_neu=w1['n_neu'],agreeE=1.0,agreeI=float((t.loc[1951:2017,'iod']==T.loc[1951:2017,'iod']).mean())))
R['conventions']=conv
# baseline: vs all remaining years
t=T.loc[1951:2017]; m=t.cat=='EN+pIOD'
R['enp_vs_rest']=welch(A.loc[1951:2017][m.values]['Nat'],A.loc[1951:2017][~m.values]['Nat'])
# --- tercile classification (Ficchi et al. 2021-style equal-sample)
tt=T.loc[1951:2017].copy()
tt['eT']=pd.qcut(tt.oni,3,labels=['cold','mid','warm']); tt['iT']=pd.qcut(tt.dmi,3,labels=['neg','mid','pos'])
terc={}
for e in ['cold','mid','warm']:
    for i in ['neg','mid','pos']:
        mm=(tt.eT==e)&(tt.iT==i)
        terc[f'{e}|{i}']=dict(n=int(mm.sum()),mean=float(A.loc[tt.index[mm],'Nat'].mean()) if mm.sum() else None,
                             nr={nr:(float(A.loc[tt.index[mm],nr].mean()) if mm.sum() else None) for nr in NRS},years=[int(y) for y in tt.index[mm]])
base=(tt.eT=='mid')&(tt.iT=='mid')
for k in ['warm|pos','warm|mid','warm|neg','cold|neg','cold|mid','mid|pos','mid|neg','cold|pos']:
    e,i=k.split('|'); mm=(tt.eT==e)&(tt.iT==i)
    if mm.sum()>=2: terc[k]['vs_mid']=welch(A.loc[tt.index[mm],'Nat'],A.loc[tt.index[base],'Nat'])
R['terciles']=terc
R['tercile_bounds']=dict(oni=[float(x) for x in tt.oni.quantile([1/3,2/3])],dmi=[float(x) for x in tt.dmi.quantile([1/3,2/3])])
# marginal terciles
R['tercile_marg']={}
for lab,col_,cat in [('warm ONI','eT','warm'),('cold ONI','eT','cold'),('pos DMI','iT','pos'),('neg DMI','iT','neg')]:
    mm=tt[col_]==cat; R['tercile_marg'][lab]=dict(n=int(mm.sum()),**welch(A.loc[tt.index[mm],'Nat'],A.loc[tt.index[~mm],'Nat']))
# --- intensity
t=T.loc[1951:2017]
strong=t.oni>=1.0; mod=(t.oni>=0.5)&(t.oni<1.0)
neu=t.cat=='Neutral'
inten={}
for lab,mm in [('moderate EN only',mod&(t.iod=='N')),('moderate EN+pIOD',mod&(t.iod=='P')),('strong EN only',strong&(t.iod=='N')),('strong EN+pIOD',strong&(t.iod=='P'))]:
    inten[lab]=dict(n=int(mm.sum()),years=[int(y) for y in t.index[mm]],**welch(A.loc[t.index[mm],'Nat'],A.loc[t.index[neu],'Nat']))
R['intensity']=inten
R['oni_by_cat']={c:float(t.loc[t.cat==c,'oni'].mean()) for c in CATS4}
# ONI-matched comparison: regress rain on ONI within El Nino years, test pIOD effect at fixed ONI
en=t[t.enso=='EN'].copy(); en['rain']=A.loc[en.index,'Nat']; en['p']=(en.iod=='P').astype(int)
mE=smf.ols('rain~oni+p',en).fit(); R['en_matched']=dict(b_p=float(mE.params.p),p_p=float(mE.pvalues.p),b_oni=float(mE.params.oni),p_oni=float(mE.pvalues.oni),n=len(en))
mE2=smf.ols('rain~oni+dmi',en).fit(); R['en_matched_cont']=dict(b_dmi=float(mE2.params.dmi),p_dmi=float(mE2.pvalues.dmi),b_oni=float(mE2.params.oni),p_oni=float(mE2.pvalues.oni))
if __name__=='__main__':
    json.dump(R,open('results_part2.json','w'),indent=1,default=float)
    for g in grid: print(g)
    for c in conv: print({k:(round(v,3) if isinstance(v,float) else v) for k,v in c.items()})
    print('vs rest',R['enp_vs_rest'])
    for k,v in terc.items(): print(k,v['n'],None if v['mean'] is None else round(v['mean'],1),v.get('vs_mid'),v['years'])
    print(R['tercile_bounds'],R['tercile_marg'])
    for k,v in inten.items(): print(k,v)
    print(R['oni_by_cat'],R['en_matched'],R['en_matched_cont'])
    