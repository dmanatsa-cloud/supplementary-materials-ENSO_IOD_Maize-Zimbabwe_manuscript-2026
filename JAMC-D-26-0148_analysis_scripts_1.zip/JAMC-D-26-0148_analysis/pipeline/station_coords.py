"""Station coordinates: workbook values, with corrections where the workbook position is inconsistent with the
named station's location (standard gazetteer positions of the towns/research stations)."""
import pandas as pd, geopandas as gpd
from shapely.geometry import Point
from masks import nr_polygons
# MSD station register coordinates (supplied by the authors, Oct 2026) for the 37 archive stations listed in the register.
REG={'Beitbridge':(30.000,-22.217),'Binga':(27.333,-17.617),'Buhera':(31.433,-19.317),'Bulawayo_Goetz':(28.613,-20.144),'Chinhoyi':(30.200,-17.367),
'Chipinge':(32.617,-20.200),'Chivhu':(30.883,-19.033),'Gokwe':(28.922,-18.210),'Marondera':(31.467,-18.183),'Guruve':(30.700,-16.650),'Gweru':(29.850,-19.450),
'Belvedere':(31.017,-17.833),'Kutsaga':(31.133,-17.917),'Harare_Airport':(31.100,-17.933),'Hwange':(27.000,-18.633),'Kadoma':(29.900,-18.320),'Kanyemba':(30.417,-15.633),
'Kariba':(28.883,-16.517),'Karoi':(29.615,-16.831),'Kezi':(28.450,-20.917),'Kwekwe':(29.833,-18.933),'Makoholi':(30.783,-19.833),'Masvingo':(30.867,-20.067),
'Matopos':(28.550,-20.383),'Mounts_Darwin':(31.583,-16.783),'Mutoko':(32.217,-17.417),'Mutare':(32.667,-18.967),'Mvurwi':(30.983,-17.033),'Nkayi':(28.900,-19.000),
'Nyanga':(32.750,-18.283),'Plumtree':(27.800,-20.483),'Rusape':(32.134,-18.538),'Victoria_Falls':(25.850,-18.095),'Wedza':(31.567,-18.617),'West_Nicholson':(29.367,-21.050),
'Zaka':(31.467,-20.333),'Zvishavane':(30.067,-20.317)}
# WMO identifiers from the MSD station register (stations not in the register have none)
WMO={'Beitbridge':67964,'Binga':67755,'Buhera':67885,'Bulawayo_Goetz':67963,'Chinhoyi':67665,'Chipinge':67983,'Chivhu':67879,'Gokwe':67761,
'Marondera':67779,'Guruve':67673,'Gweru':67861,'Belvedere':67775,'Kutsaga':67773,'Harare_Airport':67774,'Hwange':67743,'Kadoma':67765,
'Kanyemba':67571,'Kariba':67651,'Karoi':67663,'Kezi':67953,'Kwekwe':67865,'Makoholi':67875,'Masvingo':67873,'Matopos':67961,
'Mounts_Darwin':67675,'Mutoko':67693,'Mutare':67891,'Mvurwi':67671,'Nkayi':67841,'Nyanga':67793,'Plumtree':67951,'Rusape':67785,
'Victoria_Falls':67741,'Wedza':67781,'West_Nicholson':67957,'Zaka':67883,'Zvishavane':67869}
# MSD national climatological register numbers for stations without a WMO index (supplied by the authors)
MSD_ID={'Chimanimani':'015','Banket':'002','Bikita':'005','Concession':'021','Mvuma':'073','Esigodhini':'025','Lupane':'052','Tsholotsho':'096','Chisumbanje':'019'}
FIX={st:(lo,la,'MSD register') for st,(lo,la) in REG.items()}
FIX['Chisumbanje']=(32.23,-20.80,'not in register; archive latitude 20.48S corrected to the Chisumbanje position')
def stations():
    x=pd.read_excel('/home/claude/data/zim/zimbabwe_natural_region_representative_timeseries_1951_2017_to be used.xlsx',sheet_name='Station_Regions')
    x['lon_wb']=x.Longitude; x['lat_wb']=x.Latitude; x['coord_note']=''
    for st,(lo,la,note) in FIX.items():
        i=x.index[x.Station==st][0]; x.loc[i,['Longitude','Latitude','coord_note']]=[lo,la,note]
    g,d=nr_polygons()
    pts=gpd.GeoDataFrame(x,geometry=[Point(a,b) for a,b in zip(x.Longitude,x.Latitude)],crs='EPSG:4326')
    j=gpd.sjoin(pts,d,how='left',predicate='within')
    for i in j.index[j.NR.isna()]:
        dist=d.geometry.distance(j.loc[i,'geometry']); j.loc[i,'NR']=d.NR.iloc[dist.values.argmin()]
    s=gpd.sjoin(pts,g[['Rev_Region','geometry']],how='left',predicate='within')
    j['subzone']=s.Rev_Region.values
    j=j.rename(columns={'Natural_Region':'NR_msd','NR':'NR_poly'})
    j['WMO_ID']=j.Station.map(WMO).astype('Int64'); j['MSD_ID']=j.Station.map(MSD_ID)
    return pd.DataFrame(j.drop(columns=['geometry','index_right'],errors='ignore'))
if __name__=='__main__':
    s=stations(); print(s[s.NR_msd!=s.NR_poly][['Station','Longitude','Latitude','NR_msd','NR_poly','subzone']].to_string())
    print(s.groupby('NR_poly').size().to_dict(), s.groupby('NR_msd').size().to_dict())
    s.to_csv('stations_table.csv',index=False)
