import xarray as xr, numpy as np, pandas as pd
D='/home/claude/data/idx/'
def knmi_series(path,var):
    ds=xr.open_dataset(path,decode_times=False)
    u=ds.time.attrs['units']; origin=pd.Timestamp(u.split('since')[1].strip()[:10])
    t=pd.DatetimeIndex([pd.Timestamp(origin.year,origin.month,1)+pd.DateOffset(months=int(round(m))) for m in ds.time.values])
    s=pd.Series(ds[var].values.astype(float),index=t)
    return s.where(np.abs(s)<1e10)
def ersst_io_boxes():
    ds=xr.open_dataset(D+'ersstv5_IO.nc',decode_times=False)
    u=ds.time.attrs['units']; origin=pd.Timestamp(u.split('since')[1].strip()[:10])
    t=pd.DatetimeIndex([pd.Timestamp(origin.year,origin.month,1)+pd.DateOffset(months=int(round(m))) for m in ds.time.values])
    sst=ds.sst.assign_coords(time=t)
    sst=sst.where(np.abs(sst)<100)
    def box(la0,la1,lo0,lo1):
        s=sst.sel(lat=slice(min(la0,la1),max(la0,la1))) if sst.lat[0]<sst.lat[-1] else sst.sel(lat=slice(max(la0,la1),min(la0,la1)))
        s=s.sel(lon=slice(lo0,lo1))
        w=np.cos(np.deg2rad(s.lat))
        return s.weighted(w).mean(('lat','lon')).to_series()
    return pd.DataFrame({'wtio':box(-10,10,50,70),'setio':box(-10,0,90,110)}), sst
