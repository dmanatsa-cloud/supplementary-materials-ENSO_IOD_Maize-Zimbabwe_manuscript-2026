import xarray as xr, numpy as np, pandas as pd
from masks import nr_means
F='/home/claude/data/grid/v2p0chirps_25_25-34E_-15--23N_firstyear-lastyear.nc'
def load():
    ds=xr.open_dataset(F,decode_times=False)
    t=pd.Timestamp('1981-01-01')+pd.to_timedelta(ds.time.values,unit='D')
    p=ds.precip.assign_coords(time=t)
    return p.where(p>=0)
if __name__=='__main__':
    p=load(); print(p.time.values[[0,-1]], p.shape, float(p.lat.min()),float(p.lat.max()),float(p.lon.min()),float(p.lon.max()))
    out,m=nr_means(p)
    print('cells per NR', [int((m==k).sum()) for k in range(5)])
    df=pd.DataFrame({k:v.to_series() for k,v in out.items()})
    df.to_pickle('chirps_daily_nr.pkl'); print(df.tail(3))
