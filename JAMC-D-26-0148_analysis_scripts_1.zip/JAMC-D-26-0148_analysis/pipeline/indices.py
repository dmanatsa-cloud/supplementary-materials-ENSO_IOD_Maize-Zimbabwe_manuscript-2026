"""Build ENSO and IOD indices from ERSSTv5 with documented conventions."""
from load_idx import *
def block_base(y, first_year_available=1854):
    """CPC ONI convention: centred 30-yr base for 5-yr blocks; latest = 1991-2020 from 2011."""
    if y<=1955: b=(1936,1965)
    elif y>=2011: b=(1991,2020)
    else:
        k=(y-1956)//5; start=1956+5*k; b=(start-15,start+14)
    if b[0]<first_year_available: b=(first_year_available, first_year_available+29)
    return b
def rolling_anom(a, first_year_available):
    a=a.copy(); out=pd.Series(np.nan,index=a.index)
    for y in sorted(set(a.index.year)):
        b0,b1=block_base(y,first_year_available)
        m=(a.index.year>=b0)&(a.index.year<=b1)
        clim=a[m].groupby(a[m].index.month).mean()
        sel=a.index.year==y
        out[sel]=a[sel].values-clim.reindex(a[sel].index.month).values
    return out
def fixed_anom(s,b0,b1):
    m=(s.index.year>=b0)&(s.index.year<=b1)
    clim=s[m].groupby(s[m].index.month).mean()
    return s-clim.reindex(s.index.month).values
def lin_detrend(s,y0=1950,y1=2025):
    s=s[str(y0):str(y1)].copy(); t=np.arange(len(s)); ok=s.notna().values
    p=np.polyfit(t[ok],s.values[ok],1); return s-np.polyval(p,t)
def build():
    n=knmi_series(D+'iersst_nino34a.nc','Nino3.4')          # ERSSTv5 anomalies wrt 1981-2010 (KNMI)
    b,_=ersst_io_boxes()                                     # ERSSTv5 absolute SST, 1950-2026
    h=knmi_series(D+'ihadisst1_dmi.nc','diff')               # HadISST1 DMI (KNMI)
    I={}
    # primary: CPC rolling-base convention
    I['n34_roll']=rolling_anom(n,1854)
    I['wtio_roll']=rolling_anom(b.wtio,1950); I['setio_roll']=rolling_anom(b.setio,1950)
    I['dmi_roll']=I['wtio_roll']-I['setio_roll']
    # alternatives
    I['n34_8110']=fixed_anom(n,1981,2010); I['dmi_8110']=fixed_anom(b.wtio,1981,2010)-fixed_anom(b.setio,1981,2010)
    I['n34_9120']=fixed_anom(n,1991,2020); I['dmi_9120']=fixed_anom(b.wtio,1991,2020)-fixed_anom(b.setio,1991,2020)
    I['n34_detr']=lin_detrend(fixed_anom(n,1981,2010)); 
    I['dmi_detr_boxes']=lin_detrend(fixed_anom(b.wtio,1981,2010))-lin_detrend(fixed_anom(b.setio,1981,2010))
    I['dmi_detr_index']=lin_detrend(I['dmi_8110'])
    I['dmi_had_roll']=rolling_anom(h['1950':],1950)
    df=pd.DataFrame(I)['1950':'2026-07']
    return df
def seas(s,y,months):
    idx=[pd.Timestamp(y+(1 if m<7 else 0),m,1) for m in months]
    return s.reindex(idx).mean()
def seasonal_table(df, years, n34col='n34_roll', dmicol='dmi_roll', te=0.5, ti=0.4, ensomonths=(12,1,2), iodmonths=(9,10,11)):
    rows=[]
    for y in years:
        e=seas(df[n34col],y,ensomonths); i=seas(df[dmicol],y,iodmonths)
        rows.append(dict(year=y,oni=e,dmi=i,enso='EN' if e>=te else ('LN' if e<=-te else 'N'),
                         iod='P' if i>=ti else ('M' if i<=-ti else 'N')))
    t=pd.DataFrame(rows).set_index('year')
    def cat(r):
        return {('EN','N'):'EN only',('LN','N'):'LN only',('N','P'):'pIOD only',('N','M'):'nIOD only',
                ('EN','P'):'EN+pIOD',('EN','M'):'EN+nIOD',('LN','P'):'LN+pIOD',('LN','M'):'LN+nIOD',('N','N'):'Neutral'}[(r.enso,r.iod)]
    t['cat']=t.apply(cat,axis=1)
    return t
if __name__=='__main__':
    df=build(); df.to_csv('indices_monthly_built.csv')
    t=seasonal_table(df,range(1950,2025)); t.to_csv('season_class_primary.csv')
    from table1 import T1, T1ext
    mapE={'EN':'EN','LN':'LN','0':'N'}; mapI={'P':'P','N':'M','0':'N'}
    print('Changes vs submitted Table 1 (1951-2017) and extension (2018-2024):')
    for y in range(1951,2025):
        old=T1ext[y]; o=(mapE[old[0]],mapI[old[1]])
        new=(t.loc[y,'enso'],t.loc[y,'iod'])
        if o!=new: print(y,'old',o,'new',new,'ONI %.2f DMI %.2f'%(t.loc[y,'oni'],t.loc[y,'dmi']))
    print(t.loc[1951:2017,'cat'].value_counts()); print(t.loc[1951:2024,'cat'].value_counts())
    print('corr ONI-DMI 1951-2017', t.loc[1951:2017,['oni','dmi']].corr().iloc[0,1])
