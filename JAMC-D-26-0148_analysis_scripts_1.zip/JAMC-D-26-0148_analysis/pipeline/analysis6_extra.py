"""Additional diagnostics added during revision: NR V gap sensitivity, sub-period composites and regressions,
DMI drift under a fixed base, driest station seasons, SPEI-6 vs station r for NR V. Writes results_extra.json."""
import json, numpy as np, pandas as pd
import statsmodels.api as sm
from indices import seasonal_table
from scipy import stats
D = pd.read_pickle('cache_data.pkl'); A = D['A']
T = pd.read_csv('season_class_primary.csv', index_col=0)
def comp(a):
    t = T.loc[a.index]; neu = a[t.cat == 'Neutral']; out = {}
    for c in ['EN+pIOD', 'EN only', 'LN only', 'LN+nIOD']:
        x = a[t.cat == c]
        out[c] = [int(len(x)), round(float(x.mean() - neu.mean()), 1), round(float(stats.ttest_ind(x, neu, equal_var=False).pvalue), 4) if len(x) > 1 else None]
    return out, int(len(neu)), round(float(neu.mean()), 1)
X = {}
X['nat_1959'] = comp(A['Nat'].loc[1959:2017])[0]
X['nat_NRI_IV'] = comp(A[['I', 'II', 'III', 'IV']].mean(axis=1).loc[1951:2017])[0]
X['nrv_missing'] = '1951-1958'
X['subperiod_comp'] = {}
for lo, hi in [(1951, 1982), (1983, 2017)]:
    c, nn, nm = comp(A['Nat'].loc[lo:hi]); c.update(neu_n=nn, neu_mean=nm); X['subperiod_comp'][f'{lo}-{hi}'] = c
X['subperiod_regress'] = {}
for lo, hi in [(1951, 1982), (1983, 2017), (1951, 2017)]:
    y = A['Nat'].loc[lo:hi]; Xm = T.loc[y.index, ['oni', 'dmi']]
    m = sm.OLS((y - y.mean()) / y.std(), sm.add_constant((Xm - Xm.mean()) / Xm.std())).fit()
    X['subperiod_regress'][f'{lo}-{hi}'] = dict(beta_oni=m.params['oni'], p_oni=m.pvalues['oni'], beta_dmi=m.params['dmi'], p_dmi=m.pvalues['dmi'], r2=m.rsquared)
idx = pd.read_csv('indices_monthly_built.csv', index_col=0, parse_dates=True)
def son(col):
    s = idx[col]; k = s.index.month.isin([9, 10, 11]); return s[k].groupby(s[k].index.year).mean().loc[1951:2024]
f, r = son('dmi_8110'), son('dmi_roll'); lf, lr = stats.linregress(f.index, f.values), stats.linregress(r.index, r.values)
n = idx['n34_8110']; k = n.index.month.isin([12, 1, 2])
X['dmi_trend'] = dict(fixed8110_per_decade=round(lf.slope * 10, 3), fixed8110_p=round(lf.pvalue, 3), fixed_mean_1951_1980=round(f.loc[1951:1980].mean(), 2),
                      fixed_mean_1995_2024=round(f.loc[1995:2024].mean(), 2), roll_per_decade=round(lr.slope * 10, 3), roll_p=round(lr.pvalue, 2),
                      n34_fixed_mean_1951_1980=round(float(seasonal_table(idx, range(1951, 1981), 'n34_8110', 'dmi_8110').oni.mean()), 2))
dr = A['Nat'].loc[1951:2017].sort_values().head(10)
X['driest_station'] = [[int(y), round(float(v), 1), T.loc[y, 'cat']] for y, v in dr.items()]
sp = D['spei']; c = pd.concat([sp['V'], A['V']], axis=1).dropna(); X['spei_r_NRV'] = float(c.corr().iloc[0, 1])
json.dump(X, open('results_extra.json', 'w'), indent=1, default=float); print(json.dumps(X['dmi_trend']), X['subperiod_comp']['1983-2017']['EN only'])
