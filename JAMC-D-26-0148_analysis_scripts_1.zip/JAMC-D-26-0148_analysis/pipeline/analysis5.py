from analysis4 import *
R=json.load(open('results_part4.json'))
d=D['chd']   # daily CHIRPS NR means
def onset_cess(s,y):
    """Onset (MSD definition): first day from 1 Oct with >=20 mm in 1-3 days, not followed by a >=10-day dry spell (<1 mm) in the next 30 days.
       Max dry spell (consecutive days <1 mm) within Dec and within Feb."""
    ss=s[f'{y}-10-01':f'{y+1}-04-30']; v=ss.values; dates=ss.index
    on=np.nan
    for i in range(len(v)-33):
        if dates[i].month in (4,): break
        if v[i:i+3].sum()>=20:
            nxt=v[i+3:i+33]; run=0; bad=False
            for x in nxt:
                run=run+1 if x<1 else 0
                if run>=10: bad=True; break
            if not bad: on=(dates[i]-pd.Timestamp(y,7,1)).days+1; break
    def maxdry(mm,yy):
        x=s[f'{yy}-{mm:02d}-01':f'{yy}-{mm:02d}-{pd.Timestamp(yy,mm,1).days_in_month}'].values; best=run=0
        for q_ in x:
            run=run+1 if q_<1 else 0; best=max(best,run)
        return best
    return on, maxdry(12,y), maxdry(2,y+1)
rows=[]
for y in range(1981,2025):
    for c in ['Nat']+NRS:
        o,dd,fd=onset_cess(d[c],y); rows.append(dict(year=y,reg=c,onset=o,dec_dry=dd,feb_dry=fd))
DD=pd.DataFrame(rows)
nat=DD[DD.reg=='Nat'].set_index('year')
P2=nat.join(T[['oni','dmi','cat']])
P2['maize']=pd.read_pickle('maize_series.pkl')['ma']
def pc(y,x,z,df):
    dd=df[[y,x,z]].dropna(); rx=sm.OLS(dd[x],sm.add_constant(dd[z])).fit().resid; ry=sm.OLS(dd[y],sm.add_constant(dd[z])).fit().resid
    r,p=stats.pearsonr(rx,ry); return dict(r=float(r),p=float(p),n=len(dd))
daily={v:dict(iod=pc(v,'dmi','oni',P2),enso=pc(v,'oni','dmi',P2)) for v in ['onset','dec_dry','feb_dry']}
daily['maize_links']={v:dict(r=float(P2[[v,'maize']].dropna().corr().iloc[0,1]),p=float(stats.pearsonr(*P2[[v,'maize']].dropna().values.T)[1]),n=int(P2[[v,'maize']].dropna().shape[0])) for v in ['onset','dec_dry','feb_dry']}
daily['onset_comp']=cat_vs_neutral(nat.onset,T,range(1981,2025),['EN+pIOD','EN only','LN+nIOD','LN only'])
daily['onset_clim']=float(nat.onset.mean()); daily['onset_missing']=int(nat.onset.isna().sum())
daily['r_onset_station']=float(np.corrcoef(nat.onset.loc[1981:2017],D['T']['SOS']['Nat'].loc[1981:2017])[0,1])
R['daily']=daily
# monthly evolution (CHIRPS NR polygons), Oct-Mar, % anomaly vs monthly climatology 1981-2024
mon=D['chm']
mres={}
for c_ in ['EN+pIOD','EN only','LN+nIOD','LN only','Neutral']:
    yrs_c=[y for y in range(1981,2025) if T.loc[y,'cat']==c_]
    mres[c_]={}
    for reg in NRS+['Nat']:
        vals=[]
        for mth in [10,11,12,1,2,3]:
            clim=np.mean([mon.loc[pd.Timestamp(y+(1 if mth<7 else 0),mth,1),reg] for y in range(1981,2025)])
            comp=np.mean([mon.loc[pd.Timestamp(y+(1 if mth<7 else 0),mth,1),reg] for y in yrs_c])
            vals.append(float((comp/clim-1)*100))
        mres[c_][reg]=vals
    mres[c_]['n']=len(yrs_c)
# OND and JFM totals tests (national) EN+pIOD vs neutral and EN only vs neutral
def part_season(months,reg='Nat'):
    out={}
    for y in range(1981,2025):
        out[y]=sum(mon.loc[pd.Timestamp(y+(1 if m<7 else 0),m,1),reg] for m in months)
    s=pd.Series(out); return (s/s.mean()-1)*100
for nm,ms in [('OND',[10,11,12]),('JFM',[1,2,3])]:
    s=part_season(ms); mres[nm+'_tests']={c:cat_vs_neutral(s,T,range(1981,2025),[c])[c] for c in ['EN+pIOD','EN only','LN+nIOD','LN only']}
R['monthly']=mres
json.dump(R,open('results_final.json','w'),indent=1,default=float)
DD.to_csv('chirps_daily_metrics.csv',index=False)
if __name__=='__main__':
    print(json.dumps(daily,indent=0,default=float)[:2500])
    for c_,v in mres.items():
        if isinstance(v,dict) and 'Nat' in v: print(c_,v['n'],[round(x) for x in v['Nat']],'NR I',[round(x) for x in v['I']])
    print(mres['OND_tests'],mres['JFM_tests'])
