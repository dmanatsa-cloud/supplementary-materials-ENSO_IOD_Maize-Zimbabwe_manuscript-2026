import pandas as pd, numpy as np, json, warnings, itertools
from scipy import stats
import statsmodels.api as sm
import statsmodels.formula.api as smf
from statsmodels.stats.multitest import multipletests
from statsmodels.stats.multicomp import pairwise_tukeyhsd
warnings.filterwarnings('ignore')
from indices import build, seasonal_table, seas
from stations import NRS
rng=np.random.default_rng(2026)
D=pd.read_pickle('cache_data.pkl')
IDX=build()
CATS4=['LN+nIOD','LN only','EN only','EN+pIOD']
def classify(conv='roll',te=0.5,ti=0.4,iodmonths=(9,10,11),years=range(1950,2026)):
    cols={'roll':('n34_roll','dmi_roll'),'f8110':('n34_8110','dmi_8110'),'f9120':('n34_9120','dmi_9120'),
          'detr_boxes':('n34_detr','dmi_detr_boxes'),'detr_index':('n34_detr','dmi_detr_index'),'had_roll':('n34_roll','dmi_had_roll')}[conv]
    return seasonal_table(IDX,years,cols[0],cols[1],te,ti,iodmonths=iodmonths)
T=classify()
def clean(x): x=np.asarray(x,float); return x[~np.isnan(x)]
def welch(a,b):
    a=clean(a); b=clean(b)
    if len(a)<2 or len(b)<2: return dict(d=float(np.mean(a)-np.mean(b)) if len(a) and len(b) else np.nan,p=np.nan,na=len(a),nb=len(b))
    t,p=stats.ttest_ind(a,b,equal_var=False); return dict(d=float(a.mean()-b.mean()),p=float(p),na=len(a),nb=len(b))
def boot(a,b,n=10000):
    a=clean(a); b=clean(b)
    ia=rng.integers(0,len(a),(n,len(a))); ib=rng.integers(0,len(b),(n,len(b)))
    d=a[ia].mean(1)-b[ib].mean(1); return [float(x) for x in np.percentile(d,[2.5,97.5])]
def cohen_d(a,b):
    a=clean(a); b=clean(b); s=np.sqrt(((len(a)-1)*a.var(ddof=1)+(len(b)-1)*b.var(ddof=1))/(len(a)+len(b)-2)); return float((a.mean()-b.mean())/s)
def composites(A,t,years,cols):
    t=t.loc[list(years)]; A=A.reindex(list(years))
    out={}
    for nm,mask in [('EN',t.enso=='EN'),('LN',t.enso=='LN'),('pIOD',t.iod=='P'),('nIOD',t.iod=='M')]:
        out[nm]={c:welch(A.loc[mask,c],A.loc[~mask,c]) for c in cols}; out[nm]['n']=int(mask.sum())
    neu=t.cat=='Neutral'
    for cname in CATS4+['pIOD only','nIOD only','EN+nIOD','LN+pIOD']:
        m=t.cat==cname
        if m.sum()==0: continue
        out[cname]={c:welch(A.loc[m,c],A.loc[neu,c]) for c in cols}; out[cname]['n']=int(m.sum())
        out[cname]['mean_abs']={c:float(A.loc[m,c].mean()) for c in cols}
    out['Neutral']={'n':int(neu.sum()),'mean_abs':{c:float(A.loc[neu,c].mean()) for c in cols}}
    return out
R={}
# ---------------- 1. chronology
yrs_st=range(1951,2018); yrs_ch=range(1981,2025)
R['chron']={'counts_51_17':T.loc[1951:2017,'cat'].value_counts().to_dict(),'counts_81_24':T.loc[1981:2024,'cat'].value_counts().to_dict(),
  'counts_51_24':T.loc[1951:2024,'cat'].value_counts().to_dict(),
  'nEN':int((T.loc[1951:2017,'enso']=='EN').sum()),'nLN':int((T.loc[1951:2017,'enso']=='LN').sum()),
  'nP':int((T.loc[1951:2017,'iod']=='P').sum()),'nM':int((T.loc[1951:2017,'iod']=='M').sum()),
  'P_given_EN':int(((T.enso=='EN')&(T.iod=='P')).loc[1951:2017].sum()),'M_given_LN':int(((T.enso=='LN')&(T.iod=='M')).loc[1951:2017].sum()),
  'r_oni_dmi':float(T.loc[1951:2017,['oni','dmi']].corr().iloc[0,1]),
  'years':{c:[int(y) for y in T.index[(T.cat==c)&(T.index>=1951)&(T.index<=2024)]] for c in T.cat.unique()}}
# ---------------- 2. station composites, NR and national
A=D['A']; cols=NRS+['Nat']
R['st']=composites(A,T,yrs_st,cols)
# bootstrap CIs for co-occurrence vs neutral
neu=T.loc[1951:2017].cat=='Neutral'
R['st_boot']={}
for cname in CATS4:
    m=T.loc[1951:2017].cat==cname
    R['st_boot'][cname]={c:boot(A.loc[1951:2017][m.values][c],A.loc[1951:2017][neu.values][c]) for c in cols}
# FDR over 5 NR x 4 categories
ps=[];keys=[]
for cname in CATS4:
    for nr in NRS: ps.append(R['st'][cname][nr]['p']); keys.append((cname,nr))
rej,q,_,_=multipletests(ps,method='fdr_bh')
R['st_fdr']={f'{k[0]}|{k[1]}':dict(p=float(p),q=float(qq),sig=bool(r)) for k,p,qq,r in zip(keys,ps,q,rej)}
# ANOVA + Tukey on national
sub=T.loc[1951:2017]; sub=sub[sub.cat.isin(CATS4)]
groups=[A.loc[sub.index[sub.cat==c],'Nat'].values for c in CATS4]
F,pA=stats.f_oneway(*groups); R['anova']=dict(F=float(F),p=float(pA))
tk=pairwise_tukeyhsd(A.loc[sub.index,'Nat'].values,sub.cat.values)
R['tukey']=[dict(g1=str(r[0]),g2=str(r[1]),diff=float(r[2]),p=float(r[3])) for r in tk.summary().data[1:]]
# continuous-index regression with interaction (national, 1951-2017)
X=pd.DataFrame({'rain':A.loc[1951:2017,'Nat'],'oni':T.loc[1951:2017,'oni'],'dmi':T.loc[1951:2017,'dmi']})
m0=smf.ols('rain~oni+dmi',X).fit(); m1=smf.ols('rain~oni+dmi+oni:dmi',X).fit()
Fi=((m0.ssr-m1.ssr)/1)/(m1.ssr/m1.df_resid); pFi=1-stats.f.cdf(Fi,1,m1.df_resid)
Xs=(X-X.mean())/X.std(); ms=smf.ols('rain~oni+dmi',Xs).fit()
R['regress']=dict(b_oni=float(m0.params.oni),p_oni=float(m0.pvalues.oni),b_dmi=float(m0.params.dmi),p_dmi=float(m0.pvalues.dmi),r2=float(m0.rsquared),
   b_int=float(m1.params['oni:dmi']),p_int=float(m1.pvalues['oni:dmi']),F_int=float(Fi),pF_int=float(pFi),
   beta_oni=float(ms.params.oni),beta_dmi=float(ms.params.dmi),
   pr_oni=float(stats.pearsonr(sm.OLS(X.rain,sm.add_constant(X.dmi)).fit().resid, sm.OLS(X.oni,sm.add_constant(X.dmi)).fit().resid)[0]),
   pr_dmi=float(stats.pearsonr(sm.OLS(X.rain,sm.add_constant(X.oni)).fit().resid, sm.OLS(X.dmi,sm.add_constant(X.oni)).fit().resid)[0]),
   r_oni=float(X.rain.corr(X.oni)),r_dmi=float(X.rain.corr(X.dmi)))
# additive prediction for EN+pIOD: compare observed composite with additive model prediction at category-mean indices
cm=X.join(T.loc[1951:2017,'cat']).groupby('cat')[['oni','dmi','rain']].mean()
R['additive_check']={c:dict(obs=float(cm.loc[c,'rain']),pred=float(m0.predict(cm.loc[[c],['oni','dmi']]).iloc[0]),oni=float(cm.loc[c,'oni']),dmi=float(cm.loc[c,'dmi'])) for c in CATS4+['Neutral']}
# NR sensitivity vs climatological rainfall
clim=D['R'].loc[1951:2017].mean()
R['nr_clim']={nr:float(clim[nr]) for nr in NRS}
for k in ['EN','pIOD','EN+pIOD']:
    rho,p=stats.spearmanr([clim[n] for n in NRS],[R['st'][k][n]['d'] for n in NRS]); R.setdefault('spearman',{})[k]=dict(rho=float(rho),p=float(p))
if __name__=='__main__':
    json.dump(R,open('results_part1.json','w'),indent=1,default=float)
    print(json.dumps({k:R[k] for k in ['chron','anova','regress','spearman']},indent=0,default=float)[:4000])
    for cname in ['EN','LN','pIOD','nIOD']+CATS4:
        v=R['st'][cname]; print(f"{cname:9s} n={v['n']:2d} "+' '.join(f"{c}:{v[c]['d']:+6.1f}({v[c]['p']:.3f})" for c in cols))
    print({k:[round(x,1) for x in v['Nat']] for k,v in R['st_boot'].items()})
    print({k:(round(v['q'],3),v['sig']) for k,v in R['st_fdr'].items()})
    print(R['tukey']); print(R['additive_check'])
    