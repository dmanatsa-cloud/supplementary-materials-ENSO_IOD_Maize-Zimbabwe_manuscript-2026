"""Station-choice sensitivity of the national co-occurrence composites -> results_station_sens.json"""
import json, numpy as np, pandas as pd
from scipy import stats
from stations import load_raw, representative, pct_anom, NRS
T = pd.read_csv('season_class_primary.csv', index_col=0)
def nat_from(q):
    R_, C_ = representative(q, 'Season_T'); A_ = pct_anom(R_); A_['Nat'] = A_[NRS].mean(axis=1); return A_, C_
def comp(a):
    a = a.dropna(); t = T.loc[a.index]; neu = a[t.cat == 'Neutral']; out = {}
    for c, k in [('EN+pIOD', 'enp'), ('EN only', 'en'), ('LN+nIOD', 'lnm')]:
        x = a[t.cat == c]; out[k] = float(x.mean() - neu.mean()); out[k + '_p'] = float(stats.ttest_ind(x, neu, equal_var=False).pvalue); out['n_' + k] = int(len(x))
    return out
S = {}
q = pd.read_pickle('station_qc.pkl'); A, C = nat_from(q)
S['polygon membership (primary)'] = comp(A['Nat'].loc[1951:2017])
S['msd membership'] = comp(nat_from(pd.read_pickle('station_qc_msd.pkl'))[0]['Nat'].loc[1951:2017])
raw, _ = load_raw('poly'); S['no QC (poly)'] = comp(nat_from(raw)[0]['Nat'].loc[1951:2017])
A2 = A[NRS].where(C[NRS] >= 2); S['exclude <2-station region-years'] = comp(A2.mean(axis=1).loc[1951:2017])
S['lowcov_count'] = int((C[NRS] < 2).sum().sum()); S['lowcov_by_nr'] = {k: int(v) for k, v in (C[NRS] < 2).sum().items()}
c83 = comp(A['Nat'].loc[1983:2017]); c83['n'] = c83['n_enp']; c83['nen'] = c83['n_en']; S['1983-2017 only'] = c83
json.dump(S, open('results_station_sens.json', 'w'), indent=1)
print(json.dumps({k: {kk: round(vv, 3) for kk, vv in v.items()} if isinstance(v, dict) and k != 'lowcov_by_nr' else v for k, v in S.items()}, indent=0))
