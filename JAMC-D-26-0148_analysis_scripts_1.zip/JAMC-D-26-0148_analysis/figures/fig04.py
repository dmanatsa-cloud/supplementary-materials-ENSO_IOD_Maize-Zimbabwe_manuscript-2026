from figstyle import *
import json, numpy as np, pandas as pd
from analysis import T, D
R=json.load(open('results_final.json'))
rng=np.random.default_rng(1)
A=D['A']; CA=D['chA']; sp=D['spei']
fig,axs=plt.subplots(2,2,figsize=(7.4,5.6),gridspec_kw=dict(width_ratios=[1,1.35]))
cats=ORDER4
ax=axs[0,0]
v=[R['st'][c]['Nat']['d'] for c in cats]; ci=np.array([R['st_boot'][c]['Nat'] for c in cats])
ax.bar(range(4),v,color=[CAT_COL[c] for c in cats],width=0.65)
ax.errorbar(range(4),v,yerr=[np.array(v)-ci[:,0],ci[:,1]-np.array(v)],fmt='none',ecolor=INK2,elinewidth=0.7,capsize=2)
for i,c in enumerate(cats):
    p=R['st'][c]['Nat']['p']; yy=ci[i,1]+2 if v[i]>0 else ci[i,0]-2
    ax.text(i,yy,f"{v[i]:+.0f}%\np = {p:.3f}" if p>=0.001 else f"{v[i]:+.0f}%\np < 0.001",ha='center',va='bottom' if v[i]>0 else 'top',fontsize=6.2,color=INK)
zero(ax); ax.set_xticks(range(4)); ax.set_xticklabels([LAB[c]+f"\n(n={R['st'][c]['n']})" for c in cats],fontsize=6.3)
ax.set_ylabel('National rainfall vs neutral (%)'); ax.set_ylim(-48,45)
panel(ax,'a','National rainfall, 1951–2017')
ax=axs[1,0]
yrs=[y for y in range(1951,2018)]
vals=[];cis=[]
for c in cats+['Neutral']:
    x=sp.loc[[y for y in yrs if T.loc[y,'cat']==c],'Nat'].values; vals.append(x.mean())
    bs=[rng.choice(x,len(x)).mean() for _ in range(5000)]; cis.append(np.percentile(bs,[2.5,97.5]))
cis=np.array(cis); order=cats+['Neutral']
ax.bar(range(5),vals,color=[CAT_COL[c] for c in order],width=0.65)
ax.errorbar(range(5),vals,yerr=[np.array(vals)-cis[:,0],cis[:,1]-np.array(vals)],fmt='none',ecolor=INK2,elinewidth=0.7,capsize=2)
for i,c in enumerate(order): ax.text(i,(cis[i,1]+0.06) if vals[i]>0 else (cis[i,0]-0.06),f'{vals[i]:+.2f}',ha='center',va='bottom' if vals[i]>0 else 'top',fontsize=6.3)
ax.axhline(-1,color=MUTE,lw=0.6,ls='--'); ax.text(4.45,-1.04,'moderate\ndrought',fontsize=5.8,color=INK2,va='top',ha='right')
zero(ax); ax.set_xticks(range(5)); ax.set_xticklabels([LAB[c] for c in order],fontsize=6.3); ax.set_ylabel('March SPEI-6 (national mean)'); ax.set_ylim(-1.75,1.5)
panel(ax,'c','SPEI-6 (ERA5-based), 1951–2017')
ax=axs[0,1]
st=(A.loc[1951:2017,'Nat']); ch=CA.loc[1981:2024,'Nat']
ax.plot(st.index,st.values,color=INK,lw=1.0,label='MSD stations (1951–2017)')
ax.plot(ch.index,ch.values,color=DS2,lw=1.0,ls='--',label='CHIRPS v2.0 (1981–2024)')
for y in range(1951,2025):
    c=T.loc[y,'cat']
    if c in ('EN+pIOD','LN+nIOD'): ax.axvspan(y-0.5,y+0.5,color=CAT_COL[c],alpha=0.18,lw=0)
for y in [1991,1982,1994,2015,2023]:
    val=st.get(y,ch.get(y)) if y<=2017 else ch.get(y)
    ax.annotate(f'{y}/{str(y+1)[2:]}',(y,val),xytext=(0,-9),textcoords='offset points',ha='center',fontsize=5.8,color=INK2)
zero(ax); ax.set_ylabel('National rainfall anomaly (%)'); ax.set_xlim(1950,2025)
from matplotlib.patches import Patch
h,l=ax.get_legend_handles_labels(); h+= [Patch(color=CAT_COL['EN+pIOD'],alpha=0.3),Patch(color=CAT_COL['LN+nIOD'],alpha=0.3)]; l+=['El Niño & +IOD seasons','La Niña & −IOD seasons']
ax.legend(h,l,fontsize=6.0,loc='upper right',ncol=2)
ax.set_ylim(-55,80)
panel(ax,'b','National ONDJFM rainfall, by onset year')
ax=axs[1,1]
sl=R['nonstat']['sliding']; ys=np.array([int(k) for k in sl]); rs=np.array([sl[k] for k in sl])
ax.plot(ys+9.5,rs,color=INK,lw=1.2)
ax.axhline(-0.444,color=MUTE,lw=0.6,ls='--'); ax.text(1962,-0.47,'p = 0.05 (n = 20)',fontsize=6,color=INK2,va='top')
zero(ax); ax.set_xlabel('Centre of 20-season window'); ax.set_ylabel('r (DJF ONI, national rainfall)'); ax.set_ylim(-0.85,0.15)
panel(ax,'d','Sliding 20-season ENSO–rainfall correlation')
fig.tight_layout(h_pad=1.2,w_pad=1.2); save(fig,'Fig04_national')
