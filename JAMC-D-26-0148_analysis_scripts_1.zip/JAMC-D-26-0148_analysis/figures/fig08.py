from figstyle import *
import json, numpy as np
R=json.load(open('results_final.json'))
NR=['I','II','III','IV','V','Nat']; cats=ORDER4; x=np.arange(6); w=0.19
fig,axs=plt.subplots(2,1,figsize=(7.4,4.8),sharex=True)
for ax,key,lab,letter,title in [(axs[0],'sm','Soil moisture, top layer (kg m⁻²)','a','ERA5-Land DJF top-layer soil moisture vs neutral, 1951–2024'),
                                (axs[1],'stress','PET − ET (mm d⁻¹)','b','ERA5 DJF evaporative stress (potential minus actual evaporation) vs neutral')]:
    for i,c in enumerate(cats):
        v=[R['land'][key][n][c]['d'] for n in NR]; p=[R['land'][key][n][c]['p'] for n in NR]
        xx=x+(i-1.5)*w
        ax.bar(xx,v,w*0.9,color=CAT_COL[c],label=f"{LAB1[c]} (n = {R['land']['counts'][c]})")
        for j in range(6):
            if p[j]<0.05: ax.text(xx[j],v[j]+(0.12 if v[j]>0 else -0.12)*(1 if key=='sm' else 0.25),'*',ha='center',va='bottom' if v[j]>0 else 'top',fontsize=7.5)
    zero(ax); ax.set_ylabel(lab); panel(ax,letter,title)
axs[0].legend(ncol=4,fontsize=6.3,loc='upper center',bbox_to_anchor=(0.5,1.0))
axs[0].set_ylim(-6.5,8.5); axs[1].set_ylim(-1.6,1.6)
axs[1].set_xticks(x); axs[1].set_xticklabels([f'NR {n}' if n!='Nat' else 'National' for n in NR])
axs[1].text(0.995,0.03,'* p < 0.05 (Welch); fields linearly detrended',transform=axs[1].transAxes,ha='right',fontsize=6,color=INK2)
fig.tight_layout(h_pad=0.8); save(fig,'Fig08_land_surface')
