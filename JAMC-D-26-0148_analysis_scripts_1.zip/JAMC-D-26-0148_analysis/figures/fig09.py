from figstyle import *
import json, numpy as np
R=json.load(open('results_final.json'))
fig,axs=plt.subplots(1,3,figsize=(7.4,2.9),gridspec_kw=dict(width_ratios=[1.35,0.9,1.1]))
ax=axs[0]
pars=['SOS','OND_LODS','Dec_LODS','Season_T','JF_LODS','Feb_LODS','LOS']; flip={'Season_T':-1,'LOS':-1}
labs=['Onset (SOS)','OND dry spell','Dec dry spell','Seasonal total','JF dry spell','Feb dry spell','Season length']
x=np.arange(len(pars)); w=0.38
iod=[R['pcor'][p]['iod']['r']*flip.get(p,1) for p in pars]; ens=[R['pcor'][p]['enso']['r']*flip.get(p,1) for p in pars]
pi=[R['pcor'][p]['iod']['p'] for p in pars]; pe=[R['pcor'][p]['enso']['p'] for p in pars]
ax.bar(x-w/2,iod,w*0.92,color=DS2,label='SON DMI | DJF ONI'); ax.bar(x+w/2,ens,w*0.92,color=DS1,label='DJF ONI | SON DMI')
for i in range(len(pars)):
    if pi[i]<0.05: ax.text(x[i]-w/2,iod[i]+0.01,'*',ha='center',fontsize=8)
    if pe[i]<0.05: ax.text(x[i]+w/2,ens[i]+0.01,'*',ha='center',fontsize=8)
zero(ax); ax.set_xticks(x); ax.set_xticklabels(labs,fontsize=6.2,rotation=35,ha='right',rotation_mode='anchor'); ax.set_ylabel('Partial r (positive = drier or later)'); ax.legend(fontsize=6,loc='upper left'); ax.set_ylim(-0.05,0.48)
panel(ax,'a','Which driver tracks which parameter')
ax=axs[1]
ms=['Sep','Oct','Nov','Dec','Jan','Feb','Mar']; sd=R['seasonality']['mon_sd']
ax.plot(ms,[sd[m]['dmi'] for m in ms],'-o',color=DS2,ms=4,lw=1.4,label='DMI')
ax.plot(ms,[sd[m]['n34'] for m in ms],'-s',color=DS1,ms=4,lw=1.4,label='Niño 3.4')
ax.set_ylabel('Interannual SD (°C)'); ax.legend(fontsize=6.3); ax.set_ylim(0,1.3); ax.tick_params(axis='x',labelsize=6.5)
panel(ax,'b','Seasonality of the modes')
ax=axs[2]
mo=['Oct','Nov','Dec','Jan','Feb','Mar']
for c in ['LN+nIOD','LN only','EN only','EN+pIOD']:
    v=R['monthly'][c]['Nat']; ax.plot(mo,v,('-o' if c in ('EN+pIOD','LN+nIOD') else '--o'),color=CAT_COL[c],ms=3.5,lw=1.4 if 'EN' in c else 1.0,label=f"{LAB1[c]} ({R['monthly'][c]['n']})")
zero(ax); ax.set_ylabel('Monthly rainfall vs climatology (%)'); ax.legend(fontsize=5.8,loc='upper right',ncol=1); ax.set_ylim(-55,58); ax.tick_params(axis='x',labelsize=6.5)
panel(ax,'c','Monthly evolution, CHIRPS 1981–2024')
fig.tight_layout(w_pad=0.8); save(fig,'Fig09_timing_drivers')
