from figstyle import *
import json, numpy as np, pandas as pd, geopandas as gpd, matplotlib.colors as mcolors
from matplotlib.patches import Rectangle
R=json.load(open('results_final.json')); M=pd.read_pickle('mech_fields.pkl')
ne=gpd.read_file('/home/claude/data/ne/ne_50m_admin_0_countries.geojson')
fig=plt.figure(figsize=(7.4,6.6)); outer=fig.add_gridspec(2,1,height_ratios=[1.25,0.85],hspace=0.32)
gs=outer[0].subgridspec(1,4,width_ratios=[1,1,1,0.05],wspace=0.1)
gb=outer[1].subgridspec(1,2,width_ratios=[1.25,1],wspace=0.32)
def mapax(ax,lon,lat,diff,p,cmap,norm,title,letter,boxes=()):
    LON,LAT=np.meshgrid(lon,lat)
    cf=ax.pcolormesh(lon,lat,diff,cmap=cmap,norm=norm,shading='auto',rasterized=True)
    sig=p<0.05
    ss=sig.copy(); ss[::2,:]=False; ss[:,::2]=False
    ax.scatter(LON[ss],LAT[ss],s=0.5,c=INK,lw=0,alpha=0.6)
    ne.boundary.plot(ax=ax,color=INK2,lw=0.35); ne[ne.ADMIN=='Zimbabwe'].boundary.plot(ax=ax,color=INK,lw=1.0)
    for (la0,la1,lo0,lo1,lab) in boxes:
        ax.add_patch(Rectangle((lo0,la0),lo1-lo0,la1-la0,fill=False,ec=INK,lw=0.8,ls='--')); ax.text(lo0+0.3,la1-0.4,lab,fontsize=6,va='top',fontweight='bold')
    ax.set_xlim(11,41); ax.set_ylim(-35,0); ax.set_aspect('equal')
    ax.set_xticks([15,25,35]); ax.set_xticklabels(['15°E','25°E','35°E'],fontsize=6.5); ax.set_xlabel(''); ax.set_ylabel('')
    ax.set_title(f'({letter}) {title}',loc='left',fontsize=7.2,fontweight='bold'); return cf
cmap=plt.get_cmap('RdBu_r'); nw=mcolors.TwoSlopeNorm(vcenter=0,vmin=-3,vmax=3)
cw=M['cw']; lat=M['lat']; lon=M['lon']
ax=fig.add_subplot(gs[0]); cf=mapax(ax,lon,lat,cw['EN+pIOD']['diff']*100,cw['EN+pIOD']['p'],cmap,nw,f"DJF ω500, El Niño & +IOD\nminus neutral (n = {cw['EN+pIOD']['n']})",'a')
ax.set_yticks([-30,-20,-10,0]); ax.set_yticklabels(['30°S','20°S','10°S','0°'],fontsize=6.5)
ax=fig.add_subplot(gs[1]); mapax(ax,lon,lat,cw['EN only']['diff']*100,cw['EN only']['p'],cmap,nw,f"DJF ω500, El Niño only\nminus neutral (n = {cw['EN only']['n']})",'b'); ax.set_yticks([])
nz=mcolors.BoundaryNorm(np.arange(0,20,2),256); cz=M['cz5']
ax=fig.add_subplot(gs[2]); cfz=mapax(ax,M['lonz'],M['latz'],cz['EN+pIOD']['diff'],cz['EN+pIOD']['p'],plt.get_cmap('YlOrBr'),nz,f"DJF Z500, El Niño & +IOD\nminus neutral (n = {cz['EN+pIOD']['n']})",'c',
   boxes=[(-26,-18,18,28,'BH'),(-19,-11,14,25,'AL')]); ax.set_yticks([])
cs=ax.contour(M['lonz'],M['latz'],cz['EN+pIOD']['diff'],levels=np.arange(4,20,2),colors=INK2,linewidths=0.4); ax.clabel(cs,fmt='%d',fontsize=5)
cax=fig.add_subplot(gs[3]); 
cb=fig.colorbar(cf,cax=cax,orientation='vertical'); cb.set_label('ω500 (10⁻² Pa s⁻¹; red = descent)',fontsize=6.5); cb.ax.tick_params(labelsize=6)
pos=cax.get_position(); cax.set_position([pos.x0,pos.y0+pos.height*0.52,pos.width,pos.height*0.46])
cax2=fig.add_axes([pos.x0,pos.y0,pos.width,pos.height*0.46]); cb2=fig.colorbar(cfz,cax=cax2); cb2.set_label('Z500 (m, detrended)',fontsize=6.5); cb2.ax.tick_params(labelsize=6)
# bottom: Zimbabwe-mean omega DJF/OND and BH/AL composites
cats=ORDER4; x=np.arange(4); w=0.36
ax=fig.add_subplot(gb[0])
d1=[R['mech']['w500_zim_tests'][c]['d']*100 for c in cats]; d2=[R['mech']['w500_zim_tests_OND'][c]['d']*100 for c in cats]
p1=[R['mech']['w500_zim_tests'][c]['p'] for c in cats]; p2=[R['mech']['w500_zim_tests_OND'][c]['p'] for c in cats]
ax.bar(x-w/2,d2,w*0.92,color=[CAT_COL[c] for c in cats],alpha=0.55,hatch='////',edgecolor='white',lw=0.3,label='OND')
ax.bar(x+w/2,d1,w*0.92,color=[CAT_COL[c] for c in cats],label='DJF')
for i in range(4):
    for xx,v,p in [(x[i]-w/2,d2[i],p2[i]),(x[i]+w/2,d1[i],p1[i])]:
        if p<0.05: ax.text(xx,v+(0.1 if v>0 else -0.1),'*',ha='center',va='bottom' if v>0 else 'top',fontsize=8)
zero(ax); ax.set_xticks(x); ax.set_xticklabels([LAB[c] for c in cats],fontsize=6.3); ax.set_ylabel('Zimbabwe ω500 vs neutral\n(10⁻² Pa s⁻¹)'); ax.set_ylim(-2.3,1.7)
from matplotlib.patches import Patch
ax.legend(handles=[Patch(facecolor='#a9a8a1',alpha=0.55,hatch='////',label='OND'),Patch(facecolor='#a9a8a1',label='DJF')],fontsize=6.3,loc='lower left')
panel(ax,'d','ω500 over Zimbabwe, 1951–2024 (* p < 0.05)')
ax=fig.add_subplot(gb[1])
b=[R['mech']['BH'][c]['d'] for c in cats]; a=[R['mech']['AL'][c]['d'] for c in cats]
ax.bar(x-w/2,b,w*0.92,color=[CAT_COL[c] for c in cats]); ax.bar(x+w/2,a,w*0.92,color=[CAT_COL[c] for c in cats],alpha=0.55,hatch='....',edgecolor='white',lw=0.3)
for i in range(4):
    ax.text(x[i]-w/2,b[i]+(0.6 if b[i]>0 else -0.6),'BH',ha='center',va='bottom' if b[i]>0 else 'top',fontsize=5.6,color=INK2)
    ax.text(x[i]+w/2,a[i]+(0.6 if a[i]>0 else -0.6),'AL',ha='center',va='bottom' if a[i]>0 else 'top',fontsize=5.6,color=INK2)
zero(ax); ax.set_xticks(x); ax.set_xticklabels([LAB[c] for c in cats],fontsize=6.2); ax.set_ylabel('Height vs neutral (m)'); ax.set_ylim(-10,21)
panel(ax,'e','Regional highs and lows, 1980–2024')
save(fig,'Fig07_mechanism')
