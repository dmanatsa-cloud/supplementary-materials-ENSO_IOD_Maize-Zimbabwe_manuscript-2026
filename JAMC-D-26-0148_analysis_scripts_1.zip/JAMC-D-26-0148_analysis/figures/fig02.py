from figstyle import *
import json, numpy as np, pandas as pd
from analysis import T
R=json.load(open('results_final.json'))
t=T.loc[1951:2024]
fig,axs=plt.subplots(1,2,figsize=(7.4,3.3),gridspec_kw=dict(width_ratios=[1.15,1]))
ax=axs[0]
for c in ['Neutral','LN only','EN only','LN+nIOD','EN+pIOD','pIOD only','nIOD only','EN+nIOD','LN+pIOD']:
    s=t[t.cat==c]
    main=c in ['Neutral','LN only','EN only','LN+nIOD','EN+pIOD']
    for era,mk in [((1951,2017),'o'),((2018,2024),'D')]:
        ss=s.loc[era[0]:era[1]]
        if len(ss)==0: continue
        ax.scatter(ss.oni,ss.dmi,s=22 if mk=='o' else 20,marker=mk,c=CAT_COL[c] if main else 'white',edgecolor=CAT_COL[c] if not main else ('white' if mk=='o' else INK),lw=0.9 if not main else 0.6,zorder=3,
                   label=(LAB1[c] if era[0]==1951 else None) if main else None)
for y in [1961,1958,1991,1997,2015,2023,1982,2019,1987]:
    off=(5,-3) if y==1961 else (3,2)
    ax.annotate(str(y),(t.loc[y,'oni'],t.loc[y,'dmi']),xytext=off,textcoords='offset points',fontsize=5.8,color=INK2,va='top' if y==1961 else 'baseline')
for v in [0.5,-0.5]: ax.axvline(v,color=MUTE,lw=0.6,ls='--')
for v in [0.4,-0.4]: ax.axhline(v,color=MUTE,lw=0.6,ls='--')
b=R['tercile_bounds']
for v in b['oni']: ax.axvline(v,color='#c3c2b7',lw=0.6,ls=':')
for v in b['dmi']: ax.axhline(v,color='#c3c2b7',lw=0.6,ls=':')
ax.scatter([],[],marker='o',c='white',edgecolor=INK2,s=18,label='Other combinations')
ax.scatter([],[],marker='D',c='#a9a8a1',edgecolor=INK,s=16,label='2018–2024 (CHIRPS era)')
ax.set_xlabel('DJF Oceanic Niño Index (°C)'); ax.set_ylabel('SON Dipole Mode Index (°C)'); ax.set_ylim(-1.15,2.25)
ax.legend(loc='upper left',fontsize=5.8,handletextpad=0.3,borderaxespad=0.2,labelspacing=0.25,framealpha=0.9)
ax.annotate('1967',(T.loc[1967,'oni'],T.loc[1967,'dmi']),xytext=(-4,-9),textcoords='offset points',fontsize=5.8,color=INK2,ha='right')
panel(ax,'a','ENSO and IOD state of each season, 1951–2024')
ax.text(0.99,0.02,'dashed: event thresholds\ndotted: tercile bounds (1951–2017)',transform=ax.transAxes,ha='right',va='bottom',fontsize=5.8,color=INK2)
r=R['chron']['r_oni_dmi']; ax.text(0.99,0.16,f'r = {r:.2f} (1951–2017)',transform=ax.transAxes,ha='right',fontsize=6.5,color=INK)
ax=axs[1]
cats=['EN+pIOD','EN only','pIOD only','EN+nIOD','Neutral','LN+pIOD','nIOD only','LN only','LN+nIOD']
n1=[R['chron']['counts_51_17'].get(c,0) for c in cats]; n2=[sum(1 for y in range(2018,2025) if T.loc[y,'cat']==c) for c in cats]
x=np.arange(len(cats))
ax.bar(x,n1,color=[CAT_COL[c] for c in cats],width=0.7,edgecolor='white',lw=0.5)
ax.bar(x,n2,bottom=n1,color=[CAT_COL[c] for c in cats],alpha=0.4,width=0.7,edgecolor='white',lw=0.5,hatch='////')
for i,(a,b_) in enumerate(zip(n1,n2)): ax.text(i,a+b_+0.3,f'{a}'+(f'+{b_}' if b_ else ''),ha='center',fontsize=6.5,color=INK)
ax.set_xticks(x); ax.set_xticklabels([LAB1[c] for c in cats],fontsize=6.3,rotation=40,ha='right',rotation_mode='anchor'); ax.set_ylabel('Number of seasons')
from matplotlib.patches import Patch
ax.legend(handles=[Patch(facecolor='#a9a8a1',label='1951–2017 (station era)'),Patch(facecolor='#a9a8a1',alpha=0.4,hatch='////',label='2018–2024 (CHIRPS extension)')],loc='upper center',fontsize=6.2)
panel(ax,'b','Seasons in each category')
ax.set_ylim(0,max(np.array(n1)+np.array(n2))+6)
fig.tight_layout(w_pad=1.5); save(fig,'Fig02_chronology')
