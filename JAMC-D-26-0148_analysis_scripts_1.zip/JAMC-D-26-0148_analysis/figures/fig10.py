from figstyle import *
import json, numpy as np, pandas as pd, datetime as dt
from analysis import T, D, boot
R=json.load(open('results_final.json'))
Tm=D['T']; q=D['q']; q=q[(q.Year>=1951)&(q.Year<=2017)].copy(); q['cat']=q.Year.map(T.cat)
fig=plt.figure(figsize=(7.4,5.4)); gs=fig.add_gridspec(2,2,height_ratios=[1,0.8],hspace=0.5,wspace=0.3)
ax=fig.add_subplot(gs[0,0]); cats=ORDER4; x=np.arange(3); w=0.19
t=T.loc[1951:2017]
for i,c in enumerate(cats):
    vals=[];lo=[];hi=[]
    for v in ['SOS','EOS','LOS']:
        s=Tm[v]['Nat'].loc[1951:2017]; a=s[(t.cat==c).values]; b=s[(t.cat=='Neutral').values]
        d=a.mean()-b.mean(); ci=boot(a,b,4000); vals.append(d); lo.append(d-ci[0]); hi.append(ci[1]-d)
    xx=x+(i-1.5)*w
    ax.bar(xx,vals,w*0.9,color=CAT_COL[c],label=LAB1[c]); ax.errorbar(xx,vals,yerr=[lo,hi],fmt='none',ecolor=INK2,elinewidth=0.6,capsize=1.5)
zero(ax); ax.set_xticks(x); ax.set_xticklabels(['Onset (SOS)','Cessation (EOS)','Length (LOS)']); ax.set_ylabel('Days vs neutral (national)'); ax.legend(fontsize=6,ncol=2,loc='lower left')
panel(ax,'a','Season timing composites, 1951–2017')
ax=fig.add_subplot(gs[0,1])
data=[];labs=[];cols=[]
for v in ['SOS','LOS']:
    for c in ['LN+nIOD','EN only','EN+pIOD']:
        diffs=[]
        for st,g in q.groupby('Station'):
            a=g.loc[g.cat==c,v].dropna(); b=g.loc[g.cat=='Neutral',v].dropna()
            if len(a)>=3 and len(b)>=3: diffs.append(a.mean()-b.mean())
        data.append(diffs); labs.append(f'{v}\n{LAB1[c]}'); cols.append(CAT_COL[c])
pos=[0,1,2,4,5,6]
bp=ax.boxplot(data,positions=pos,widths=0.6,patch_artist=True,showfliers=True,flierprops=dict(ms=2,mec=INK2))
for p_,c_ in zip(bp['boxes'],cols): p_.set_facecolor(c_); p_.set_edgecolor(INK2); p_.set_linewidth(0.6)
for el in ['whiskers','caps','medians']:
    for l in bp[el]: l.set_color(INK); l.set_linewidth(0.7)
zero(ax); ax.set_xticks([1,5]); ax.set_xticklabels(['Onset (SOS)','Length (LOS)'])
ax.set_ylabel('Station composite difference (days)')
for k,(p0,c) in enumerate(zip([0,1,2],['LN+nIOD','EN only','EN+pIOD'])):
    pass
ss=R['timing']['station_spread']
ax.text(2,max(data[2])+3,f"{ss['SOS|EN+pIOD']['frac_pos']*100:.0f}% later",ha='center',fontsize=6,color=INK)
ax.text(6,min(data[5])-3,f"{ss['LOS|EN+pIOD']['frac_neg']*100:.0f}% shorter",ha='right',va='top',fontsize=6,color=INK); ax.set_ylim(min(data[5])-12,max(data[2])+10)
from matplotlib.patches import Patch
ax.legend(handles=[Patch(facecolor=CAT_COL[c],label=LAB1[c]) for c in ['LN+nIOD','EN only','EN+pIOD']],fontsize=6,loc='upper right')
panel(ax,'b','Spread across stations (n ≈ 40)')
ax=fig.add_subplot(gs[1,:])
base=dt.date(2001,7,1)
for k,c in enumerate(['LN+nIOD','Neutral','EN only','EN+pIOD']):
    yrs=[y for y in range(1951,2018) if T.loc[y,'cat']==c]
    s0=Tm['SOS']['Nat'].loc[yrs].mean(); e0=Tm['EOS']['Nat'].loc[yrs].mean()
    ax.barh(k,e0-s0,left=s0,height=0.55,color=CAT_COL[c])
    d0=base+dt.timedelta(days=s0-1); d1=base+dt.timedelta(days=e0-1)
    ax.text(s0-2,k,d0.strftime('%d %b'),ha='right',va='center',fontsize=6.3); ax.text(e0+2,k,d1.strftime('%d %b')+f'  ({e0-s0:.0f} d)',ha='left',va='center',fontsize=6.3)
ax.set_yticks(range(4)); ax.set_yticklabels([LAB1[c] for c in ['LN+nIOD','Neutral','EN only','EN+pIOD']])
ticks=[dt.date(2001,m,1) for m in [11,12]]+[dt.date(2002,m,1) for m in [1,2,3,4]]
ax.set_xticks([(d-base).days+1 for d in ticks]); ax.set_xticklabels([d.strftime('1 %b') for d in ticks]); ax.set_xlim(118,300)
ax.axvline(245,color=MUTE,lw=0.6,ls='--'); ax.set_ylim(-0.9,3.5); ax.text(247,-0.62,f"earliest recordable cessation ({R['timing']['eos_floor_frac']*100:.0f}% of station-seasons at this bound)",fontsize=5.8,color=INK2,va='center')
panel(ax,'c','Composite season windows (national mean of station onset and cessation)')
save(fig,'Fig10_season_timing')
