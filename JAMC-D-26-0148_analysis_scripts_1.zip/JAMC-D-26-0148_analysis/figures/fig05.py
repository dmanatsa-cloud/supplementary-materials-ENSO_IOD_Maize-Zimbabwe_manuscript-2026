from figstyle import *
import json, numpy as np, pandas as pd, matplotlib.colors as mcolors
from analysis import T, D, classify, boot
from stations import representative, pct_anom, NRS
R=json.load(open('results_final.json'))
A=D['A']; CA=D['chA']
def comp(t,AA,years,cat):
    t=t.loc[list(years)]; AA=AA.reindex(list(years))
    a=AA.loc[(t.cat==cat).values,'Nat'].dropna().values; b=AA.loc[(t.cat=='Neutral').values,'Nat'].dropna().values
    ci=boot(a,b,4000); return a.mean()-b.mean(),ci,len(a)
rows=[]
for conv,lab in [('roll','Moving 30-yr base (primary)'),('f8110','Fixed 1981–2010 base'),('f9120','Fixed 1991–2020 base'),('detr_boxes','Linear trend removed (each box)'),('had_roll','HadISST1 DMI (moving base)')]:
    t=classify(conv); rows.append((lab,comp(t,A,range(1951,2018),'EN+pIOD'),comp(t,A,range(1951,2018),'EN only')))
for mm,lab in [((9,),'DMI September only'),((11,),'DMI November only')]:
    t=classify('roll',iodmonths=mm); rows.append((lab,comp(t,A,range(1951,2018),'EN+pIOD'),comp(t,A,range(1951,2018),'EN only')))
qm=pd.read_pickle('station_qc_msd.pkl'); Rm,_=representative(qm,'Season_T'); Am=pct_anom(Rm); Am['Nat']=Am[NRS].mean(axis=1)
rows.append(('MSD station-to-NR membership',comp(T,Am,range(1951,2018),'EN+pIOD'),comp(T,Am,range(1951,2018),'EN only')))
rows.append(('Stations, 1983–2017 only',comp(T,A,range(1983,2018),'EN+pIOD'),comp(T,A,range(1983,2018),'EN only')))
rows.append(('CHIRPS v2.0, 1981–2024',comp(T,CA,range(1981,2025),'EN+pIOD'),comp(T,CA,range(1981,2025),'EN only')))
pd.to_pickle(rows,'fig05_rows.pkl')
fig=plt.figure(figsize=(7.4,6.6)); gs=fig.add_gridspec(2,2,width_ratios=[1,0.95],hspace=0.45,wspace=0.95)
ax=fig.add_subplot(gs[0,0])
G=R['thr_grid']; M=np.array([[g['d'] for g in G if g['te']==te] for te in [0.4,0.5,0.6]])
cmap=plt.get_cmap('BrBG'); norm=mcolors.TwoSlopeNorm(vcenter=0,vmin=-30,vmax=30)
ax.imshow(M,cmap=cmap,norm=norm,aspect='auto')
for i,te in enumerate([0.4,0.5,0.6]):
    for j,ti in enumerate([0.3,0.4,0.5]):
        g=[g for g in G if g['te']==te and g['ti']==ti][0]
        ax.text(j,i,f"{g['d']:+.0f}% (n={g['n']})\nEN only {g['d_en']:+.0f}%",ha='center',va='center',fontsize=6.0,color='white' if g['d']<-20 else INK,fontweight='bold' if g['p']<0.05 else 'normal')
ax.set_xticks(range(3)); ax.set_xticklabels(['±0.3','±0.4','±0.5']); ax.set_yticks(range(3)); ax.set_yticklabels(['±0.4','±0.5','±0.6'])
ax.set_xlabel('SON DMI threshold (°C)'); ax.set_ylabel('DJF ONI threshold (°C)')
for s_ in ax.spines.values(): s_.set_visible(False)
panel(ax,'a','Threshold grid: El Niño & +IOD vs neutral')
ax.text(0.5,-0.3,'bold: p < 0.05 (Welch); lower line: El Niño only vs neutral',transform=ax.transAxes,ha='center',fontsize=6,color=INK2)
ax=fig.add_subplot(gs[0,1])
y=np.arange(len(rows))[::-1]
for k,(lab,a,b) in enumerate(rows):
    yy=y[k]
    ax.errorbar(a[0],yy+0.15,xerr=[[a[0]-a[1][0]],[a[1][1]-a[0]]],fmt='o',color=CAT_COL['EN+pIOD'],ms=4,elinewidth=0.8,capsize=1.5)
    ax.errorbar(b[0],yy-0.15,xerr=[[b[0]-b[1][0]],[b[1][1]-b[0]]],fmt='s',color=CAT_COL['EN only'],ms=3.5,elinewidth=0.8,capsize=1.5)
    ax.text(24,yy,f'{a[2]}/{b[2]}',fontsize=5.8,va='center',color=INK2)
ax.set_yticks(y); ax.set_yticklabels([r[0] for r in rows],fontsize=6.2); zero(ax,'x')
ax.set_xlabel('National rainfall vs neutral (%)'); ax.set_xlim(-50,32); ax.text(24,len(rows)-0.4,'n',fontsize=5.8,color=INK2)
ax.plot([],[],'o',color=CAT_COL['EN+pIOD'],label='El Niño & +IOD'); ax.plot([],[],'s',color=CAT_COL['EN only'],label='El Niño only')
ax.legend(loc='upper center',bbox_to_anchor=(0.45,-0.16),ncol=2,fontsize=6.2)
panel(ax,'b','Index conventions and data choices')
ax=fig.add_subplot(gs[1,0])
TT=R['terciles']; E=['cold','mid','warm']; I_=['neg','mid','pos']
M=np.array([[TT[f'{e}|{i}']['mean'] if TT[f'{e}|{i}']['mean'] is not None else np.nan for e in E] for i in I_[::-1]])
ax.imshow(M,cmap=cmap,norm=norm,aspect='auto')
for r_,i in enumerate(I_[::-1]):
    for c_,e in enumerate(E):
        v=TT[f'{e}|{i}']; ax.text(c_,r_,f"{v['mean']:+.0f}%\nn={v['n']}",ha='center',va='center',fontsize=6.5,color='white' if abs(v['mean'])>22 else INK)
ax.set_xticks(range(3)); ax.set_xticklabels(['Cold','Middle','Warm']); ax.set_yticks(range(3)); ax.set_yticklabels(['Positive','Middle','Negative'])
ax.set_xlabel('DJF ONI tercile'); ax.set_ylabel('SON DMI tercile')
ax.text(0.5,-0.32,'cells: mean national rainfall anomaly (% of 1951–2017 mean)',transform=ax.transAxes,ha='center',fontsize=6,color=INK2)
for s_ in ax.spines.values(): s_.set_visible(False)
panel(ax,'c','Tercile classification (equal margins)')
ax=fig.add_subplot(gs[1,1])
IN=R['intensity']; labs=['moderate EN only','moderate EN+pIOD','strong EN only','strong EN+pIOD']
v=[IN[l]['d'] for l in labs]
cols=[CAT_COL['EN only'],CAT_COL['EN+pIOD'],CAT_COL['EN only'],CAT_COL['EN+pIOD']]
bars=ax.bar(range(4),v,color=cols,width=0.62,hatch=['','','////','////'],edgecolor='white',lw=0.4)
for i,l in enumerate(labs): ax.text(i,v[i]-1.5 if v[i]<0 else v[i]+1,f"{v[i]:+.0f}%\nn={IN[l]['n']}",ha='center',va='top' if v[i]<0 else 'bottom',fontsize=6.3)
zero(ax); ax.set_xticks(range(4)); ax.set_xticklabels(['Moderate\nEl Niño\nonly','Moderate\nEl Niño\n& +IOD','Strong\nEl Niño\nonly','Strong\nEl Niño\n& +IOD'],fontsize=6.3)
ax.set_ylabel('National rainfall vs neutral (%)'); ax.set_ylim(-36,12)
panel(ax,'d','Event intensity (strong: DJF ONI ≥ 1.0 °C)')
save(fig,'Fig05_robustness')
for r in rows: print(r[0],[round(x,1) if not isinstance(x,list) else [round(z,1) for z in x] for x in r[1]],[round(x,1) if not isinstance(x,list) else [round(z,1) for z in x] for x in r[2]])
