from figstyle import *
import json, numpy as np, pandas as pd, geopandas as gpd
from masks import nr_polygons
from analysis import T, D, IDX
R=json.load(open('results_final.json'))
g,d=nr_polygons(); ne=gpd.read_file('/home/claude/data/ne/ne_50m_admin_0_countries.geojson')
# S1 original seven zones
col={'I':'#0d366b','IIa':'#2a78d6','IIb':'#86b6ef','III':'#cde2fb','IV':'#f2c48d','Va':'#d9822b','Vb':'#a85a12'}
fig,ax=plt.subplots(figsize=(5.2,4.4))
for z in ['I','IIa','IIb','III','IV','Va','Vb']: g[g.Rev_Region==z].plot(ax=ax,color=col[z],edgecolor='white',lw=0.3)
ne[ne.ADMIN=='Zimbabwe'].boundary.plot(ax=ax,color=INK,lw=0.8)
from matplotlib.patches import Patch
area=(g.to_crs('ESRI:102022').area/1e6).values
ax.legend(handles=[Patch(color=col[z],label=f'{z} ({a/1000:.1f}×10³ km²)') for z,a in zip(g.Rev_Region,area)],loc='upper left',bbox_to_anchor=(1.0,1.0),fontsize=6.5,title='Revised Natural Regions',title_fontsize=7)
ax.set_xlim(25.1,33.2); ax.set_ylim(-22.6,-15.4); ax.set_aspect('equal'); ax.set_xlabel(''); ax.set_ylabel('')
ax.set_xticks(range(26,34)); ax.set_xticklabels([f'{v}°E' for v in range(26,34)],fontsize=6.5); ax.set_yticks(range(-22,-15)); ax.set_yticklabels([f'{-v}°S' for v in range(-22,-15)],fontsize=6.5)
save(fig,'FigS1_seven_zones')
# S2 station coverage
C=D['C']
fig,ax=plt.subplots(figsize=(7.0,2.6))
nrc={'I':'#0d366b','II':'#3987e5','III':'#9ec5f4','IV':'#f2c48d','V':'#d9822b'}
for nr in ['I','II','III','IV','V']: ax.plot(C.index,C[nr],color=nrc[nr],lw=1.3,label=f'NR {nr}')
ax.axhline(2,color=MUTE,ls='--',lw=0.6); ax.text(1951,2.3,'low-coverage flag (< 2 stations)',fontsize=6,color=INK2)
ax.set_ylabel('Stations reporting a seasonal total'); ax.set_xlabel('Season onset year'); ax.legend(ncol=5,fontsize=6.5,loc='upper left')
save(fig,'FigS2_station_coverage')
# S3 index conventions
fig,axs=plt.subplots(2,1,figsize=(7.0,4.6),sharex=True)
yrs=range(1951,2025)
from indices import seas
def s(col,ms): return pd.Series({y:seas(IDX[col],y,ms) for y in yrs})
ax=axs[0]
ax.plot(list(yrs),s('n34_roll',(12,1,2)),color=INK,lw=1.2,label='Moving 30-yr base (primary)')
ax.plot(list(yrs),s('n34_8110',(12,1,2)),color=DS1,lw=0.9,label='Fixed 1981–2010 base')
ax.plot(list(yrs),s('n34_detr',(12,1,2)),color=DS2,lw=0.9,ls='--',label='Fixed base, linear trend removed')
for v in [0.5,-0.5]: ax.axhline(v,color=MUTE,lw=0.5,ls=':')
zero(ax); ax.set_ylabel('DJF Niño 3.4 (°C)'); ax.legend(fontsize=6.2,ncol=3,loc='upper left'); panel(ax,'a','ERSSTv5 Niño 3.4 under three trend treatments')
ax=axs[1]
ax.plot(list(yrs),s('dmi_roll',(9,10,11)),color=INK,lw=1.2,label='ERSSTv5, moving base (primary)')
ax.plot(list(yrs),s('dmi_8110',(9,10,11)),color=DS1,lw=0.9,label='ERSSTv5, fixed 1981–2010 base')
ax.plot(list(yrs),s('dmi_detr_boxes',(9,10,11)),color=DS2,lw=0.9,ls='--',label='ERSSTv5, each box detrended')
ax.plot(list(yrs),s('dmi_had_roll',(9,10,11)),color='#eb6834',lw=0.9,ls='-.',label='HadISST1, moving base')
for v in [0.4,-0.4]: ax.axhline(v,color=MUTE,lw=0.5,ls=':')
zero(ax); ax.set_ylabel('SON DMI (°C)'); ax.legend(fontsize=6.2,ncol=2,loc='upper left'); ax.set_xlabel('Season onset year'); panel(ax,'b','Dipole Mode Index under alternative datasets and trend treatments')
fig.tight_layout(); save(fig,'FigS3_index_conventions')
# S4 monthly evolution by NR (CHIRPS)
fig,axs=plt.subplots(1,5,figsize=(7.4,2.2),sharey=True)
mo=['O','N','D','J','F','M']
for k,nr in enumerate(['I','II','III','IV','V']):
    ax=axs[k]
    for c in ['LN+nIOD','EN only','EN+pIOD']:
        ax.plot(mo,R['monthly'][c][nr],'-o' if c!='EN only' else '--o',color=CAT_COL[c],ms=2.5,lw=1.1,label=LAB1[c])
    zero(ax); ax.set_title(f'NR {nr}',fontsize=7.5)
axs[0].set_ylabel('Monthly rainfall vs\nclimatology (%)'); fig.legend(*axs[0].get_legend_handles_labels(),fontsize=6.5,loc='lower center',ncol=3,bbox_to_anchor=(0.5,-0.06),frameon=False)
fig.tight_layout(w_pad=0.3); save(fig,'FigS4_monthly_by_NR')
print('ok')
