from figstyle import *
import json, numpy as np, geopandas as gpd, matplotlib.colors as mcolors
from masks import nr_polygons
R=json.load(open('results_final.json'))
g,d=nr_polygons(); ne=gpd.read_file('/home/claude/data/ne/ne_50m_admin_0_countries.geojson')
NR=['I','II','III','IV','V']
cmap=plt.get_cmap('BrBG'); norm=mcolors.TwoSlopeNorm(vcenter=0,vmin=-35,vmax=35)
fig=plt.figure(figsize=(7.4,6.2))
gs=fig.add_gridspec(2,3,height_ratios=[1.05,1],width_ratios=[1,1,0.06],hspace=0.32,wspace=0.08)
cent={'I':(32.85,-19.3),'II':(31.0,-17.6),'III':(30.0,-19.2),'IV':(27.6,-19.7),'V':(30.9,-21.4)}
for k,(cat,letter) in enumerate([('EN+pIOD','a'),('EN only','b')]):
    ax=fig.add_subplot(gs[0,k])
    for nr in NR:
        v=R['st'][cat][nr]['d']; d[d.NR==nr].plot(ax=ax,color=cmap(norm(v)),edgecolor='white',lw=0.4)
    ne[ne.ADMIN=='Zimbabwe'].boundary.plot(ax=ax,color=INK,lw=0.7)
    for nr in NR:
        v=R['st'][cat][nr]['d']; q=R['st_fdr'].get(f'{cat}|{nr}',{}).get('q',1)
        x,y=cent[nr]
        ax.text(x,y,f'NR {nr}\n{v:+.0f}%'+('*' if q<0.05 else ''),ha='center',va='center',fontsize=6.6,fontweight='bold' if q<0.05 else 'normal',color=INK,
                bbox=dict(boxstyle='round,pad=0.15',fc='white',ec='none',alpha=0.75))
    ax.set_xlim(25.1,33.2); ax.set_ylim(-22.6,-15.4); ax.set_aspect('equal'); ax.set_xticks([]); ax.set_yticks([]); ax.set_xlabel(''); ax.set_ylabel('')
    for s_ in ax.spines.values(): s_.set_visible(False)
    n=R['st'][cat]['n']; panel(ax,letter,f'{LAB1[cat]} minus neutral (n = {n})')
cax=fig.add_subplot(gs[0,2]); cb=fig.colorbar(plt.cm.ScalarMappable(norm=norm,cmap=cmap),cax=cax); cb.set_label('Seasonal rainfall anomaly (% of mean)',fontsize=7); cb.ax.tick_params(labelsize=6.5)
ax=fig.add_subplot(gs[1,:])
cats=ORDER4; w=0.19; x=np.arange(5)
for i,c in enumerate(cats):
    vals=[R['st'][c][nr]['d'] for nr in NR]; ci=np.array([R['st_boot'][c][nr] for nr in NR])
    xx=x+(i-1.5)*w
    ax.bar(xx,vals,width=w*0.9,color=CAT_COL[c],label=f"{LAB1[c]} (n = {R['st'][c]['n']})",zorder=2)
    ax.errorbar(xx,vals,yerr=[np.array(vals)-ci[:,0],ci[:,1]-np.array(vals)],fmt='none',ecolor=INK2,elinewidth=0.6,capsize=1.5,zorder=3)
    for j,nr in enumerate(NR):
        q=R['st_fdr'].get(f'{c}|{nr}',{}).get('q',1)
        if q<0.05: ax.text(xx[j],ci[j,0]-3.5,'*',ha='center',fontsize=8,color=INK)
zero(ax); ax.set_xticks(x); ax.set_xticklabels([f"NR {nr}\n({R['nr_clim'][nr]:.0f} mm)" for nr in NR])
ax.set_ylabel('Rainfall anomaly vs neutral (%)'); ax.set_ylim(-50,78); ax.legend(ncol=4,loc='upper center',fontsize=6.5)
panel(ax,'c','Co-occurrence composites by Natural Region, station rainfall 1951–2017')
ax.text(0.995,0.03,'bars: 95% bootstrap CI;  *: FDR-adjusted q < 0.05',transform=ax.transAxes,ha='right',fontsize=6,color=INK2)
save(fig,'Fig03_NR_responses')
