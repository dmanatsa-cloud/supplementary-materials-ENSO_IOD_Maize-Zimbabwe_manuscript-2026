from figstyle import *
import json, numpy as np, pandas as pd
from analysis import T, D
from analysis3 import lin_detr
R=json.load(open('results_final.json'))
fig,axs=plt.subplots(1,3,figsize=(7.4,2.8),gridspec_kw=dict(width_ratios=[1.1,1,1.1]))
ax=axs[0]; cats=ORDER4+['Neutral']; x=np.arange(5); w=0.36
b=[R['temp']['berk_detr'][c] for c in cats]; e=[R['temp']['era_detr'][c] for c in cats]
ax.bar(x-w/2,b,w*0.92,color=DS1,label='Berkeley Earth'); ax.bar(x+w/2,e,w*0.92,color=DS2,label='ERA5')
for i in range(5): ax.text(x[i],max(b[i],e[i])+0.08 if b[i]>0 else min(b[i],e[i])-0.08,f'{b[i]:+.1f}',ha='center',va='bottom' if b[i]>0 else 'top',fontsize=6)
zero(ax); ax.set_xticks(x); ax.set_xticklabels([LAB[c] for c in cats],fontsize=6); ax.set_ylabel('DJF Tmax anomaly (°C, detrended)'); ax.legend(fontsize=6.2,loc='upper left'); ax.set_ylim(-1.6,1.9)
cnt=R['temp']['counts']; ax.text(0.99,0.02,'1970–2024; n = '+'/'.join(str(cnt[c]) for c in cats),transform=ax.transAxes,ha='right',fontsize=5.6,color=INK2)
panel(ax,'a','Temperature by category')
ax=axs[1]
tb=lin_detr(D['tb'].loc[1970:2024]); A=D['A']
yy=list(range(1970,2018))
for c in ['Neutral','LN only','EN only','LN+nIOD','EN+pIOD']:
    s=[y for y in yy if T.loc[y,'cat']==c]
    ax.scatter(A.loc[s,'Nat'],tb.loc[s],s=14,color=CAT_COL[c],edgecolor='white',lw=0.4,label=LAB1[c],zorder=3)
s=[y for y in yy if T.loc[y,'cat'] not in ['Neutral','LN only','EN only','LN+nIOD','EN+pIOD']]
ax.scatter(A.loc[s,'Nat'],tb.loc[s],s=12,facecolor='white',edgecolor=INK2,lw=0.6,zorder=3,label='Other')
p=np.polyfit(A.loc[yy,'Nat'],tb.loc[yy],1); xx=np.linspace(-50,55,10); ax.plot(xx,np.polyval(p,xx),color=INK2,lw=0.8)
ax.text(0.98,0.95,f"r = {R['temp']['r_rain_berk_st']:.2f}",transform=ax.transAxes,ha='right',va='top',fontsize=6.8)
ax.set_xlabel('National rainfall anomaly (%)'); ax.set_ylabel('DJF Tmax anomaly (°C)'); ax.legend(fontsize=5.6,loc='lower left',ncol=1,handletextpad=0.1)
panel(ax,'b','Rainfall vs Tmax, 1970–2017')
ax=axs[2]; NR=['I','II','III','IV','V','Nat']; x=np.arange(6)
r=[abs(R['cohen'][n]['rain']) for n in NR]; s_=[abs(R['cohen'][n]['spei']) for n in NR]
ax.bar(x-w/2,r,w*0.92,color='#a9a8a1',label='Station rainfall'); ax.bar(x+w/2,s_,w*0.92,color=DS1,label='SPEI-6')
ax.set_xticks(x); ax.set_xticklabels([f'NR {n}' if n!='Nat' else 'National' for n in NR],fontsize=6.2,rotation=30); ax.set_ylabel("|Cohen's d| (El Niño vs other)"); ax.legend(fontsize=6.2,loc='upper left'); ax.set_ylim(0,1.15)
panel(ax,'c','El Niño detection, 1951–2017')
fig.tight_layout(w_pad=1.0); save(fig,'Fig06_hot_dry')
