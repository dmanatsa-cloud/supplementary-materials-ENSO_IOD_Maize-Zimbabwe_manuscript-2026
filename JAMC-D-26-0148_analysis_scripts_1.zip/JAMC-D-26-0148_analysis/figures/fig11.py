from figstyle import *
import json, numpy as np
from analysis import T, D
R=json.load(open('results_final.json')); A=D['A']; CA=D['chA']
fig,axs=plt.subplots(1,3,figsize=(7.4,2.9),gridspec_kw=dict(width_ratios=[1,0.75,1.5]))
ax=axs[0]; yy=list(range(1981,2018))
for c in ['Neutral','LN only','EN only','LN+nIOD','EN+pIOD']:
    s=[y for y in yy if T.loc[y,'cat']==c]; ax.scatter(A.loc[s,'Nat'],CA.loc[s,'Nat'],s=14,color=CAT_COL[c],edgecolor='white',lw=0.4,zorder=3)
s=[y for y in yy if T.loc[y,'cat'] not in ['Neutral','LN only','EN only','LN+nIOD','EN+pIOD']]; ax.scatter(A.loc[s,'Nat'],CA.loc[s,'Nat'],s=12,facecolor='white',edgecolor=INK2,lw=0.6)
ax.plot([-50,60],[-50,60],color=MUTE,lw=0.6,ls='--'); ax.set_xlim(-50,60); ax.set_ylim(-50,60)
ax.text(0.04,0.95,f"r = {R['chirps']['val']['Nat']['r']:.2f}\nn = 37",transform=ax.transAxes,va='top',fontsize=6.8)
ax.set_xlabel('Station anomaly (%)'); ax.set_ylabel('CHIRPS anomaly (%)'); panel(ax,'a','National, 1981–2017')
ax=axs[1]; NR=['I','II','III','IV','V','Nat']
r=[R['chirps']['val'][n]['r'] for n in NR]
ax.barh(range(6)[::-1],r,color='#a9a8a1',height=0.6)
for i,v in enumerate(r): ax.text(v+0.02,5-i,f'{v:.2f}',va='center',fontsize=6.3)
ax.set_yticks(range(6)[::-1]); ax.set_yticklabels([f'NR {n}' if n!='Nat' else 'National' for n in NR]); ax.set_xlim(0,1.05); ax.set_xlabel('r (station vs CHIRPS)')
panel(ax,'b','Agreement by region')
ax=axs[2]; cats=ORDER4; x=np.arange(6); w=0.19
for i,c in enumerate(cats):
    v=[R['chirps']['ext'][c][n]['d'] for n in NR]; p=[R['chirps']['ext'][c][n]['p'] for n in NR]
    xx=x+(i-1.5)*w; ax.bar(xx,v,w*0.9,color=CAT_COL[c],label=f"{LAB1[c]} ({R['chirps']['ext'][c]['n']})")
    for j in range(6):
        if p[j]<0.05: ax.text(xx[j],v[j]+(1 if v[j]>0 else -1),'*',ha='center',va='bottom' if v[j]>0 else 'top',fontsize=7.5)
zero(ax); ax.set_xticks(x); ax.set_xticklabels([f'NR {n}' if n!='Nat' else 'Nat.' for n in NR],fontsize=6.5); ax.set_ylabel('CHIRPS rainfall vs neutral (%)')
ax.legend(fontsize=5.8,ncol=2,loc='upper right'); ax.set_ylim(-35,48)
panel(ax,'c','CHIRPS composites, 1981–2024 (* p < 0.05)')
fig.tight_layout(w_pad=0.8); save(fig,'Fig11_chirps')
