from figstyle import *
import geopandas as gpd, pandas as pd, numpy as np
from masks import nr_polygons
g,d=nr_polygons(); ne=gpd.read_file('/home/claude/data/ne/ne_50m_admin_0_countries.geojson')
x=pd.read_csv('stations_table.csv'); x['Natural_Region']=x['NR_poly']
q=pd.read_pickle('station_qc.pkl')
yrs=q[q.Season_T.notna()].groupby('Station').Year.agg(['min','max','count'])
x=x.merge(yrs,left_on='Station',right_index=True,how='left')
nrcol={'I':'#0d366b','II':'#3987e5','III':'#9ec5f4','IV':'#f2c48d','V':'#d9822b'}
fig=plt.figure(figsize=(7.4,4.3))
ax=fig.add_axes([0.0,0.0,0.68,1.0])
for nr in ['I','II','III','IV','V']:
    d[d.NR==nr].plot(ax=ax,color=nrcol[nr],edgecolor='white',lw=0.6)
# subzone boundaries (IIa/IIb, Va/Vb) dashed
for sub in ['IIa','IIb','Va','Vb']:
    g[g.Rev_Region==sub].boundary.plot(ax=ax,color='#52514e',lw=0.35,linestyle='--')
ne[ne.ADMIN=='Zimbabwe'].boundary.plot(ax=ax,color=INK,lw=0.8)
for nr,mk in zip(['I','II','III','IV','V'],['o','o','o','o','o']):
    s=x[x.Natural_Region==nr]
    ax.scatter(s.Longitude,s.Latitude,s=14+0.35*s['count'].fillna(0),c='white',edgecolor=INK,lw=0.7,zorder=5)
for _,r in x.iterrows():
    if r.Station in ['Harare_Airport','Bulawayo_Goetz','Masvingo','Beitbridge','Chipinge','Nyanga','Victoria_Falls','Kariba','Gweru','Mutare','Hwange','Karoi','Harare','Bulawayo']:
        east=r.Longitude>32.3
        ax.annotate(r.Station.replace('_Airport','').replace('_Goetz','').replace('_',' '),(r.Longitude,r.Latitude),xytext=(-4 if east else 3,3),textcoords='offset points',fontsize=6,color=INK2,ha='right' if east else 'left',bbox=dict(boxstyle='round,pad=0.1',fc='white',ec='none',alpha=0.7))
ax.set_xlim(25.1,33.2); ax.set_ylim(-22.6,-15.4); ax.set_aspect('equal'); ax.set_xticks(range(26,34)); ax.set_yticks(range(-22,-15))
ax.set_xlabel(''); ax.set_ylabel(''); ax.set_xticklabels([f'{v}°E' for v in range(26,34)]); ax.set_yticklabels([f'{-v}°S' for v in range(-22,-15)])
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
area=(d.to_crs('ESRI:102022').area/1e6).values
nst=x.groupby('Natural_Region').size()
import json; _R=json.load(open('results_final.json')); clim={k:round(v) for k,v in _R['nr_clim'].items()}
h=[Patch(facecolor=nrcol[nr],edgecolor='none',label=f'NR {nr}: {nst[nr]} stations, {area[i]/1000:.0f}×10³ km², {clim[nr]} mm') for i,nr in enumerate(['I','II','III','IV','V'])]
h+= [Line2D([],[],color='#52514e',lw=0.6,ls=(0,(2,2)),label='Sub-zone boundary (IIa/IIb, Va/Vb)'),
     Line2D([],[],marker='o',ls='',mfc='white',mec=INK,ms=5,label='MSD station (size ∝ years of record)')]
ax.legend(handles=h,loc='upper left',bbox_to_anchor=(1.0,0.98),fontsize=6.8,title='Natural Region (ONDJFM mean, 1951–2017)',title_fontsize=7,alignment='left')
# inset locator
ax2=fig.add_axes([0.72,0.06,0.25,0.42])
ne.plot(ax=ax2,color='#f0efec',edgecolor='#c3c2b7',lw=0.3); ne[ne.ADMIN=='Zimbabwe'].plot(ax=ax2,color='#b3302e')
ax2.set_xlim(10,42); ax2.set_ylim(-35,-5); ax2.set_xticks([]); ax2.set_yticks([]); ax2.set_xlabel(''); ax2.set_ylabel(''); 
for s_ in ax2.spines.values(): s_.set_visible(True); s_.set_color('#c3c2b7')
ax2.set_title('Southern Africa',fontsize=7,fontweight='normal',color=INK2)
save(fig,'Fig01_study_area')
print(dict(zip(['I','II','III','IV','V'],area.round(0))),nst.to_dict())
