from figstyle import *
import json, numpy as np, pandas as pd
from analysis import T, boot
R=json.load(open('results_final.json')); M=pd.read_pickle('maize_series.pkl'); mz=M['mz']; fit=M['mfit']; ma=M['ma']
fig,axs=plt.subplots(1,3,figsize=(7.4,2.9),gridspec_kw=dict(width_ratios=[1.5,1.05,1.05]))
ax=axs[0]
ax.plot(mz.index,mz.values/1000,color=INK,lw=1.0,marker='o',ms=2.2)
for a,b in [(1960,1999),(2000,2023)]: ax.plot(fit.loc[a:b].index,fit.loc[a:b].values/1000,color=MUTE,lw=0.9,ls='--')
for y in mz.index:
    c=T.loc[y,'cat']
    if c=='EN+pIOD': ax.scatter(y,mz[y]/1000,s=24,color=CAT_COL[c],zorder=4,edgecolor='white',lw=0.5)
    if c=='EN only': ax.scatter(y,mz[y]/1000,s=18,color=CAT_COL[c],zorder=4,edgecolor='white',lw=0.5,marker='s')
OFF={1986:(-12,4),1994:(-4,-10),1982:(-6,-9)}
for y in [1991,1994,2001,2015,2023,1982,1986]: ax.annotate(f'{y}/{str(y+1)[2:]}',(y,mz[y]/1000),xytext=OFF.get(y,(0,-9)),textcoords='offset points',ha='center',va='bottom' if y==1986 else 'baseline',fontsize=5.4,color=INK2)
ax.axvline(1999.5,color='#c3c2b7',lw=0.6); ax.text(2000.5,2.75,'fast-track\nland reform',fontsize=5.6,color=INK2)
ax.scatter([],[],s=24,color=CAT_COL['EN+pIOD'],label='El Niño & +IOD'); ax.scatter([],[],s=18,marker='s',color=CAT_COL['EN only'],label='El Niño only'); ax.plot([],[],ls='--',color=MUTE,label='Era trend')
ax.legend(fontsize=6,loc='upper left',ncol=3); ax.set_ylabel('Maize production (Mt)'); ax.set_xlabel('Season onset year'); ax.set_ylim(0,3.6)
panel(ax,'a','National maize production (USDA)')
ax=axs[1]; cats=ORDER4+['Neutral']
Y=json.load(open('results_yield.json')); YS=pd.read_pickle('yield_series.pkl'); ya=YS['ya']; AP=pd.read_pickle('fao_area_prod_series.pkl'); aa=AP['aa']
def bci(series):
    v=[];c=[]
    for k in cats:
        x=series.reindex([y for y in range(1960,2024) if T.loc[y,'cat']==k]).dropna().values
        rng=np.random.default_rng(3); bs=[rng.choice(x,len(x)).mean() for _ in range(4000)]; v.append(x.mean()); c.append(np.percentile(bs,[2.5,97.5]))
    return np.array(v),np.array(c)
v,cis=bci(ma); vy,ciy=bci(ya); va,cia=bci(aa); xx=np.arange(5); w=0.27
ax.bar(xx-w,v,color=[CAT_COL[c] for c in cats],width=w*0.95,label='Production (USDA)')
ax.bar(xx+w,va,color='white',width=w*0.95,edgecolor=[CAT_COL[c] for c in cats],lw=0.8,hatch='....',label='Area harvested (FAOSTAT)')
ax.bar(xx,vy,color=[CAT_COL[c] for c in cats],width=w*0.95,alpha=0.55,hatch='////',edgecolor='white',lw=0.3,label='Yield (FAOSTAT)')
ax.errorbar(xx-w,v,yerr=[v-cis[:,0],cis[:,1]-v],fmt='none',ecolor=INK2,elinewidth=0.5,capsize=1.0)
ax.errorbar(xx,vy,yerr=[vy-ciy[:,0],ciy[:,1]-vy],fmt='none',ecolor=INK2,elinewidth=0.5,capsize=1.0)
ax.errorbar(xx+w,va,yerr=[va-cia[:,0],cia[:,1]-va],fmt='none',ecolor=INK2,elinewidth=0.5,capsize=1.0)
from matplotlib.patches import Patch
ax.legend(handles=[Patch(facecolor='#a9a8a1',label='Production (USDA)'),Patch(facecolor='#a9a8a1',alpha=0.55,hatch='////',edgecolor='white',label='Yield (FAOSTAT)'),Patch(facecolor='white',edgecolor='#a9a8a1',hatch='....',label='Area harvested (FAOSTAT)')],fontsize=5.4,loc='upper left',frameon=False)
zero(ax); ax.set_xticks(xx); ax.set_xticklabels([LAB1[c] for c in cats],fontsize=5.9,rotation=35,ha='right',rotation_mode='anchor'); ax.set_ylabel('Departure from era trend (%)'); ax.set_ylim(-50,62)
panel(ax,'b','Departure by category')
ax=axs[2]
for j,(m,lab) in enumerate([(R['maize'],'Production'),(Y['fao_prod'],'FAO production'),(Y,'Yield')]):
    comps=[m['uniq_enso']*100,m['shared']*100,m['uniq_iod']*100]
    ax.bar([j],[comps[0]],color=DS1,width=0.55,label='ENSO unique' if j==0 else None)
    ax.bar([j],[comps[1]],bottom=[comps[0]],color='#a9a8a1',width=0.55,label='Shared' if j==0 else None)
    ax.bar([j],[comps[2]],bottom=[comps[0]+comps[1]],color=DS2,width=0.55,label='IOD unique' if j==0 else None)
    ax.text(j,sum(comps)+0.8,f"R² = {m['R2_full']*100:.0f}%",ha='center',fontsize=6)
    ax.text(j,-1.2,f"{comps[0]:.1f}/{comps[1]:.1f}/{comps[2]:.1f}",ha='center',va='top',fontsize=4.8,color=INK2)
ax.set_xlim(-0.6,2.6); ax.set_xticks([0,1,2]); ax.set_xticklabels(['Production\n(USDA)','Production\n(FAOSTAT)','Yield\n(FAOSTAT)'],fontsize=5.4)
ax.tick_params(axis='x',pad=12); ax.set_ylabel('Variance explained (%)'); ax.set_ylim(0,36); ax.legend(fontsize=5.8,loc='upper right')
panel(ax,'c','Variance partition')
fig.tight_layout(w_pad=0.6); save(fig,'Fig12_maize')
