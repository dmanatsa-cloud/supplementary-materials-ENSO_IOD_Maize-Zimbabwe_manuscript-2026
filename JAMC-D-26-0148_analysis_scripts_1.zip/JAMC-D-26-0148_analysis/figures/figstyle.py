import matplotlib as mpl, matplotlib.pyplot as plt
mpl.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':8.5,'axes.labelsize':8,'xtick.labelsize':7.5,'ytick.labelsize':7.5,
  'legend.fontsize':7,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':0.6,'xtick.major.width':0.6,'ytick.major.width':0.6,
  'axes.edgecolor':'#52514e','axes.labelcolor':'#0b0b0b','xtick.color':'#52514e','ytick.color':'#52514e','axes.titleweight':'bold','axes.titlelocation':'left',
  'savefig.dpi':300,'figure.dpi':150,'axes.grid':False,'legend.frameon':False,'hatch.linewidth':0.5})
CAT_COL={'LN+nIOD':'#1c5cab','LN only':'#6da7ec','Neutral':'#a9a8a1','EN only':'#e98a80','EN+pIOD':'#b3302e',
         'pIOD only':'#eda100','nIOD only':'#1baf7a','EN+nIOD':'#6250d6','LN+pIOD':'#e87ba4'}
LAB={'LN+nIOD':'La Niña\n& −IOD','LN only':'La Niña\nonly','Neutral':'Neutral','EN only':'El Niño\nonly','EN+pIOD':'El Niño\n& +IOD',
     'pIOD only':'+IOD\nonly','nIOD only':'−IOD\nonly','EN+nIOD':'El Niño\n& −IOD','LN+pIOD':'La Niña\n& +IOD'}
LAB1={k:v.replace('\n',' ') for k,v in LAB.items()}
DS1='#2a78d6'; DS2='#1baf7a'; INK='#0b0b0b'; INK2='#52514e'; MUTE='#898781'; GRID='#e1e0d9'
ORDER4=['LN+nIOD','LN only','EN only','EN+pIOD']
def panel(ax,letter,title):
    ax.set_title(f'({letter}) {title}',loc='left',fontsize=8.5,fontweight='bold',color=INK)
def zero(ax,axis='y'):
    (ax.axhline if axis=='y' else ax.axvline)(0,color='#c3c2b7',lw=0.7,zorder=0)
def save(fig,name):
    fig.savefig(f'/home/claude/figs/{name}.png',dpi=300,bbox_inches='tight',facecolor='white'); fig.savefig(f'/home/claude/figs/{name}.pdf',bbox_inches='tight',facecolor='white'); plt.close(fig)
